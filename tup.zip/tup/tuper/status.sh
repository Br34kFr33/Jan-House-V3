#!/bin/bash
# Usage: ./status.sh [rt1/rt2]
# Accepetd parameters are: rt1, rt2
# If no parameters are passed, status for tuper-client is returned.
# Passing rt1 returns rtorrent1 screen session status
# Passing rt2 returns rtorrent2 screen session status
#
# Prints out return code of "kill -0", meaning shows if pid is running and
# killable. 0 - running and ok, >0 - something is wrong.
#
cd `dirname $0`
if [ "$1" == "rt1" ]
then
    kill -0 `ps -f -AF | grep -i rtorrent | grep -iv screen | grep rtorrent.rc | grep -iv grep | awk '{ print $2 }'`
else
    if [ "$1" == "rt2" ]
    then
        kill -0 `ps -f -AF | grep -i rtorrent | grep -iv screen | grep rtorrent2.rc | grep -iv grep | awk '{ print $2 }'`
    else
        kill -0 `cat tuper.pid`
        
    fi
fi
echo $?
