#!/bin/bash
cd `dirname $0`
LOOP=1
if [ "$1" == "rt1" ]
then
    PID=`ps -f -AF | grep -i rtorrent | grep -iv screen | grep rtorrent.rc | grep -iv grep | awk '{ print $2 }'`
    kill -INT $PID
    ./wait.sh $PID
    screen -dmS rtorrent1 rtorrent -n -o import=~/.rtorrent.rc
else
    if [ "$1" == "rt2" ]
    then
        PID=`ps -f -AF | grep -i rtorrent | grep -iv screen | grep rtorrent2.rc | grep -iv grep | awk '{ print $2 }'`
        kill -INT $PID
        ./wait.sh $PID
        screen -dmS rtorrent2 rtorrent -n -o import=~/.rtorrent2.rc
    else
        screen -X -S tuper quit
        screen -dmS tuper ./run-tuper-client.sh
    fi
fi
