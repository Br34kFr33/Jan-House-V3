{
    package AnnounceHelper;

    use JSON::XS;

    use IO::Async::Loop;
    use IO::Async::Timer::Periodic;
    use IO::Socket::INET;
    use IO::Async::Protocol::Stream;

    #use IO::Async::Handle;
    #use IO::Async::Listener;
    #use IO::Async::Stream;
    #use IO::Async::Function;

    sub new{
	    my ($proto, $params)=@_;
	    my $class = ref($proto) || $proto;
	    my $self  = {};

	    $self->{_host}=defined $params->{host} ? $params->{host} : '127.0.0.1'; # AnnounceClient host
	    $self->{_port}=defined $params->{port} ? $params->{port} : 8505; # Announce client port
	    $self->{_retry}=defined $params->{retry} ? $params->{retry} : 3; # Retry time for AnnounceClient socket
	    $self->{_timeout}=defined $params->{timeout} ? $params->{timeout} : 10; # Retry time for AnnounceClient socket
	    $self->{_timer_time}=defined $params->{timer_time} ? $params->{timer_time} : 30; # Retry time for AnnounceClient socket
	    $self->{_socket}=undef; # Connection socket to AnnounceClient
	    $self->{_socket_event}=undef; # Event that happens on socket activity
	    $self->{_socket_ping}=0; # Ping flag for checking conectivity
	    $self->{_event_loop}=undef; # Main event loop
	    $self->{_timer_event}=undef; # Runs action_ping sub
	    $self->{_connect_event}=undef; # Runs init_connect sub
	    $self->{_json}=JSON::XS->new();
	    $self->{_json}->pretty(0);
	    $self->{_json}->utf8(1);

	    bless($self, $class);
	    return $self;
    }

    sub init{
	    my $self = shift;
	    print "[JhUp] Starting up JhUp::AnnounceHelper.\n";

	    # Creating main loop
	    $self->{_event_loop} = IO::Async::Loop->new();

	    # Server connection loop
	    $self->{_connect_event} = IO::Async::Timer::Periodic->new(
		    interval => $self->{_retry},
		    on_tick => sub { $self->init_connect(@_) },
	    );
	    $self->{_event_loop}->add($self->{_connect_event});

	    # Timer that executes every 30 sec
	    $self->{_timer_event} = IO::Async::Timer::Periodic->new(
		    interval => $self->{_timer_time},
		    on_tick => sub { $self->action_send_ping() },
	    );
	    $self->{_event_loop}->add($self->{_timer_event});

	    $self->init_connect();

	    # Start the loop
	    $self->{_event_loop}->loop_forever;

    }

    sub init_connect{
	    my $self = shift;

	    $self->{_socket} = IO::Socket::INET->new(
		    PeerAddr => $self->{_host},
		    PeerPort => $self->{_port},
		    Proto    => 'tcp',
		    Timeout    => $self->{_timeout},
	    );

       if(! defined $self->{_socket}){
		    print "[JhUp] Could not connect to AnnounceClient ".$self->{_host}.", port ".$self->{_port}.", retrying in ".$self->{_retry}." sec.: $!\n";
		    if(not $self->{_connect_event}->is_running){
			    $self->{_connect_event}->start;
		    }
		    return 0;
	    }else{

		    $self->{_socket_event} = IO::Async::Protocol::Stream->new(
			    handle => $self->{_socket},
			    on_read => sub { $self->socket_read_event(@_) },
			    on_closed => sub { $self->socket_closed_event(@_) },
		    );
		    $self->{_event_loop}->add($self->{_socket_event});

		    $self->{_connect_event}->stop;
		    $self->{_timer_event}->start;
	    }
	    print "[JhUp] Connected to AnnounceClient!\n";
	    return 1;
    }

    sub socket_read_event{
        my ($self, $socket, $buffref, $eof ) = @_;
        return 0 unless $$buffref =~ s/^(.*)\n//;
        my $line = $1;

	    if($eof){
		    $self->socket_close();
		    return 0;
	    }

	    my $incoming;
	    eval {$incoming = $self->{_json}->decode($line);};
	    if($@){
		    print "[JhUp] Got incoming data with no JSON, ignoring.\n";
	    }else{
		    if(exists $incoming->{c}){
			    if($incoming->{c} eq "ping") { $self->action_got_ping(@_) }
			    elsif($incoming->{c} eq "pong") { $self->action_got_pong(@_) }
			    else{ print "[JhUp] Recieved unknown command: ".$incoming->{c}."\n" }
		    }else{
			    print "[JhUp] Recieved JSON data but it has no command specified, ignoring.";
		    }
	    }
	    $self->{_socket_ping}=0;
	    $buffref="";
        return 1;
    }

    sub action_send_ping{
	    my ($self) = @_;

	    if($self->{_socket_ping}==1){
		    print "[JhUp] AnnounceClient didn't respond to ping, closing connection.\n";
		    $self->socket_close();
		    return 0;
	    }
	    $self->{_socket_ping}=1;
	    print "[JhUp] Sending ping!\n";
	    $self->{_socket}->write('{"c":"ping"}'."\n");
    }

    sub action_got_pong{
	    my ($self) = @_;
	    print "[JhUp] Got pong!\n";
	    $self->{_socket_ping}=0;
    }

    sub action_got_ping{
	    my ($self) = @_;
	    print "[JhUp] Got ping, sending pong!\n";
	    $self->{_socket}->write('{"c":"pong"}'."\n");
    }

    sub socket_close{
	    my $self=shift;
	    print "[JhUp] Closing connection.\n";
	    $self->{_socket_event}->close;
    }

    sub socket_closed_event{
	    my $self=shift;
	    if($!){ print "[JhUp] Lost connection: $!.\n";}
	    else{print "[JhUp] Disconnected.\n";}
	    close $self->{_socket};
	    $self->{_timer_event}->stop;
	    $self->{_connect_event}->start;
    }
}

1;
