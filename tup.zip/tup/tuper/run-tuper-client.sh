#!/bin/sh
cd `dirname $0`
while true
do
    ./JhUp announce-client
    echo "Tuper client closed. Reopening..."
done
