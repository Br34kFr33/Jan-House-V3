#!/bin/sh
cd `dirname $0`
if ! [[ "$1" =~ ^[0-9]+$ ]] ; then
    exit 1
fi
PID=$1
LOOP=1
if [ $PID ]
then
    while [ $LOOP == 1 ]
    do
        status=1
        kill -0 $PID
        status=$?
        if [ $status != 0 ]
        then
            exit 0
        fi
        sleep 1
    done
fi
