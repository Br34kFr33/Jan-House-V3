#!/usr/bin/env perl
use warnings;
no warnings qw/uninitialized/;
use strict;

{
    package AnnounceHelper;

    use JSON::XS;
    use IO::Socket::INET;
    use IO::Socket::UNIX qw( SOCK_STREAM );

    sub new{
	    my ($proto, $params)=@_;
	    my $class = ref($proto) || $proto;
	    my $self  = {};

        $self->{_unix_socket}=$params->{unix_socket} == 1 ? 1 : 0; # Should it use UNIX domain socket
        $self->{_socket_path}=defined $params->{socket} ? $params->{socket} : '/tmp/JhUp.sock'; # UNIX socket path
	    $self->{_host}=defined $params->{host} ? $params->{host} : '127.0.0.1'; # AnnounceClient host
	    $self->{_port}=defined $params->{port} ? $params->{port} : 8505; # Announce client port
	    $self->{_timeout}=defined $params->{timeout} ? $params->{timeout} : 10; # Timeout for AnnounceClient socket
	    $self->{_json}=JSON::XS->new();
	    $self->{_json}->pretty(0);
	    $self->{_json}->utf8(1);

	    bless($self, $class);
	    return $self;
    }

    sub send{
	    my ($self, $data) = @_;

	    if(ref $data eq 'HASH'){
		    $data=$self->{_json}->encode($data)."\n";
	    }elsif(ref $data eq 'SCALAR'){
		    $data=$$data."\n";
	    }else{
		    print "[JhUp] Trying to send wrong data format: ".ref($data);
		    return 0;
	    }

        my $socket = undef;
        if($self->{_unix_socket}==1){
            $socket = IO::Socket::UNIX->new(
                Peer  => $self->{_socket_path},
                Type      => SOCK_STREAM,
                Timeout   => $self->{_timeout},
            );
        }else{
            $socket = IO::Socket::INET->new(
                PeerAddr => $self->{_host},
                PeerPort => $self->{_port},
                Proto    => 'tcp',
                Timeout  => $self->{_timeout},
            );
        }

	    if(not defined $socket){
            if($self->{_unix_socket}==1){
                print "[JhUp] *** Could not connect to AnnounceClient ".$self->{_socket_path}.": $!\n";
            }else{
                print "[JhUp] *** Could not connect to AnnounceClient ".$self->{_host}.", port ".$self->{_port}.": $!\n";
            }
		    return 0;
	    }else{
		    print "[JhUp] *** Connected to AnnounceClient!\n";
		    $socket->autoflush(1);
		    my $line = <$socket>; # Receive greeting from server
		    #print "[JhUp] Got: ".$line;
		    #print "[JhUp] Sending: $data";
		    print $socket $data; # Send data to server
		    $line = <$socket>;
		    if(not $line){
			    print "[JhUp] Got EOF.\n";
			    return 0;
		    }

		    my $incoming;
		    my $retval=1;
		    eval {$incoming = $self->{_json}->decode($line);};
		    if(not $@){
			    if(exists $incoming->{c} and $incoming->{c} eq 'r' and exists $incoming->{m} and exists $incoming->{r}){
				    print "[JhUp] Got proper ".($incoming->{r}==0 ? 'FAILURE' : 'SUCCESS')." response: ".$incoming->{m}."\n";
				    if($incoming->{r}==2){ $retval=2; }
			    }else{
				    print "[JhUp] Got improper JSON response: $line";
			    }
		    }else{
			    print "[JhUp] Got plaintext response: ".$line;
		    }

		    if(close $socket){
			    #print "[JhUp] *** Closed connection.\n";
		    }else{
			    #print "[JhUp] *** Failed to close connection: $!\n";
		    }
		    return $retval;
	    }
	    return 1;
    }
}
################################################################################

    package main;

        return 1 if caller;
        die "No arguments added.\n" if not defined $ARGV[0];

        my %command;

        if($ARGV[0] eq 'get' or $ARGV[0] eq 'aget'){
	        die "Command get/aget requires at least 2 parameters.\n" if not defined $ARGV[1] or not defined $ARGV[2];
	        %command=('c' => $ARGV[0], 's' => $ARGV[1], 'id' => $ARGV[2], 't' => $ARGV[3]);
        }elsif($ARGV[0] eq 'upload' or $ARGV[0] eq 'aupload'){
	        die "Command upload/aupload requires at least 1 parameter.\n" if not defined $ARGV[1];
	        %command=('c' => $ARGV[0], 'h' => $ARGV[1], 't' => $ARGV[2]);
        }elsif($ARGV[0] eq 'send_rls'){
	        die "Command send_rls requires at least 4 parameters.\n" if not defined $ARGV[1] or not defined $ARGV[2] or not defined $ARGV[3] or not defined $ARGV[4];
	        %command=('c' => $ARGV[0], 'name' => $ARGV[4], 'category' => $ARGV[3], 'source' => $ARGV[1], 'id' => $ARGV[2]);
        }elsif($ARGV[0] eq 'local_rls'){
	        die "Command local_rls requires at least 4 parameters.\n" if not defined $ARGV[1] or not defined $ARGV[2] or not defined $ARGV[3] or not defined $ARGV[4];
	        %command=('c' => $ARGV[0], 'name' => $ARGV[4], 'category' => $ARGV[3], 'source' => $ARGV[1], 'id' => $ARGV[2], 'type' => $ARGV[5]);
        }elsif($ARGV[0] eq 'status' or $ARGV[0] eq 'astatus'){
            die "Command status/astatus requires at least 2 parameters.\n" if not defined $ARGV[1] or not defined $ARGV[2];
            %command=('c' => $ARGV[0], 'a' => $ARGV[1], 'h' => $ARGV[2]);
        }elsif($ARGV[0] eq 'del' or $ARGV[0] eq 'adel'){
            die "Command del/adel requires at least 2 parameters.\n" if not defined $ARGV[1] or not defined $ARGV[2];
            %command=('c' => $ARGV[0], 'a' => $ARGV[1], 'h' => $ARGV[2]);
        }elsif($ARGV[0] eq 'restart'){
            %command=('c' => $ARGV[0]);
        }elsif($ARGV[0] eq 'add' or $ARGV[0] eq 'aadd'){
            die "Command add/aadd requires at least 2 parameters.\n" if not defined $ARGV[1] or not defined $ARGV[2];
            %command=('c' => $ARGV[0], 'cat' => $ARGV[1], 'dir' => $ARGV[2], 't' => $ARGV[3]);
        }

        die "No correct arguments added.\n" if not %command;

        my %params=(
            host => '127.0.0.1',
            port => 8505,
            unix_socket => 0,
            socket => '/tmp/JhUp.sock',
        );

        my $c=AnnounceHelper->new(\%params);

        my $resp=$c->send(\%command);

        exit 2 if $resp==2;
        exit 1 if $resp==0;
        exit 0 if $resp>0;

    exit;

1;
