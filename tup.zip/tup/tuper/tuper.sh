#!/bin/sh
cd `dirname $0`
/usr/bin/env perl ./announce-helper.pl "$@"
