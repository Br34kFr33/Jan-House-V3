require "include/upload_tof.config.pm";

sub upload_tof {

	my $name=shift; # Torrent name from database
	my $category=shift; # Category ID
	my $description=shift; # Description file path
	my $torrent=shift;  # Torrent file path
	my $nfo=shift; # NFO file path
	my $to_tracker=shift; # tracker code (for example: fano)
	my $defname=shift; # Filename from database
	my $defhash=shift; # Download torrent file info hash
	my $config=shift;

	my $r=ClientFunctions->new('upload', 'tof', $config);

	###################################
	# Requesting upload page before sending POST data
	# This should be used to bypass some session verification checks
	my $eh=$r->get("http://www.torrentfeed.org/upload.php");
	return 0 if($eh==0);

	###################################
	# Search for nologin
	my $match_nologin=qr/<form method='post' action='takelogin.php'>/ms;
	my $nologin_matches=$r->match('nologin', $match_nologin);
	if($nologin_matches!=0){ $r->err('	Can not continue without login, aborting!'); return 0;}
	my $descr_txt=$r->read_file($description);

        ###################################
        # Search for original NFO that comes with torrent
        $nfo=$r->find_nfo($torrent, $nfo, $config->{paths}->{download_dir});

	# Read description	
	my $descr_txt=$r->read_file($description);
	if($descr_txt eq $config->{tuper}->{no_descr_txt}){
	$descr_txt=$r->read_file($nfo);
	}

    use Net::BitTorrent::File;
    my $fromfile = new Net::BitTorrent::File($torrent);
    delete($fromfile->{data}{"announce-list"});
    delete($fromfile->{data}{"announce"});
    $fromfile->announce('http://www.torrentfeed.org/announce.php?passkey='.$config->{cookies}->{passkey_tof});
    my $newtorr=$config->{paths}->{temp_dir}.$defname.".torrent";
    $fromfile->save($newtorr);
    if(-f $newtorr){
        $torrent=$newtorr;
    }

	###################################
	# Upload torrent
	$r->form_new;
	# Form fields passed to upload script
	$r->form_add('MAX_FILE_SIZE', '3145728');
	$r->form_add('request', '0');
	$r->form_add('fontsize', '0');
	$r->form_add('fontfont', '0');
	$r->form_add('request', 'no');	
	$r->form_add('strip', 'strip');
	$r->form_add('release_group', 'none');
	$r->form_add('uplver', 'yes');
	$r->form_add('free_length', '0');
	$r->form_add('genre', '');
	$r->form_add('poster', '');
	$r->form_add('youtube', '');
	$r->form_add('tags', '');
	# Match IMDB URL
	my $match_imdb=qr/imdb.com\/title\/tt([0-9]*)/ms; 
        my $imdb=""; 
        if($descr_txt =~ $match_imdb){
                $imdb="http://www.imdb.com/title/tt".$1."/"; 
                $r->err("Found IMDB link: ".$imdb); 
        }
	$r->form_add('description', ''); #genre
	$r->form_add('url', $imdb);
	$r->form_add('type', $category);
	$r->form_add('name', $name);
	$r->form_add('descr', $descr_txt);

	# Form files passed to upload script
	return 0 if(not $r->form_add_file('file', $torrent, "application/x-bittorrent"));
	return 0 if(not $r->form_add_file('nfo', $nfo, "text/plain"));

	# POSTing data to upload script
	$eh=$r->post("http://www.torrentfeed.org/takeupload.php");
	return 0 if($eh==0);
#	$r->err($r->{curldat});
    ###################################
    # Search for already uploaded
    my $match_uploaded=qr/torrent already uploaded.<\/td>/ms;
    my $uploaded_matches=$r->match('uploaded', $match_uploaded);
    if($uploaded_matches!=0){ $r->err('	Torrent already uploaded, aborting!'); return 0;}

	###################################
	# Search for torrent id
	my $match_torrentid=qr/href="download.php\?torrent=(\d*?)"/ms;
	my $torrentid_matches=$r->match('torrent id', $match_torrentid);
	if($torrentid_matches==0){ $r->err('	Can not continue without torrent ID, aborting!'); return 0;}
	my $torrentid=@$torrentid_matches[0];
	$r->err("	Torrent ID: $torrentid");

	###################################
	# Request torrent file
	my $eh=$r->get("http://www.torrentfeed.org/download.php?torrent=".$torrentid);
	return 0 if($eh==0);

	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("	Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('	Can not continue without infohash, aborting!'); return 0; }
	$r->err('	Downloaded file infohash: '.$down_hash);
	my $newtorr=$r->{curldat};

	$newtorr=$r->remove_hashcheck($config->{paths}->{upload_dir}, $newtorr);
	return 0 if($newtorr eq 0);

	###################################
	# Write torrent file
	my $torr_file=$config->{paths}->{watch2_dir}."[".uc($to_tracker)."]".$defname.".torrent";
	if($r->write_file('torrent', $torr_file, $newtorr)==0){ return 0; }

	my %retvals=(
		"id" => $torrentid,
		"hash" => $down_hash,
	);
	return \%retvals;

}

sub add_tof {
    my $category_name=shift;
    my $directory=shift;
    my $config=shift;

    my $to_tracker="tof";
    my $directory_path=$config->{paths}->{download_dir}.$directory;

    #################################
    # Loading ClientFunctions class that has useful client functions
    my $r=ClientFunctions->new('upload', $to_tracker, $config);

    #################################
    # Checking if folder exists in downloads directory
    my $notsingle=0;
    if(-d $directory_path){
        $r->err("Found directory $directory to add");
        $notsingle=1;
    }elsif(-d $directory_path){
        $r->err("Found single file $directory to add");
    }else{
        $r->err("Found no files to add, aborting!", "red"); return 0;
    }

    #################################
    # Look for NFO
    my $nfo="";
    if($notsingle){
        $r->err("Looking for NFO file");
        my $upl_data_dir = $directory_path;
        my $new_nfo="";
        opendir(DIR, $upl_data_dir);
        my @files = readdir(DIR);
        for my $file (@files)
        {
            $file eq '.'  and next;
            $file eq '..' and next;
            if( $file =~ /\.nfo$/i ){
                $new_nfo=$upl_data_dir.'/'.$file;
                $r->err("NFO file found: ".$new_nfo);
                last;
            }
        }
        if($new_nfo eq ""){
            $nfo=$config->{tuper}->{no_descr_txt};
            $r->err("Failed to find original NFO...");
        }else{
            if($nfo=$r->read_file($new_nfo)){
                $r->err("Succeeded finding original NFO...");
            }else{
                $r->err("Found NFO file but failed to read it...");
            }            
        }
    }else{
        $nfo=$config->{tuper}->{no_descr_txt};
    }
    my $description=$nfo;

    #################################
    # Set up name
    my $name=$directory;
    my $filename=$directory;

    #################################
    # Create torrent
    my $torzname=$config->{paths}->{temp_dir}.$filename.".torrent";
    my $anauns="http://127.0.0.1";
    if(defined $config->{cookies}->{"announce_".$to_tracker}){
        $anauns=$config->{cookies}->{"announce_".$to_tracker};
    }
    if(-f $torzname){
        @argz=($torzname);
        system "rm", @argz;
    }
    # Checking path size
    my $size=$r->path_size($directory_path);
    # Picking piece size for mktorrent
    my $piece_size=$r->mktorrent_piece_size($size);
    # Building torrent
    @argz=('-p', '-v', '-l', $piece_size, '-a', $anauns, '-o', $torzname, $directory_path);
    $r->err("mktorrent ".join(' ', @argz));
    system "mktorrent", @argz;

    if(not -f $torzname){
        $r->err("Can't find the new torrent file, aborting."); return 0;
    }
    $r->err("Finished making torrent...");

    #################################
    # Getting info hash to add to the database

    my $torrent_data=$r->read_file($torzname);
    my $torrent_info=$r->process_torrent_data($torrent_data);
    if(not $torrent_info->{'hash'}){ $r->err('Failed to get info hash. Is the torrent broken?'); return 0; }
    my $down_hash=lc($torrent_info->{'hash'});

    ###################################
    # Writing temp files
    # Write NFO file
    my $nfo_file=$config->{paths}->{temp_dir}.$filename.".nfo";
    if($r->write_file('nfo', $nfo_file, $nfo)==0){ return 0; }
    # Wrtie description file
    my $descr_file=$config->{paths}->{temp_dir}.$filename.".txt";
    if($r->write_file('description', $descr_file, $description)==0){ return 0; }

    my $torr_file=$torzname;

     my $target_cat_name=$category_name;
     my $category_id=0;
     eval " \$category_id = &cat_ftp_ftp1_".$to_tracker."(\$target_cat_name); ";
     if($category_id==0)
         { $r->err("Failed to find target tracker ($to_tracker) category ID for source tracker ($source) category name '$target_cat_name'.\nResponse was: $category_id", 'red'); return 0; }
     $r->err("Category ID for $target_cat_name on $to_tracker => $category_id");
     my $category=$category_id;

    my %retvals=(
        "name" => $name,
        "descr" => $description,
        "filename" => $filename,
        "category" => $category,
        "nfo_file" => $nfo_file,
        "descr_file" =>  $descr_file,
        "torrent_data" => $torrent,
        "down_hash" => $down_hash,
    );
    return \%retvals;

}

1;
