sub cat_id_tv_xtv{
	my $veids=shift;
	my %cat=(
		"Appz/0DAY" => 3,
		"Appz/Mac" => 3,
		"Appz/PC-ISO" => 3,
		"Ebooks" => 5,
		"BlurayTV" => 20,
		"Documentaries" => 20,
		"Episodes/TV-Boxset" => 20,
		"Episodes/TV-x264" => 20,
		"Episodes/TV-XviD" => 20,
		"Episodes/TV-Foreign" => 20,
		"Games/Wii" => 10,
		"Games/NDS" => 6,
		"Games/PC-ISO" => 7,
		"Games/PS2" => 9,
		"Games/PS3" => 33,
		"Games/PSP" => 8,
		"Games/Wii" => 10,
		"Game/Packs" => 6,
		"Games/X360" => 22,
		"Movies/Boxsets" => 11,
		"Movies/DVDR" => 12,
		"Movies/x264" => 13,
		"Movies/XviD" => 14,
		"Music/MP3" => 16,
		"Music/Videos" => 17,
		"Music/FLAC" => 15,
		"Requests" => 81,
		"Packs/0DAY" => 3,
		"Packs/Ebooks" => 5,
		"Packs/Music" => 16,
		"Retro/Music" => 16,
		"Episodes/TV-DVDR" => 20,
		"Sports" => 18,
		"Sports/UFC" => 19,
		"Sports/WWE" => 31,
		"XXX" => 26,
		"Windows Software" => 30,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_gft_xtv{
	my $veids=shift;
	my %cat=(
		"APPS" => 5,
		"0DAY" => 5,
		"XXX-XVID" => 999,
		"TV-XVID" => 8,
		"Music" => 16,
		"Games/PC" => 9,
		"Movies-XVID" => 13,
		"Movies-DVDR" => 21,
		"E-Learning" => 7,
		"Misc" => 9,
		"Games/XBOX360" => 11,
		"MVID" => 18,
		"GFT Gems" => 999,
		"Anime" => 3,
		"TV-X264" => 8,
		"Movies-X264" => 28,
		"Movies/XviD" => 13,
		"TV-DVDRIP" => 8,
		"XXX-HD" => 999,
		"XXX-0DAY" => 999,
		"Games/WII" => 27,
		"XXX-DVDR" => 999,
		"Portable/Mobile/PDA" => 5,
		"MAC" => 5,
		"Games/PSP" => 12,
		"Games/NDS" => 22
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}


sub cat_id_rtt_xtv{
	my $veids=shift;
	my %cat=(
		"Anime" => 77,
		"Apps/Misc" => 81,
		"Appz/PC-ISO" => 3,
		"E-Book" => 95,
		"Games/PC-ISO" => 6,
		"Games/PC-Rips" => 6,
		"Games/PS2" => 85,
		"Games/PS3" => 85,
		"Games/Wii" => 85,
		"Games/XBOX360" => 85,
		"Handheld/PSP" => 91,
		"Mac" => 81,
		"Movies/DVDR" => 87,
		"Movies/Packs" => 82,
		"Movies/WMV" => 77,
		"Movies/x264" => 86,
		"Movies/XviD" => 86,
		"Music" => 84,
		"Music/Packs" => 88,
		"MusicVideos" => 78,
		"TV/DVDR" => 89,
		"TV/HR" => 77,
		"TV/Packs" => 89,
		"TV/x264" => 86,
		"TV/XViD" => 77,
		"XXX" => 90,
		"XXX/DVDR" => 90,
		"XXX/HD" => 90
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_scc_xtv{
	my $veids=shift;
	my %cat=(
		"Dox" => 205,
		"Apps/PC ISO" => 207,
		"Games/PC ISO" => 207,
		"Games/PS2" => 207,
		"Games/PS3" => 207,
		"Games/WII" => 207,
		"Games/XBOX" => 207,
		"Games/XBOX360" => 207,
		"MiSC" => 207,
		"Movies/DVDR" => 210,
		"Movies/VCD" => 213,
		"Movies/X264" => 200,
		"Movies/XviD" => 213,
		"TV/DVDR" => 236,
		"TV-X264" => 233,
		"TV/XviD" => 233,
		"XXX" => 207,
		"Apps/0DAY" => 207,
		"MP3" => 207,
		"Music Videos" => 207
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_tl_xtv{
	my $veids=shift;
	my %cat=(
		"Anime/Cartoon" => 198,
		"Appz/MAC" => 207,
		"Appz/misc" => 207,
		"Appz/PC ISO" => 207,
		"Appz/PDA" => 207,
		"Books - Mags" => 207,
		"Documentaries" => 205,
		"Episodes/Boxsets" => 236,
		"Episodes/TV" => 233,
		"Episodes" => 233,		
		"Games/PC ISO" => 207,
		"Games/PC Retro" => 207,
		"Games/PC Rips" => 207,
		"Games/PS2" => 207,
		"Games/PS3" => 207,
		"Games/PS2 Retro" => 207,
		"Games/PSP" => 207,
		"Games/Wii" => 207,
		"Games/X360 Retro" => 207,
		"Games/XBOX" => 207,
		"Games/XBOX360" => 207,
		"Movies/DVD-R" => 210,
		"Movies/Foreign" => 213,
		"Movies/HD-x264" => 200,
		"Movies/Music DVD" => 207,
		"Movies/Retro" => 201,
		"Movies/XviD" => 213,
		"Music" => 207,
		"Nintendo DS" => 207,
		"NonScene/BRRip-x264" => 207,
		"NonScene/BRRip-XviD" => 207,
		"NonScene/Xvid" => 213,
		"XXX" => 207
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_danbit_xtv{
	my $veids=shift;
	my %cat=(
		"Appz" => 3,
		"BluRay" =>86,
		"Console" => 85,
		"Covers" => 81,
		"Danishbits Custom" => 81,
		"Danske Film" => 77,
		"Ebooks" => 95,
		"HD-X264" => 86,
		"Movies/DVDnonDK" => 87,
		"Movies/DVDR" => 87,
		"Movies/DVDR-NOR" => 87,
		"Movies/DVDR-SWE" => 87,
		"Movies/XviD" => 77,
		"Music" => 84,
		"Music Videos" => 78,
		"PC Games" => 6,
		"TV" => 77,
		"XXX" => 90
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

# IPTorrents category converter
sub cat_id_ipt_xtv{
	my $veids=shift;
	my %cat=(
		"Appz/misc" => 207,
		"Anime" => 198,
		"Ebooks" => 207,
		"Books - Mags" => 207,
		"Games/Nintendo DS" => 207,
		"Games/PC ISO" => 207,
		"Games/PC Rips" => 207,
		"Games/PS2" => 207,
		"Games/PSP" => 207,
		"Games/PS3" => 207,
		"Games/Wii" => 207,
		"Games/XBOX" => 207,
		"Games/XBOX360" => 207,
		"HD/X264" => 200,
		"Movies/DVD-R" => 210,
		"Movies/Non-English" => 213,
		"Movies/Packs" => 212,
		"Movies/XviD" => 213,
		"Music > Video" => 207,
		"Music/Audio" => 207,
		"Sports" => 225,
		"Sports/UFC" => 225,
		"Sports/WWE" => 223,
		"TV > Episodes" => 233,
		"TV/Packs" => 236,
		"TV/XVID" => 233,
		"Windows > Software" => 207,
		"XXX" => 207
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}
1;
