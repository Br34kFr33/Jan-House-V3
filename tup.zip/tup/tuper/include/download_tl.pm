sub download_tl {

	$tid=shift;
	$config=shift;

	#use ClientFunctions;
	my $r=ClientFunctions->new('download', 'tl', $config);

	###################################
	# Request page
	my $eh=$r->get("http://www.torrentleech.org/torrent/".$tid);
	return 0 if($eh==0);

	###################################
	# Search for nologin
	my $match_nologin=qr/<input name="login"/ms;
    my $nologin_matches=$r->match('nologin', $match_nologin);
    if($nologin_matches!=0 and not defined $config->{cookies}->{cookie_tl}){
        $r->err('Can not continue without login, trying to login!');
        $r->form_new;
        $r->form_add('login', 'submit');
        $r->form_add('remember_me', 'on');
        $r->form_add('username', $config->{cookies}->{user_tl});
        $r->form_add('password', $config->{cookies}->{pass_tl});
        $eh=$r->post("http://www.torrentleech.org/user/account/login/");
        return 0 if($eh==0);
        $nologin_matches=$r->match('nologin', $match_nologin);
        if($nologin_matches!=0){
                $r->err('Can not continue without login, aborting!');
                return 0;
        }
        $eh=$r->get("http://www.torrentleech.org/torrent/".$tid);
        return 0 if($eh==0);
    }elsif($nologin_matches!=0){
        $r->err('Can not continue without login, aborting!');
        return 0;
    }

	###################################
	# Search for notorrent
	my $match_notorrent=qr/<h1>An error occurred<\/h1>/m;
	my $notorrent_matches=$r->match('notorrent', $match_notorrent);
	if($notorrent_matches!=0){ $r->err('	Can not continue without torrent, aborting!'); return 0;}

	###################################
	# Search for name
	my $match_name=qr/Torrent Name<\/td><td>(.*?)<\/td><\/tr>/ms;
	my $name_matches=$r->match('name', $match_name);
	if($name_matches==0){ $r->err('	Can not continue without name, aborting!'); return 0;}
	my $name=@$name_matches[0];
	$r->err("	Name: $name");

	###################################
	# Filename
	my $filename=$name;
	$filename =~ s/ /./g;
	$r->err("	Filename: $filename");

	###################################
	# Search for category
	my $match_category=qr/Category<\/td><td>(.*?)<\/td><\/tr>/ms;
	my $category_matches=$r->match('category', $match_category);
	if($category_matches==0){ $r->err('	Can not continue without category, aborting!'); return 0;}
	my $category=$r->html_unescape(@$category_matches[0]);
	$r->err("	Category: $category...");

	###################################
	# Search for description
	$r->err('	No description for TL, using default one');
	$description=$config->{tuper}->{no_descr_txt};

	###################################
	# Request torrent page
	my $eh=$r->get("http://www.torrentleech.org/download/".$tid."/some.torrent/");
	return 0 if($eh==0);

	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("	Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('	Can not continue without infohash, aborting!'); return 0; }
	$r->err('	Downloaded file infohash: '.$down_hash);
	$torrent=$r->{curldat};

	###################################
	# Writing files
	# Write NFO file
	my $nfo_file=$config->{paths}->{temp_dir}.$filename.".nfo";
	if($r->write_file('nfo', $nfo_file, $description)==0){ return 0; }
	# Wrtie description file
	my $descr_file=$config->{paths}->{temp_dir}.$filename.".txt";
	if($r->write_file('description', $descr_file, $description)==0){ return 0; }
	# Write torrent file
	my $torr_file=$config->{paths}->{temp_dir}.$filename.".torrent";
	if($r->write_file('torrent', $torr_file, $torrent)==0){ return 0; }

	my %retvals=(
		"name" => $name,
		"descr" => $description,
		"filename" => $filename,
		"category" => $category,
		"nfo_file" => $nfo_file,
		"descr_file" =>  $descr_file,
		"torrent_data" => $torrent,
		"down_hash" => $down_hash,
	);
	return \%retvals;

}

1;
