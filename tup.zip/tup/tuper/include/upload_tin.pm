require "include/upload_tin.config.pm";

sub upload_tin {

	my $name=shift; # Torrent name from database
	my $category=shift; # Category ID
	my $description=shift; # Description file path
	my $torrent=shift;  # Torrent file path
	my $nfo=shift; # NFO file path
	my $to_tracker=shift; # tracker code (for example: fano)
	my $defname=shift; # Filename from database
	my $defhash=shift; # Download torrent file info hash
	my $config=shift;

	my $r=ClientFunctions->new('upload', 'tin', $config);

	my $passkey=$config->{cookies}->{passkey_tin};
	
	###################################
	# Search for original NFO that comes with torrent
	$nfo=$r->find_nfo($torrent, $nfo, $config->{paths}->{download_dir});

	###################################
	# Requesting upload page before sending POST data
	# This should be used to bypass some session verification checks
	my $eh=$r->get("http://theinternationals.nu/index.php?pid=upload");
	return 0 if($eh==0);

	###################################
	# Search for nologin
	my $match_nologin=qr/<input type="submit" name="login" value="Login" \/>/ms;
    my $nologin_matches=$r->match('nologin', $match_nologin);
    if($nologin_matches!=0 and not defined $config->{cookies}->{cookie_tin}){
        $r->err('Can not continue without login, trying to login!');
        $r->form_new;
        $r->form_add('remember_me', 'on');
        $r->form_add('login', 'Login');
        $r->form_add('username', $config->{cookies}->{user_tin});
        $r->form_add('password', $config->{cookies}->{pass_tin});
        $eh=$r->post("http://theinternationals.nu/index.php?pid=upload");
        return 0 if($eh==0);
        $nologin_matches=$r->match('nologin', $match_nologin);
        if($nologin_matches!=0){
                $r->err('Can not continue without login, aborting!');
                return 0;
        }
        $eh=$r->get("http://theinternationals.nu/index.php?pid=upload ");
        return 0 if($eh==0);
    }elsif($nologin_matches!=0){
        $r->err('Can not continue without login, aborting!');
        return 0;
    }


	# Read description	
    my $descr_txt=$r->read_file($description);
    if($descr_txt eq $config->{tuper}->{no_descr_txt}){
        $descr_txt=$r->read_file($nfo);
    }
	
	###################################
	# Upload torrent
	$r->form_new;
	# Form fields passed to upload script
	
	# Match IMDB URL
	my $match_imdb=qr/imdb.com\/title\/tt([0-9]*)/ms; 
        my $imdb=""; 
        if($descr_txt =~ $match_imdb){
                $imdb="http://www.imdb.com/title/tt".$1."/"; 
                $r->err("Found IMDB link: ".$imdb); 
        }
	$r->form_add('url', $imdb);
	$r->form_add('youtube', '');
	$r->form_add('upload', 'Upload Torrent');
	$r->form_add('type', $category);
	#$r->form_add('name', $name);
	#$r->form_add('descr', $descr_txt);

	# Form files passed to upload script
	return 0 if(not $r->form_add_file('file', $torrent, "application/x-bittorrent"));
	return 0 if(not $r->form_add_file('nfo', $nfo, "multipart/form-data"));

	# POSTing data to upload script
	$eh=$r->post("http://theinternationals.nu/index.php?pid=upload");
	return 0 if($eh==0);


	my $torrentid=0;
	###################################
	# Search for already uploaded
	my $match_uploaded=qr/already uploaded/ms;
	my $uploaded_matches=$r->match('uploaded', $match_uploaded);
	if($uploaded_matches!=0){ $r->err('Torrent already uploaded, aborting!'); return 0; }

	#$r->err($r->{curldat});

	###################################
	# Search for torrent id
	my $match_torrentid=qr/download.php\?torrent=(\d*?)'/ms;
	my $torrentid_matches=$r->match('torrent id', $match_torrentid);
	if($torrentid_matches==0){ $r->err('	Can not continue without torrent ID, aborting!'); return 0;}
	$torrentid=@$torrentid_matches[0];
	$r->err("	Torrent ID: $torrentid");
	
	###################################
	# Request torrent file
	my $eh=$r->get("http://theinternationals.nu/download.php?torrent=".$torrentid);
	return 0 if($eh==0);
	
	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("	Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('	Can not continue without infohash, aborting!'); return 0; }
	$r->err('	Downloaded file infohash: '.$down_hash);
	my $newtorr=$r->{curldat};

	#$newtorr=$r->remove_hashcheck($config->{paths}->{upload_dir}, $newtorr);
	#return 0 if($newtorr eq 0);

	###################################
	# Write torrent file
	my $torr_file=$config->{paths}->{watch2_dir}."[".uc($to_tracker)."]".$defname.".torrent";
	if($r->write_file('torrent', $torr_file, $newtorr)==0){ return 0; }

	my %retvals=(
		"id" => $torrentid,
		"hash" => $down_hash,
	);
	return \%retvals;

}
1;
