require "include/upload_stc.config.pm";

sub upload_stc {

	my $name=shift; # Torrent name from database
	my $category=shift; # Category ID
	my $description=shift; # Description file path
	my $torrent=shift;  # Torrent file path
	my $nfo=shift; # NFO file path
	my $to_tracker=shift; # tracker code (for example: fano)
	my $defname=shift; # Filename from database
	my $defhash=shift; # Download torrent file info hash
	my $config=shift;

	my $r=ClientFunctions->new('upload', 'stc', $config);

	my $passkey=$config->{cookies}->{passkey_stc};

	###################################
	# Requesting upload page before sending POST data
	# This should be used to bypass some session verification checks
	my $eh=$r->get("http://scenetrader.com/index.php?page=upload");
	return 0 if($eh==0);

	###################################
	# Search for nologin
	my $match_nologin=qr/<form action="index.php\?page=login" name="login" method="post">/ms;
	my $nologin_matches=$r->match('nologin', $match_nologin);
	if($nologin_matches!=0 and not defined $config->{cookies}->{cookie_stc}){
        $r->err('Can not continue without login, trying to login!');
        $r->form_new;
        $r->form_add('uid', $config->{cookies}->{user_stc});
        $r->form_add('pwd', $config->{cookies}->{pass_stc});
        $eh=$r->post("http://scenetrader.com/index.php?page=login");
        return 0 if($eh==0);
        $nologin_matches=$r->match('nologin', $match_nologin);
        if($nologin_matches!=0){
                $r->err('Can not continue without login, aborting!');
                return 0;
        }
        $eh=$r->get("http://scenetrader.com/index.php?page=upload");
	        return 0 if($eh==0);
	}elsif($nologin_matches!=0){
		$r->err('Can not continue without login, aborting!');
		return 0;
	}



	###################################
	# Search for original NFO that comes with torrent
	$nfo=$r->find_nfo($torrent, $nfo, $config->{paths}->{download_dir});
	# Read description	
	my $descr_txt=$r->read_file($description);
	if($descr_txt eq $config->{tuper}->{no_descr_txt}){
	$descr_txt=$r->read_file($nfo);
	}
	
#    my $rartorr=$r->rarextract($torrent, $defname, 0, 0);
#    $torrent=$rartorr;

    use Net::BitTorrent::File;
    my $fromfile = new Net::BitTorrent::File($torrent);
    delete($fromfile->{data}{"announce-list"});
    delete($fromfile->{data}{"announce"});
    $fromfile->announce('http://scenetrader.com:2710/announce');
    my $newtorr=$config->{paths}->{temp_dir}.$defname.".torrent";
    $fromfile->save($newtorr);
    if(-f $newtorr){
        $torrent=$newtorr;
    }

# Movies
#if($category==18){
#        if($name =~ m/1080p/i) {
#                $category=19;
#        }
#}
# TV
#if($category==21){
#        if($name =~ m/1080p/i) {
#                $category=22;
#        }
#}
# Movies
#if($category==33){
#        if($name =~ m/1080p/i) {
#                $category=34;
#        }
#}

	###################################
	# Upload torrent
	$r->form_new;
	# Form fields passed to upload script
	
	# Match IMDB URL
	my $match_imdb=qr/imdb.com\/title\/tt([0-9]*)/ms; 
        my $imdb=""; 
        if($descr_txt =~ $match_imdb){
                $imdb=$1; 
                $r->err("Found IMDB link: ".$imdb); 
        }
	$r->form_add('imdb', $imdb);

	$r->form_add('youtube_video', '');
	$r->form_add('anonymous', 'false');
	$r->form_add('req', 'false');
	$r->form_add('nuk', 'false');
	$r->form_add('nuk_rea', '');
	$r->form_add('fontchange', '');
	$r->form_add('user_id', '');

	$r->form_add('videoalignment', '');
	$r->form_add('videotype', '');
	$r->form_add('scroll', '');

	$r->form_add('category', $category);
	$r->form_add('filename', $name);
	$r->form_add('genre', $name);
	$r->form_add('info', $descr_txt);

	# Form files passed to upload script
	return 0 if(not $r->form_add_file('torrent', $torrent, "application/x-bittorrent"));
	return 0 if(not $r->form_add_file('userfile', "", "multipart/form-data"));
	return 0 if(not $r->form_add_file('screen1', "", "multipart/form-data"));
	return 0 if(not $r->form_add_file('screen2', "", "multipart/form-data"));
	return 0 if(not $r->form_add_file('screen3', "", "multipart/form-data"));

	# POSTing data to upload script
	$eh=$r->post("http://scenetrader.com/index.php?page=upload");
	return 0 if($eh==0);

	#$r->err($r->{curldat});
	my $torrentid=0;
	###################################
	# Search for already uploaded
	my $match_uploaded=qr/This torrent may already exist in our database/ms;
	my $uploaded_matches=$r->match('uploaded', $match_uploaded);
	if($uploaded_matches!=0){ $r->err('Torrent already uploaded, aborting!'); return 0; }

	#$r->err($r->{curldat});

	###################################
	# Search for torrent id
	my $match_torrentid=qr/<a href="download.php\?id=(.*?)&/ms;
	my $torrentid_matches=$r->match('torrent id', $match_torrentid);
	if($torrentid_matches==0){ $r->err('	Can not continue without torrent ID, aborting!'); return 0;}
	$torrentid=@$torrentid_matches[0];
	$r->err("	Torrent ID: $torrentid");
	
	###################################
	# Request torrent file
	my $eh=$r->get("http://scenetrader.com/download.php?id=".$torrentid."&f=some.torrent");
	return 0 if($eh==0);
	
	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("	Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('	Can not continue without infohash, aborting!'); return 0; }
	$r->err('	Downloaded file infohash: '.$down_hash);
	my $newtorr=$r->{curldat};

	$newtorr=$r->remove_hashcheck($config->{paths}->{upload_dir}, $newtorr);
	return 0 if($newtorr eq 0);

	###################################
	# Write torrent file
	my $torr_file=$config->{paths}->{watch2_dir}."[".uc($to_tracker)."]".$defname.".torrent";
	if($r->write_file('torrent', $torr_file, $newtorr)==0){ return 0; }

	my %retvals=(
		"id" => $torrentid,
		"hash" => $down_hash,
	);
	return \%retvals;

}
1;
