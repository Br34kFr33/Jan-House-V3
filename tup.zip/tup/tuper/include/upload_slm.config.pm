# Demonoid
sub cat_id_dmn_slm{
    my $veids=shift;
    my %cat=(
        "Applications" => 0,
        "Audio Books" => 0,
        "Books" => 0,
        "Comics" => 0,
        "Games" => 0,
        "Japanese Anime" => 0,
        "Miscellaneous" => 0,
        "Movies" => 0,
        "Music" => 0,
        "Music Videos" => 0,
        "Pictures" => 0,
        "TV" => 0,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# iLoveTorrents
sub cat_id_ilt_slm{
    my $veids=shift;
    my %cat=(
        "3D" => 0,
        "Anime" => 0,
        "Appz/Misc" => 0,
        "Appz/PC ISO" => 0,
        "Ebooks" => 0,
        "Games/PC ISO" => 0,
        "Games/PC Rips" => 0,
        "Games/PS3" => 0,
        "Games/Wii" => 0,
        "Games/Xbox360" => 0,
        "KIDS-Zone" => 0,
        "Mobile" => 0,
        "Movies Packs" => 0,
        "Movies/DVD-R" => 0,
        "Movies/x264" => 0,
        "Movies/XviD" => 0,
        "Music Videos" => 0,
        "Music/Albums" => 0,
        "Other/Stuff" => 0,
        "TV/HDx264" => 0,
        "TV/Packs" => 0,
        "TV/SDx264" => 0,
        "TV/XviD" => 0,
        "XXX" => 0,
        "XXX/DVDR" => 0,
        "XXX/HD" => 0,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# BitSoup
sub cat_id_bs_slm{
    my $veids=shift;
    my %cat=(
        "Anime" => 0,
        "Appz/Misc" => 0,
        "Appz/PC ISO" => 0,
        "Audiobooks" => 0,
        "Ebooks" => 0,
        "Games/PC ISO" => 0,
        "Games/PC Rips" => 0,
        "Games/PS2" => 0,
        "Games/PS3" => 0,
        "Games/Wii" => 0,
        "Games/Xbox" => 0,
        "Games/Xbox360" => 0,
        "Movies/DVD-R" => 0,
        "Movies/Packs" => 0,
        "Movies/XviD" => 0,
        "Music Videos" => 0,
        "Music/Albums" => 0,
        "Other/MISC" => 0,
        "PSP/Handheld" => 0,
        "TV-HDx264" => 0,
        "TV-Packs" => 0,
        "TV-SDx264" => 0,
        "TV-XVID" => 0,
        "x264" => 0,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# SceneTime
sub cat_id_sct_slm{
    my $veids=shift;
    my %cat=(
        "Movies/XviD" => 0,
        "Movies/DVD-R" => 0,
        "Movies/XxX" => 0,
        "Movie/Packs" => 0,
        "Movies/Anime" => 0,
        "Movies/480p" => 0,
        "Movies/HD" => 0,
        "Movies/Classic" => 0,
        "Movies/3D" => 0,
        "Freeleech" => 0,
        "Games/PC ISO" => 0,
        "Games/XBOX" => 0,
        "Games/PSP" => 0,
        "Games/PS3" => 0,
        "Games/Wii" => 0,
        "Games/Nintendo DS" => 0,
        "TV/XviD" => 0,
        "TV/Packs" => 0,
        "TV-X264" => 0,
        "TV/Classic" => 0,
        "Apps/0DAY" => 0,
        "Books-Mags" => 0,
        "Mac" => 0,
        "Music/Audio" => 0,
        "Music/Videos" => 0,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# ninjabits
sub cat_id_njb_slm{
    my $veids=shift;
    my %cat=(
        "AppZ" => 1,
        "film/Barn BluRay" => 0,
        "film/Barn DVD-R" => 0,
        "film/BluRay" => 0,
        "film/DVD-R" => 0,
        "film/DVD-R - P2P" => 0,
        "film/x264" => 0,
        "Spill" => 0,
        "tv/DVD-R" => 0,
        "tv/x264" => 0,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# scanbytes
sub cat_id_sby_slm{
    my $veids=shift;
    my %cat=(
        "Android" => 0,
        "Appz/Annet" => 0,
        "DVD/Boks" => 0,
        "E-Bok" => 0,
        "Filmer/bluray" => 0,
        "Filmer/DVD-R" => 0,
        "Filmer/x264" => 0,
        "Filmer/XviD" => 0,
        "God Jul" => 0,
        "Kids" => 0,
        "Lydbok" => 0,
        "Musikk" => 0,
        "Software/PC" => 0,
        "Spill/DS" => 0,
        "Spill/PC" => 0,
        "Spill/PS3" => 0,
        "Spill/Wii" => 0,
        "Spill/Xbox" => 0,
        "TV-Episoder" => 1,
        "XXX" => 0,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# SweDream
sub cat_id_swd_slm{
    my $veids=shift;
    my %cat=(
        "Bluray complete" => 0,
        "DVD-R BARN" => 0,
        "DVD-R Eng" => 0,
        "Film Blu-ray" => 0,
        "Film DVD-R" => 0,
        "Film XviD" => 0,
        "Konsoll Retro" => 0,
        "Ljudböcker" => 0,
        "Mac Program" => 0,
        "Musik" => 0,
        "Musik Videos" => 0,
        "Oldies" => 0,
        "P2P" => 0,
        "PC-spel" => 0,
        "PS3" => 0,
        "PSP" => 0,
        "SD-Pack" => 0,
        "TV HD" => 0,
        "TV Xvid" => 0,
        "Wii" => 0,
        "Windows Program" => 0,
        "XBOX 360" => 0,
        "XMAS " => 0,
        "XXX" => 0,
        "Övrigt" => 0,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}


# Tsnu
sub cat_id_tsnu_slm{
    my $veids=shift;
    my %cat=(
        "Animerat" => 0,
        "DVDR" => 0,
        "HD" => 0,
        "LD/XviD" => 0,
        "Boxar" => 0,
        "Film" => 0,
        "Musik" => 0,
        "Serie" => 0,
        "Dokumentär" => 0,
        "DVDR" => 0,
        "HD" => 0,
        "LD/XviD" => 0,
        "Serie" => 0,
        "FILM" => 0,
        "DVDR" => 0,
        "HD" => 0,
        "LD/XviD" => 0,
        "Julkalendern" => 0,
        "Julk. (DVDR)" => 0,
        "Julk. (HD)" => 0,
        "Julk. (XviD)" => 0,
        "Ljudböcker" => 0,
        "Musik" => 0,
        "FLAC" => 0,
        "MP3" => 0,
        "Musikvideo" => 0,
        "Månadens Pack" => 0,
        "Program" => 0,
        "Serier/TV" => 0,
        "DVDR" => 0,
        "HD" => 0,
        "LD/XviD" => 0,
        "Spel" => 0,
        "PC" => 0,
        "PS" => 0,
        "Wii" => 0,
        "Xbox" => 0,
        "Övrigt" => 0,
        "Sport" => 0,
        "Veckans Film" => 0,
        "DVDR" => 0,
        "HD" => 0,
        "LD/XviD" => 0,
        "Övrigt" => 0,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}



sub cat_id_hdt_slm{
	my $veids=shift;
	my %cat=(
        "Blu-Ray" => 0,
        "Remux" => 0,
        "HD-DVD" => 0,
        "BD-25" => 0,
        "1080p/i" => 0,
        "720p" => 0,
        "Audio Track" => 0,
        "Album" => 0,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}


# TorrentDay.com
sub cat_id_td_slm{
        my $veids=shift;
        my %cat=(
            "1" => 0, #MOVIES
            "2" => 0, #TV
            "3" => 0, #DVDR
            "4" => 0, #PC GAMES
            "5" => 0, #PS2
            "6" => 0, #XXX
            "7" => 0, #TV-X264
            "8" => 0, #PSP
            "9" => 0, #XBOX360
            "10" => 0, #WII
            "12" => 0, #Software
            "11" => 0, #X264
            "13" => 0, #MOVIES Packs
            "14" => 0, #TV Packs
            "15" => 0, #XXX Packs
            "17" => 0, #MP3
            "16" => 0, #Music Videos
            "18" => 0, #PS3
            "19" => 0, #XXX
            "20" => 0, #EBOOKS
            "21" => 0, #MP4 Movies
            "22" => 0, #Bollywood Movies
            "23" => 0, #Bollywood Music
            "24" => 0, #TV/480p
            "25" => 0, #Movies/480p
        );
        return &JhUp::find_hash_value(0, $veids, \%cat);
}

# CHDBits
sub cat_id_chd_slm{
    my $veids=shift;
    my %cat=(
        "Movies" => 0,
        "iP/iPad" => 0,
        "Documentaries" => 0,
        "Animations" => 0,
        "TV Series" => 0,
        "TV Shows" => 0,
        "Music Videos" => 0,
        "Sports" => 0,
        "Misc" => 0,
        "HQ Audio" => 0,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# CHDbits category converter (regexp version)
sub cat_id_chd_slm{
        my $veids=shift;
        if($veids =~ m/Movie/) {
                return 37;
        }elsif($veids =~ m/Documentaries/) {
                return 35;
        }elsif($veids =~ m/Sport/) {
                return 23;
        }
        return &JhUp::find_hash_value(0, $veids, \%cat);
}

# SceneBits
sub cat_id_sceb_slm{
    my $veids=shift;
    my %cat=(
        "Appz/PC ISO" => 0,
        "Games/PC ISO" => 0,
        "Movies/x264" => 0,
        "Music" => 0,
        "Episodes" => 0,
        "XXX" => 0,
        "Games/GBA" => 0,
        "Games/PS2" => 0,
        "Anime" => 0,
        "Movies/XviD" => 0,
        "Movies/DVD-R" => 0,
        "Games/PC Rips" => 0,
        "Appz/misc" => 0,
        "Games/XBox" => 0,
        "Games/PC DVD" => 0,
        "Games/PSP" => 0,
        "Music Videos" => 0,
        "Games/XBox360" => 0,
        "Games/PS3" => 0,
        "Games/Wii" => 0,
        "E-Books" => 0,
        "XXX/DVD-R" => 0,
        "TV/DVDR" => 0,
        "0-Day" => 0,
        "TV/x264" => 0,
        "Packs/ScB" => 0,
        "FLAC" => 0,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# Norbits
sub cat_id_norb_slm{
    my $veids=shift;
    my %cat=(
        "Bøker/Blader o.l." => 0,
        "Filmer/Blu-ray" => 0,
        "Filmer/DVDR" => 0,
        "Filmer/MP4" => 0,
        "Filmer/MPEG" => 0,
        "Filmer/XviD" => 0,
        "Filmer/x264" => 0,
        "Lydbøker" => 0,
        "Musikk" => 0,
        "Musikkvideoer" => 0,
        "Programvare" => 0,
        "Spill" => 0,
        "TV/DVDR" => 0,
        "TV/XviD" => 0,
        "TV/x264" => 0,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# Trance Traffic
sub cat_id_tt_slm{
    my $veids=shift;
    my %cat=(
        "Albums - Dance" => 0,
        "Albums - Goa/Psy" => 0,
        "Albums - Hardcore" => 0,
        "Albums - Hardstyle" => 0,
        "Albums - House" => 0,
        "Albums - Other" => 0,
        "Albums - Techno" => 0,
        "Albums - Trance" => 0,
        "Amateur" => 0,
        "Ambient/Chill/Lo-Fi" => 0,
        "Beat/Breaks" => 0,
        "Drum & Bass/Jungle" => 0,
        "DVD/Video/Clips" => 0,
        "Electronic" => 0,
        "Livesets - Goa/Psy" => 0,
        "Livesets - Hardstyle" => 0,
        "Livesets - House" => 0,
        "Livesets - Other" => 0,
        "Livesets - Techno" => 0,
        "Livesets - Trance" => 0,
        "Music Plugins/Apps/Misc" => 0,
        "Singles - Dance" => 0,
        "Singles - Goa/Psy" => 0,
        "Singles - Hardcore" => 0,
        "Singles - Hardstyle" => 0,
        "Singles - House" => 0,
        "Singles - Other" => 0,
        "Singles - Techno" => 0,
        "Singles - Trance" => 0,
        "TranceTraffic Packs" => 0,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# bit-hdtv
sub cat_id_bhdtv_slm{
    my $veids=shift;
    my %cat=(
        "Anime" => 0,
        "Blu-ray" => 0,
        "Demonstration" => 0,
        "Documentaries" => 0,
        "HQ Audio" => 0,
        "Movies" => 0,
        "Music Videos" => 0,
        "Other" => 0,
        "Sports" => 0,
        "TV" => 0,
        "TV/Seasonpack" => 0,
        "XXX" => 0,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# hd-space
sub cat_id_hds_slm{
    my $veids=shift;
    my %cat=(
        "Blu-Ray" => 0,
        "HD-DVD" => 0,
        "Movies 720p" => 0,
        "Movies 1080" => 0,
        "HDTV 720p" => 0,
        "HDTV 1080" => 0,
        "Doc 720p" => 0,
        "Doc 1080" => 0,
        "Animation 720p" => 0,
        "Animation 1080" => 0,
        "HQ Audio" => 0,
        "Videos" => 0,
        "XXX 720p" => 0,
        "XXX 1080" => 0,
        "Trailers" => 0,
        "Software" => 0,
        "Other" => 0,
        "HDSTaRS" => 0,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# digitalhive
sub cat_id_dh_slm{
    my $veids=shift;
    my %cat=(
        "0Day" => 6,
        "0DAY-XXX" => 36,
        "Mp3" => 21,
        "MVID" => 20,
        "TV-DVDRip" => 32,
        "Anime" => 32,
        "Documentary" => 32,
        "DVD-R" => 1,
        "Ebooks" => 6,
        "HandHeld" => 6,
        "Kids Stuff" => 1,
        "Linux" => 6,
        "Mac" => 19,
        "Misc" => 6,
        "MKV (Non-HD)" => 31,
        "Movie Pack" => 1,
        "Music" => 21,
        "PC Appz" => 18,
        "PC Games" => 27,
        "PS2/PS3" => 3,
        "PSP" => 3,
        "TV Pack" => 34,
        "TV-x264" => 33,
        "TV-XViD" => 33,
        "WII" => 4,
        "x264" => 17,
        "XBox" => 26,
        "XviD" => 31,
        "XXX" => 36,
        "XXX-DVDR" => 36,
    );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}


# HD-Space
sub cat_id_hds_hdmkv{
    my $veids=shift;
    my %cat=(
        "Blu-Ray" => 0,
        "HD-DVD" => 0,
        "Movies 720p" => 0,
        "Movies 1080" => 0,
        "HDTV 720p" => 0,
        "HDTV 1080" => 0,
        "Doc 720p" => 0,
        "Doc 1080" => 0,
        "Animation 720p" => 0,
        "Animation 1080" => 0,
        "HQ Audio" => 0,
        "Videos" => 0,
        "XXX 720p" => 0,
        "XXX 1080" => 0,
        "Trailers" => 0,
        "Software" => 0,
        "Other" => 0,
        "HDSTaRS" => 0,
        );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}


# filelist.ro
sub cat_id_flr_slm{
        my $veids=shift;
        my %cat=(
			"Filme XviD" => 0,
			"Filme DVD" => 0,
			"Filme DVD-RO" => 0,
			"Filme HD" => 0,
			"Filme VCD" => 0,
			"Filme Vechi" => 0,
			"XXX" => 0,
			"Programe" => 0,
			"Jocuri PC" => 0,
			"Console" => 0,
			"Audio" => 0,
			"Videoclip" => 0,
			"Sport" => 0,
			"TV" => 0,
			"Desene" => 0,
			"Docs" => 0,
			"Linux" => 0,
			"Diverse" => 0,
			"HD-RO" => 0,
			"Blu-ray" => 0,
			"HDTV" => 0,
			"Mobile" => 0,
        );
        return &JhUp::find_hash_value(0, $veids, \%cat);
}

# TheGFT
sub cat_id_gft_slm{
    my $veids=shift;
    my %cat=(
"0DAY" => 0,
"Anime" => 0,
"APPS" => 0,
"E-Learning" => 0,
"Foreign" => 0,
"Games/NDS" => 0,
"Games/PC" => 0,
"Games/PS3" => 0,
"Games/PSP" => 0,
"Games/WII" => 0,
"Games/XBOX360" => 0,
"Misc" => 0,
"Movies/BLURAY" => 0,
"Movies/DVDR" => 0,
"Movies/X264" => 0,
"Movies/XVID" => 0,
"Music/DVDR" => 0,
"Music/FLAC" => 0,
"Music/MP3" => 0,
"Music/Vids" => 0,
"TV/BLURAY" => 0,
"TV/DVDR" => 0,
"TV/DVDRIP" => 0,
"TV/SD" => 30,
"TV/X264" => 0,
"TV/XVID" => 0,
"XXX/0DAY" => 0,
"XXX/DVDR" => 0,
"XXX/HD" => 0,
"XXX/XVID" => 0,
"Games/Gems" => 0,
"Misc/Gems" => 0,
"Movies/Gems" => 0,
"Music/Gems" => 0,
"TV/Gems" => 0,
"XXX/Gems" => 0,
        );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# RevolutionTT
sub cat_id_rtt_slm{
    my $veids=shift;
    my %cat=(
        "Anime" => 0,
        "Appz/Misc" => 0,
        "Appz/PC-ISO" => 0,
        "E-Book" => 0,
        "Games/PC-ISO" => 0,
        "Games/PC-Rips" => 0,
        "Games/PS2" => 0,
        "Games/PS3" => 0,
        "Games/Wii" => 0,
        "Games/XBOX360" => 0,
        "Handheld/NDS" => 0,
        "Handheld/PSP" => 0,
        "Mac" => 0,
        "Movies/DVDR" => 0,
        "Movies/Packs" => 0,
        "Movies/x264" => 0,
        "Movies/XviD" => 0,
        "Music" => 0,
        "Music/Packs" => 0,
        "MusicVideos" => 0,
        "TV/DVDR" => 0,
        "TV/Packs" => 0,
        "TV/x264" => 0,
        "TV/XViD" => 0,
        "XXX" => 0,
        "XXX/DVDR" => 0,
        "XXX/HD" => 0,
        );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# Torrentleech
sub cat_id_tl_slm{
    my $veids=shift;
    my %cat=(
        "Movies" => 0,
        "Cam" => 0,
        "TS/TC" => 0,
        "R5/Screeners" => 0,
        "DVDRip/DVDScreener" => 0,
        "DVD-R" => 0,
        "HD" => 0,
        "BDRip" => 0,
        "Boxsets" => 0,
        "Documentaries" => 0,
        "TV" => 0,
        "Episodes" => 0,
        "BoxSets" => 0,
        "Episodes HD" => 0,
        "Games" => 0,
        "PC" => 0,
        "XBOX" => 0,
        "XBOX360" => 0,
        "PS2" => 0,
        "PS3" => 0,
        "PSP" => 0,
        "Wii" => 0,
        "Nintendo DS" => 0,
        "Music" => 0,
        "Music Videos" => 0,
        "Audio" => 0,
        "Books" => 0,
        "Applications" => 0,
        "PC-ISO" => 0,
        "Mac" => 0,
        "PDA" => 0,
        "0-day" => 0,
        "Animation" => 0,
        "Anime" => 0,
        "Cartoons" => 0,
        );
    return &JhUp::find_hash_value(0, $veids, \%cat);
}

# Sceneaccess
sub cat_id_scc_slm{
	my $veids=shift;
	my %cat=(
        "0DAY" => 0,
        "APPS" => 0,
        "DOX" => 0,
        "MISC" => 0,
        "Movies/DVD-R" => 0,
        "Movies/x264" => 0,
        "Movies/XviD" => 0,
        "Movies/Packs" => 0,
        "TV/DVD-R" => 0,
        "TV/DVDRip" => 0,
        "TV/SD-x264" => 30,
        "TV/HD-x264" => 0,
        "TV/XviD" => 0,
        "TV/Packs" => 0,
        "Games/PC" => 0,
        "Games/PS3" => 0,
        "Games/PSP" => 0,
        "Games/WII" => 0,
        "Games/XBOX360" => 0,
        "Games/Packs" => 0,
        "MP3" => 0,
        "MVID" => 0,
        "Music/Packs" => 0,
        "XXX/XviD" => 0,
        "XXX/x264" => 0,
        "XXX/0DAY" => 0,
        "XXX/Packs" => 0,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

# IPTorrents
sub cat_id_ipt_slm{
	my $veids=shift;
	my %cat=(
        "Movies" => 0,
        "Movie/DVD-R" => 0,
        "Movie/HD/Bluray" => 0,
        "Movie/Kids" => 0,
        "Movie/MP4" => 0,
        "Movie/Non-English" => 0,
        "Movie/Packs" => 0,
        "Movie/XviD" => 0,
        "Movie/XXX" => 0,
        "Movies/480p" => 0,
        "TV" => 0,
        "TV/480p" => 0,
        "TV/MP4" => 0,
        "TV/Packs" => 0,
        "TV/X264" => 0,
        "TV/XVID" => 0,
        "Games" => 0,
        "Games/Mixed" => 0,
        "Games/Nintendo DS" => 0,
        "Games/PC ISO" => 0,
        "Games/PC Rips" => 0,
        "Games/PS2" => 0,
        "Games/PS3" => 0,
        "Games/PSP" => 0,
        "Games/Wii" => 0,
        "Games/XBOX" => 0,
        "Games/XBOX360" => 0,
        "Music" => 0,
        "Music/Audio" => 0,
        "Music/Video" => 0,
        "Books / Applications" => 0,
        "Anime" => 0,
        "Appz/misc" => 0,
        "AudioBook" => 0,
        "Books - Mags" => 0,
        "MAC" => 0,
        "Mobile" => 0,
        "Pics/Wallpapers" => 0,
        "Sports" => 0,
        "Freeleech" => 0,
        "New" => 0,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_qu_slm{
	my $veids=shift;
	my %cat=(
		"Audiobooks" => 25,
		"Musik" => 51,
		"Musikvideos" => 24,
		"Tonspuren" => 51,
		"Filme: deutsch (X)VCD" => 29,
		"Filme: deutsch DivX|Xvid" => 29,
		"Filme: deutsch DVD" => 28,
		"Filme: deutsch HD" => 61,
		"Filme: int. (X)VCD" => 29,
		"Filme: int. DivX|Xvid" => 29,
		"Filme: int. DVD" => 28,
		"Filme: int. HD" => 61,
		"Serien: deutsch" => 37,
		"Serien: deutsch HD" => 37,
		"Serien: int." => 37,
		"Serien: int. HD" => 37,
		"Anime" => 40,
		"Dokus" => 46,
		"E-Books & Comics" => 25,
		"PDA & Handy" => 36,
		"Pictures" => 36,
		"Programme" => 35,
		"TV - sonstiges" => 24,
		"Spiele: Konsolen sonstige" => 36,
		"Spiele: PC" => 33,
		"Spiele: PS2" => 34,
		"Spiele: PSP" => 41,
		"Spiele: Wii" => 47,
		"Spiele: XBOX360" => 49,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_bfty_slm{
	my $veids=shift;
	my %cat=(
        "Anime" => 0,
        "Appz MAC" => 0,
        "Appz other" => 0,
        "Appz Windows" => 0,
        "Dokumentationen" => 0,
        "eBooks" => 0,
        "Games PC" => 0,
        "HDTV" => 0,
        "Hörbücher" => 0,
        "Movies 1080p/1080i" => 0,
        "Movies 720p/720i" => 0,
        "Movies BluRay" => 0,
        "Movies DVD/HDDVD" => 0,
        "Movies M/SVCD/Other" => 0,
        "Movies XVID/DIVX/h.264" => 0,
        "Music" => 0,
        "Musikvideo" => 0,
        "Nintendo DS" => 0,
        "other" => 0,
        "Playstation" => 0,
        "Serien HD" => 0,
        "Serien XviD" => 0,
        "Sport" => 0,
        "TVRip" => 0,
        "US Movies" => 0,
        "US Serien" => 8,
        "Wii" => 0,
        "Xbox 360" => 0,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_mtt_slm{
	my $veids=shift;
	my %cat=(
        "Anime" => 24,
        "Appz - Mac" => 17,
        "Appz - PC" => 17,
        "Appz misc" => 17,
        "Comedy" => 12,
        "Dokus" => 25,
        "DOX" => 17,
        "E-Books" => 20,
        "Games - Mac" => 9,
        "Games - PC" => 9, 
        "Games - PSP" => 33,
        "Games - PSX" => 10,
        "Games - Wii" => 34,
        "Games - XBox" => 10,
        "Games - XBox 360" => 35,
        "Halloween" => 31,
        "Hörspiele" => 21,
        "Movies - BluRay + Remux" => 29,
        "Movies - DVD" => 30,
        "Movies - HD" => 29,
        "Movies - Sonstiges" => 5,       
        "Movies - XviD" => 6, 
        "Musik" => 14,
        "Sonstiges" => 31,
        "TV Events" => 12,
        "TV Serie" => 8,
        "TV Serienpacks" => 8,
        "XXX" => 0,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_hdsb_slm{
	my $veids=shift;
	my %cat=(
        "Anime - HD" => 24,
        "Blu-Ray" => 29,
        "Blu-Ray 3D" => 29,
        "Blu-Ray Remux" => 29,
        "Doku - HD" => 25,
        "Halloween" => 0,
        "Movie - 1080i" => 29,
        "Movie - 1080p" => 29,
        "Movie - 1080p 3D" => 29,
        "Movie - 720p" => 29, 
        "MusikVids - HD" => 15,
        "Other - HD" => 12,
        "Tonspur" => 16,
        "TV Events - HD" => 12,
        "TV Serie - HD" => 36,
        "TV Serienpacks - HD" => 36,
        "XXX - HD" => 0,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_ts_slm{
	my $veids=shift;
	my %cat=(
        "1080p" => 29,
        "3D" => 29,
        "720p" => 29,
        "Anime" => 24,
        "Apps/MacOSX" => 17,
        "Apps/Win" => 17,
        "Dokus" => 25,
        "EBooks" => 20,
        "Film/DVDR" => 30,
        "Film/h264" => 6, 
        "Film/XVCD" => 5,
        "Film/Xvid/DivX" => 6,
        "Games/Other" => 10,
        "Games/PC" => 9,
        "Games/PS2/PS3" => 32,
        "Games/PSP" => 33,
        "Games/Wii" => 34,
        "Games/XBOX" => 10,
        "Games/XBOX360" => 35,
        "HD/Bluray" => 29,
        "Hörspiele" => 21,
        "Musik" => 14,
        "Musik Videos" => 15,
        "Musik/Packs" => 14,
        "Serien/DVDR" => 8,
        "Serien/HD" => 36,
        "Serien/Packs" => 8,
        "Serien/Xvid" => 8,
        "Sport" => 12,                   
        "Tonspuren" => 16,
        "Verschiedenes" => 17,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

# tti.nu
sub cat_id_tti_slm{
	my $veids=shift;
	my %cat=(
        "anime" => 1,
        "audio_books" => 1,
        "console_games" => 1,
        "dvd_boxset" => 1,
        "dvd_video" => 1,
        "hdmovies" => 1,
        "hdtv" => 1,
        "misc" => 1,
        "motw" => 1,
        "music" => 1,
        "music_videos" => 1,
        "pc_games" => 1,
        "software" => 1,
        "tv" => 1,
        "tv_seasons" => 1,
        "xvid" => 1,
        "xxx" => 1,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

# Nordic t
sub cat_id_nt_slm{
	my $veids=shift;
	my %cat=(
        "0day" => 1,
        "Amateur Productions" => 1,
        "Anime" => 1,
        "Appz" => 1,
        "Audiobooks" => 1,
        "Books/Articles/Magazines" => 1,
        "Fix Pack" => 1,
        "Free to Leech" => 1,
        "Games/PC" => 1,
        "Games/PS1" => 1,
        "Games/PS2" => 1,
        "Games/PS3" => 1,
        "Games/PSP" => 1,
        "Games/Wii" => 1,
        "Games/Xbox360" => 1,
        "MAC appz" => 1,
        "Misc" => 1,
        "Movies/DVD5" => 1,
        "Movies/DVD9" => 1,
        "Movies/HD" => 1,
        "Movies/XviD" => 1,
        "Music" => 1,
        "Music Videos" => 1,
        "TV" => 1,
        "XXX" => 1,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

# Filmbits.net
sub cat_id_fbn_slm{
	my $veids=shift;
	my %cat=(
        "Appz" => 0,
        "Bluray" => 0,
        "Children" => 0,
        "Custom" => 0,
        "DVD-R" => 0,
        "DVD-R/TV" => 0,
        "DVD9" => 0,
        "Dvdboxes" => 0,
        "HD" => 0,
        "P2P" => 0,
        "Weekend" => 0,
        "XviD" => 0,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

# scanbits
sub cat_id_scnb_slm{
	my $veids=shift;
	my %cat=(
        "Android" => 1,
        "Apps - Mac" => 71,
        "Apps Windows" => 1,
        "Books - Mags" => 1,
        "BoxSets" => 10,
        "Custom DVDR" => 11,
        "Games/PC ISO" => 12,
        "Games/PS" => 8,
        "Games/Wii" => 31,
        "Games/XBOX360" => 32,
        "Ipod" => 15,
        "Kids" => 10,
        "Movies/DVDR" => 11,
        "Movies/HD-X264" => 10,
        "Movies/MP4" => 58,
        "Movies/TS or Cam" => 10,
        "Movies/XviD" => 10,
        "Music &gt; Video" => 17,
        "Music/Audio" => 15,
        "ODAY" => 1,
        "Pics/Wallpapers 	" => 1,
        "Sports" => 10,
        "Trash" => 1,
        "TV &gt; Episodes" => 70,
        "TV &gt; Episodes HD" => 70,
        "XXX" => 6,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

# torrentstar nu
sub cat_id_trns_slm{
        my $veids=shift;
        return 1;

}

# Sparvar
sub cat_id_sprv_slm{
	my $veids=shift;
	my %cat=(
        "PAL DVDR" => 11, 
        "Custom DVDR" => 11, 
        "TV DVDR" => 70, 
        "TV XviD" => 70, 
        "Film XviD" => 10, 
        "Film HD" => 64, 
        "TV HD" => 70, 
        "Ljudbok" => 18, 
        "E-bok" => 18, 
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

1;
