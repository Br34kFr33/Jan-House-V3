# TorrentDay.com
sub cat_id_td_fano{
        my $veids=shift;
        my %cat=(
            "1" => 1, #MOVIES
            "2" => 1, #TV
            "3" => 1, #DVDR
            "4" => 1, #PC GAMES
            "5" => 1, #PS2
            "6" => 1, #XXX
            "7" => 1, #TV-X264
            "8" => 1, #PSP
            "9" => 1, #XBOX360
            "10" => 1, #WII
            "12" => 1, #Software
            "11" => 1, #X264
            "13" => 1, #MOVIES Packs
            "14" => 1, #TV Packs
            "15" => 1, #XXX Packs
            "17" => 1, #MP3
            "16" => 1, #Music Videos
            "18" => 1, #PS3
            "19" => 1, #XXX
            "20" => 1, #EBOOKS
            "21" => 1, #MP4 Movies
            "22" => 1, #Bollywood Movies
            "23" => 1, #Bollywood Music
        );
        return &JhUp::find_hash_value(0, $veids, \%cat);
}

# HDBits category converter
sub cat_id_hdb_fano{
	my $veids=shift;
	if($veids =~ m/Audio Track/) {
		return 31;
	}elsif($veids =~ m/Documentary/) {
		return 32;
	}elsif($veids =~ m/Misc\/Demo/) {
		return 37;
	}elsif($veids =~ m/Movie/) {
		return 37;
	}elsif($veids =~ m/Music/) {
		return 19;
	}elsif($veids =~ m/Sport/) {
		return 23;
	}elsif($veids =~ m/TV/) {
		return 35;
	}elsif($veids =~ m/XXX/) {
		return 9;
	}
	return 0;
}

sub cat_id_fro_fano{
	my $veids=shift;
	if($veids =~ m/(720p|1080p|1080i)/){
		return 35;
	}
	return 6;
}

# Linkomanija category converter
sub cat_id_ln_fano{
	my $veids=shift;
	my %cat=(
		"Movies XviD" => 20,
		"DVD" => 4,
		"TV" => 6,
		"Music" => 5,
		"PC Games" => 7,
		"Documentaries" => 32,
		"Books" => 41,
		"Misc" => 22,
		"Movies LT" => 20,
		"DVD LT" => 4,
		"TV LT" => 6,
		"Music LT" => 5,
		"XBOX" => 34,
		"Sports" => 23,
		"Books LT" => 41,
		"Misc LT" => 22,
		"Movies RU" => 17,
		"HDTV" => 37,
		"Appz" => 1,
		"Music Videos" => 19,
		"Consoles" => 43,
		"Anime" => 27,
		"MAC" => 22,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_tv_fano{
	my $veids=shift;
	my %cat=(
		"Appz/0DAY" => 22,
		"Appz/Mac" => 22,
		"Appz/PC-ISO" => 1,
		"BlurayTV" => 35,
		"Documentaries" => 6,
		"Ebooks" => 22,
		"Episodes/TV-Boxset" => 6,
		"Episodes/TV-x264" => 35,
		"Episodes/TV-XviD" => 6,
		"Episodes/TV-Foreign" => 6,
		"Games/Misc" => 7,
		"Games/NDS" => 28,
		"Games/PC-ISO" => 7,
		"Games/PS2" => 21,
		"Games/PSP" => 7,
		"Games/Wii" => 34,
		"Game/Packs" => 7,
		"Games/X360" => 34,
		"Movies/MDVDR" => 19,
		"Movies/Boxsets" => 20,
		"Movies/DVDR" => 4,
		"Movies/x264" => 37,
		"Movies/XviD" => 20,
		"Movies/Foreign" => 20,
		"Music/MP3" => 5,
		"Music/Videos" => 19,
		"Requests" => 22,
		"Packs/0DAY" => 22,
		"Packs/Ebooks" => 22,
		"Packs/Music" => 5,
		"Retro/Music" => 5,
		"Episodes/TV-DVDR" => 4
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_gft_fano{
	my $veids=shift;
	my %cat=(
		"APPS" => 22,
		"0DAY" => 22,
		"XXX-XVID" => 9,
		"TV-XVID" => 6,
		"Music" => 5,
		"Games/PC" => 7,
		"Movies-XVID" => 20,
		"Movies-DVDR" => 4,
		"E-Learning" => 22,
		"Misc" => 22,
		"Games/XBOX360" => 34,
		"MVID" => 19,
		"GFT Gems" => 22,
		"Anime" => 27,
		"TV-X264" => 35,
		"Movies-X264" => 37,
		"Movies/XviD" => 20,
		"TV-DVDRIP" => 6,
		"XXX-HD" => 9,
		"XXX-0DAY" => 9,
		"Games/WII" => 34,
		"XXX-DVDR" => 9,
		"Portable/Mobile/PDA" => 22,
		"MAC" => 22,
		"Games/PSP" => 28,
		"Games/NDS" => 28
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}


sub cat_id_rtt_fano{
	my $veids=shift;
	my %cat=(
		"Anime" => 27,
		"Apps/Misc" => 22,
		"Appz/PC-ISO" => 1,
		"E-Book" => 22,
		"Games/PC-ISO" => 7,
		"Games/PC-Rips" => 12,
		"Games/PS2" => 43,
		"Games/PS3" => 43,
		"Games/Wii" => 40,
		"Games/XBOX360" => 34,
		"Handheld/PSP" => 39,
		"Mac" => 22,
		"Movies/DVDR" => 4,
		"Movies/Packs" => 20,
		"Movies/WMV" => 20,
		"Movies/x264" => 37,
		"Movies/XviD" => 20,
		"Music" => 5,
		"Music/Packs" => 5,
		"MusicVideos" => 19,
		"TV/DVDR" => 6,
		"TV/HR" => 35,
		"TV/Packs" => 6,
		"TV/x264" => 35,
		"TV/XViD" => 6,
		"XXX" => 9,
		"XXX/DVDR" => 9,
		"XXX/HD" => 9
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_scc_fano{
	my $veids=shift;
	my %cat=(
		"Dox" => 22,
		"Apps" => 1,
		"Games/PC" => 7,
		"Games/PS2" => 43,
		"Games/PS3" => 43,
		"Games/WII" => 40,
		"Games/XBOX" => 34,
		"Games/XBOX360" => 34,
		"MiSC" => 22,
		"Movies/DVDR" => 4,
		"Movies/VCD" => 20,
		"Movies/X264" => 37,
		"Movies/XviD" => 20,
		"TV/DVDR" => 6,
		"TV/X264" => 35,
		"TV/XviD" => 6,
		"XXX/XviD" => 9,
		"0DAY" => 22,
		"MP3" => 5,
		"MVID" => 19
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_tl_fano{
	my $veids=shift;
	my %cat=(
		"Cam" => 20,
		"TS/TC" => 20,
		"R5/Screeners" => 20,
		"DVDRip/DVDScreener" => 20,
		"DVD-R" => 4,
		"HD" => 37,
		"BDRip" => 20,
		"Boxsets" => 20,
		"Documentaries" => 32,
		"Episodes" => 6,
		"PC" => 7,
		"XBOX" => 34,
		"XBOX360" => 34,
		"PS2" => 43,
		"PS3" => 43,
		"PSP" => 39,
		"Wii" => 40,
		"Nintendo DS" => 22,
		"Music Videos" => 19,
		"Audio" => 5,
		"Anime" => 27,
		"Books" => 41,
		"PC-ISO" => 1,
		"Mac" => 22,
		"PDA" => 22,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

# IPTorrents category converter
sub cat_id_ipt_fano{
	my $veids=shift;
	my %cat=(
		"Anime" => 27,
		"Appz/misc" => 22,
		"AudioBook" => 44,
		"Books - Mags" => 41,
		"Games / Mixed" => 7,
		"Games/Nintendo DS" => 12,
		"Games/PC ISO" => 7,
		"Games/PC Rips" => 12,
		"Games/PS2" => 43,
		"Games/PSP" => 39,
		"Games/PSX" => 39,
		"Games/Wii" => 40,
		"Games/XBOX" => 34,
		"Games/XBOX360" => 34,
		"HD/X264" => 37,
		"iPod/Movies" => 38,
		"iPod/TV" => 38,
		"Kids" => 29,
		"MAC" => 22,
		"Mobile" => 38,
		"Movies/DVD-R" => 4,
		"Movies/FLAWL3SS" => 20,
		"Movies/Non-English" => 20,
		"Movies/Packs" => 20,
		"Movies/XviD" => 20,
		"Music > Video" => 19,
		"Music/Audio" => 5,
		"Pics/Wallpapers" => 22,
		"Sports" => 23,
		"TV > Episodes" => 6,
		"TV/Packs" => 6,
		"XXX" => 9
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

# BitmeTV category converter
sub cat_id_btv_fano{
	return 6; # TV category for fano
}

1;
