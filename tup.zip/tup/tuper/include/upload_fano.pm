require "include/upload_fano.config.pm";

sub upload_fano{

	my $name=shift; # Torrent name from database
	my $category=shift; # Category ID
	my $description=shift; # Description file path
	my $torrent=shift;  # Torrent file path
	my $nfo=shift; # NFO file path
	my $to_tracker=shift; # tracker code (for example: fano)
	my $defname=shift; # Filename from database
	my $defhash=shift; # Download torrent file info hash
	my $config=shift;

	#use ClientFunctions;
	my $r=ClientFunctions->new('upload', 'fano', $config);

	my $descr_txt=$r->read_file($description);

	#if($descr_txt eq $config->{tuper}->{no_descr_txt}){
	#	$r->err("Empty description, using original NFO instead.");
	#	$descr_txt=$r->read_file($nfo);
	#}

	###################################
	# Upload torrent
	$r->form_new;
	# Form fields passed to upload script
	$r->form_add('anonymous', '1');
    $r->form_add('samehash', '1');
    $r->form_add('autobot', '1');

	$r->form_add('type', $category);
	$r->form_add('name', $name);
	$r->form_add('descr', $descr_txt);

	# Form files passed to upload script
	return 0 if(not $r->form_add_file('file', $torrent, "multipart/form-data"));
	return 0 if(not $r->form_add_file('nfo', $nfo, "multipart/form-data"));

	# POSTing data to upload script
	my $eh=$r->post("http://www.fano.lv/takeupload.php");
	return 0 if($eh==0);
#$r->err($r->{curldat});
	###################################
	# Search for nologin
	my $match_nologin=qr/<b><a href="recover.php">/ms;
	my $nologin_matches=$r->match('nologin', $match_nologin);
	if($nologin_matches!=0){ $r->err('Can not continue without login, aborting!'); return 0;}

	###################################
	# Search for already uploaded
	my $match_uploaded=qr/<p>torrent already uploaded!<\/p>/ms;
	my $uploaded_matches=$r->match('already uploaded', $match_uploaded);
	if($uploaded_matches!=0){ $r->err('Torrent already uploaded, aborting!'); return 2;}

	###################################
	# Search for wrong announce url
	#my $match_announce=qr/<p>invalid announce url! must be/ms;
	#my $announce_matches=$r->match('anounce error', $match_announce);
	#if($announce_matches!=0){ $r->err('Wrong announce URL, aborting!'); return 0;}

	###################################
	# Search for torrent id
	my $match_torrentid=qr/<\/td><td width=\'99%\' align=\'left\'><a class=\'index\' href=\'download.php\?id=(.*)&amp;name=(.*).torrent\'>(.*)<\/a>&nbsp;&nbsp;&nbsp;/ms;
	my $torrentid_matches=$r->match('torrent id', $match_torrentid);
	if($torrentid_matches==0){ $r->err('Can not continue without torrent ID, aborting!'); return 0;}
	my $torrentid=@$torrentid_matches[0];
	$r->err("Torrent ID: $torrentid");

	###################################
	# Request torrent file
	$eh=$r->get("http://www.fano.lv/download.php?id=".$torrentid."&name=torrent.torrent");
	return 0 if($eh==0);

	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or ($file_type ne lc"application/x-bittorrent" or $file_type ne lc"application/vnd.torrent")){ $r->err("Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('Can not continue without infohash, aborting!'); return 0; }
	$r->err('Downloaded file infohash: '.$down_hash);
	my $newtorr=$r->{curldat};

	###################################
	# Remove hashcheck
	#$newtorr=$r->remove_hashcheck($config->{paths}->{upload_dir}, $newtorr);
	#return 0 if($newtorr eq 0);

	###################################
	# Write torrent file
	my $torr_file=$config->{paths}->{watch2_dir}."[".uc($to_tracker)."]".$defname.".torrent";
	if($r->write_file('torrent', $torr_file, $newtorr)==0){ return 0; }

	my %retvals=(
		"id" => $torrentid,
		"hash" => $down_hash,
	);
	return \%retvals;

}
=pod
sub update_fano{

	my ($id, @images) = @_;

	my $curl = new WWW::Curl::Easy;
	my $response_details;
	# windows check
	$curl->setopt(CURLOPT_WRITEFUNCTION, \&curl_write_data);
	my @curl_headers=('Expect:');
	$curl->setopt(CURLOPT_HTTPHEADER, \@curl_headers);
	$curl->setopt(CURLOPT_FOLLOWLOCATION, 1);
	$curl->setopt(CURLOPT_RETURNTRANSFER, 1);
	$curl->setopt(CURLOPT_SSL_VERIFYPEER, 0);
	$curl->setopt(CURLOPT_SSL_VERIFYHOST, 1);
	$curl->setopt(CURLOPT_TIMEOUT, 60);
	$curl->setopt(CURLOPT_VERBOSE, 0);
	$curl->setopt(CURLOPT_COOKIE, $cookie_fano);
	if($upload_ip ne ""){
		$curl->setopt(CURLOPT_INTERFACE, $upload_ip);
	}

	my $edit_page="http://fano.lv/edit.php?id=".$id;
	$curl->setopt(CURLOPT_URL, $edit_page);
	err('	Requesting edit page: '.$edit_page);
	&request_page($curl, 0);
	##########
	$response_details = $curldat;
	$curldat=""; # clean curldat

	my $match_old = qr/<input type='text' name='name' value="(.*?)" size='80' \/>(.*)<textarea name='descr' rows='10' cols='80'>(.*?)<\/textarea>(.*)<option value='([0-9]*)' selected='selected'>(.*?)<\/option>(.*)<input type='checkbox' name='latsubs' (checked='checked' )?value='1' \/>/ms;
	my $match_ok = qr/<h1>Description updated<\/h1>/ms;

	if($response_details !~ $match_old){
		err("	Failed to match old data.");
		abort("Failed to match old data.", 1);
		$retvalz=2;
	}else{
		err("	Matched old message.");
		err("	Adding images: ".join("\n			", @images));
		my $final=join(" ", @images)."\n".$3;
		my $curlf = WWW::Curl::Form->new;
		$curlf->curl_formadd("descr", $final);
		$curlf->curl_formadd("id", $id);
		$curl->setopt(CURLOPT_HTTPPOST, $curlf);

		my $edit_page="http://www.fano.lv/updatedescr.php";
		$curl->setopt(CURLOPT_URL, $edit_page);
		err('	Posting updated data to page: '.$edit_page);
		&request_page($curl, 0);
		##########
		$response_details = $curldat;
		$curldat=""; # clean curldat
#print $response_details;
		if($response_details =~ $match_ok){
			err("	Updated successfully!");
			return 1;
		}else{
			err("	Failed to match success message.");
			abort("Failed to match success message.", 1);
			$retvalz=2;
			return 2;
		}
	}
}
=cut
1;
