sub download_fbn {

	$tid=shift;
	$config=shift;

	#use ClientFunctions;
	my $r=ClientFunctions->new('download', 'fbn', $config);

	###################################
	# Request page
	my $eh=$r->get("http://www.filmbits.net/details.php?id=".$tid);
	return 0 if($eh==0);

	###################################
	# Search for nologin
	my $match_nologin=qr/<form method='post' action='takelogin.php'>/ms;
	my $nologin_matches=$r->match('nologin', $match_nologin);
	if($nologin_matches!=0){ $r->err('Can not continue without login, aborting!'); return 0;}

	###################################
	# Search for notorrent
	my $match_notorrent=qr/No torrent with ID (.*?).<\/td></m;
	my $notorrent_matches=$r->match('notorrent', $match_notorrent);
	if($notorrent_matches!=0){ $r->err('Can not continue without torrent, aborting!'); return 0;}

	###################################
	# Search for name
	my $match_name=qr/'><h1>(.*?)<\/h1>/ms;
	my $name_matches=$r->match('name', $match_name);
	if($name_matches==0){ $r->err('Can not continue without name, aborting!'); return 0;}
	my $name=@$name_matches[0];
	my $filename=$name;
	$r->err("Name: $name");
    $r->err("Filename: $filename");

	###################################
	# Search for category
	my $match_category=qr/Type<\/td><td valign='top' align='left'>(.*?)<\/td><\/tr>/ms;
	my $category_matches=$r->match('category', $match_category);
	if($category_matches==0){ $r->err('Can not continue without category, aborting!'); return 0;}
	my $category=$r->html_unescape(@$category_matches[0]);
	$r->err("Category: $category...");

	###################################
	# Search for description
	my $match_description1=qr/Description<\/td><td>(.*?)<\/td><\/tr>/ms;
	my $match_description2=qr/<tr><td class="heading" valign="top" align="right">Description<\/td><td valign="top" align=left><a href="javascript:klappe_news(\'a3\')"><img src="pic\/plus.gif" id="pica3" alt="Show\/Hide" border="0"><\/a> [Show\/Hide]<div id="ka3" style="display: none;"><br><br>(.*)<\/td><\/tr>\n<tr><td class="heading" valign="top" align="right">Type/ms;
	my $description_matches=$r->match('description', $match_description1);
	my $description;
	if ($description_matches==0){$description_matches=$r->match('description', $match_description2);
		if($description_matches==0){ $r->err('No description found, using default one'); $description=$config->{tuper}->{no_descr_txt}; }
		else{ $description=@$description_matches[1]; }
	}
	else{ $description=@$description_matches[0]; }

	###################################
	# Request torrent page
	$eh=$r->get("http://www.filmbits.net/download.php?torrent=".$tid);
	return 0 if($eh==0);

	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('Can not continue without infohash, aborting!'); return 0; }
	$r->err('Downloaded file infohash: '.$down_hash);
	$torrent=$r->{curldat};

	###################################
	# Stripping html from description and converting some of it to bbcode
	if($description ne $config->{tuper}->{no_descr_txt}){ $description=$r->strip_description($description); }

	###################################
	# Writing files
	# Write NFO file
	my $nfo_file=$config->{paths}->{temp_dir}.$filename.".nfo";
	if($r->write_file('nfo', $nfo_file, $description)==0){ return 0; }
	# Wrtie description file
	my $descr_file=$config->{paths}->{temp_dir}.$filename.".txt";
	if($r->write_file('description', $descr_file, $description)==0){ return 0; }
	# Write torrent file
	my $torr_file=$config->{paths}->{temp_dir}.$filename.".torrent";
	if($r->write_file('torrent', $torr_file, $torrent)==0){ return 0; }

	my %retvals=(
		"name" => $name,
		"descr" => $description,
		"filename" => $filename,
		"category" => $category,
		"nfo_file" => $nfo_file,
		"descr_file" =>  $descr_file,
		"torrent_data" => $torrent,
		"down_hash" => $down_hash,
	);
	return \%retvals;

}

1;
