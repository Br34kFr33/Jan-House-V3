require "include/upload_db.config.pm";

sub upload_db {

	my $name=shift; # Torrent name from database
	my $category=shift; # Category ID
	my $description=shift; # Description file path
	my $torrent=shift;  # Torrent file path
	my $nfo=shift; # NFO file path
	my $to_tracker=shift; # tracker code (for example: fano)
	my $defname=shift; # Filename from database
	my $defhash=shift; # Download torrent file info hash
	my $config=shift;

	my $r=ClientFunctions->new('upload', 'db', $config);

	my $passkey=$config->{cookies}->{passkey_db};
	
	###################################
	# Search for original NFO that comes with torrent
	$nfo=$r->find_nfo($torrent, $nfo, $config->{paths}->{download_dir});

	###################################
	# Requesting upload page before sending POST data
	# This should be used to bypass some session verification checks
	my $eh=$r->get("https://danishbits.org/upload.php");
	return 0 if($eh==0);

	###################################
	# Search for nologin
	my $match_nologin=qr/<form id="loginform" method="post" action="login.php">/ms;
    my $nologin_matches=$r->match('nologin', $match_nologin);
    if($nologin_matches!=0 and not defined $config->{cookies}->{cookie_db}){
        $r->err('Can not continue without login, trying to login!');
        $r->form_new;
        $r->form_add('keeplogged', '1');
        $r->form_add('login', 'Login');
        $r->form_add('username', $config->{cookies}->{user_db});
        $r->form_add('password', $config->{cookies}->{pass_db});
        $eh=$r->post("https://danishbits.org/login.php");
        return 0 if($eh==0);
        $nologin_matches=$r->match('nologin', $match_nologin);
        if($nologin_matches!=0){
                $r->err('Can not continue without login, aborting!');
                return 0;
        }
        $eh=$r->get("https://danishbits.org/upload.php");
        return 0 if($eh==0);
    }elsif($nologin_matches!=0){
        $r->err('Can not continue without login, aborting!');
        return 0;
    }

	###################################
	# Search for auth key
	my $match_key=qr/var authkey = "(.*?)";/ms;
	my $key_matches=$r->match('auth key', $match_key);
	if($key_matches==0){ $r->err('	Can not continue without auth key, aborting!'); return 0;}
	my $key=@$key_matches[0];
	$r->err("	Key: $key");

	# Read description	
    my $descr_txt=$r->read_file($description);
    if($descr_txt eq $config->{tuper}->{no_descr_txt}){
        $descr_txt=$r->read_file($nfo);
    }
	
	###################################
	# Upload torrent
	$r->form_new;
	# Form fields passed to upload script
	
	# Match IMDB URL
	my $match_imdb=qr/imdb.com\/title\/tt([0-9]*)/ms; 
        my $imdb=""; 
        if($descr_txt =~ $match_imdb){
                $imdb="http://www.imdb.com/title/tt".$1."/"; 
                $r->err("Found IMDB link: ".$imdb); 
        }
	$r->form_add('imdb', $imdb);
	$r->form_add('submit', 'true');
	$r->form_add('auth', '');
	$r->form_add('youtube', '');	
	$r->form_add('tags', '');
	$r->form_add('freeleechtype', '0');
	$r->form_add('type', &db_cats($category));
	$r->form_add('title', $name);
	$r->form_add('release_desc', $descr_txt);

	# Form files passed to upload script
	return 0 if(not $r->form_add_file('file_input', $torrent, "application/x-bittorrent"));
	return 0 if(not $r->form_add_file('nfo', $nfo, "text/plain"));

	# POSTing data to upload script
	$eh=$r->post("https://danishbits.org/upload.php");
	return 0 if($eh==0);

	###################################
    # Search for weird errors
    my $match_errors=qr/^<center><font color='red'>(.*?)<\/font><\/center>$/ms;
    my $errors_matches=$r->match('upload errors', $match_errors);
    if($errors_matches!=0){ $r->err('	Matched some error message, aborting: '.@$errors_matches[0], 'red'); return 0; }

	my $torrentid=0;
    ###################################
    # Search for already uploaded
    my $match_uploaded=qr/<a href="torrents.php\?torrentid=(.*?)">The exact same torrent file already exists on the site/ms;
    my $uploaded_matches=$r->match('uploaded', $match_uploaded);
    if($uploaded_matches!=0){ 
		$r->err('	Torrent already uploaded, but will add it for seeding!');
		$torrentid=@$uploaded_matches[0];
		$r->err("	Existing torrent ID: $torrentid");
	}else{
#$r->err($r->{curldat});
		###################################
		# Search for torrent id
		my $match_torrentid=qr/<a href="torrents.php\/.*?.torrent\?action=download.amp;id=(.*?).amp;authkey=(.*?)&amp;torrent_pass=(.*?)" title="Download">DL<\/a>|<a href="torrents.php\?id=(.*?)">/ms;
		my $torrentid_matches=$r->match('torrent id', $match_torrentid);
		if($torrentid_matches==0){ $r->err('	Can not continue without torrent ID, aborting!'); return 0;}
		$torrentid=@$torrentid_matches[0];
		$r->err("	Torrent ID: $torrentid");
	}
	
	###################################
	# Request torrent file
	my $eh=$r->get("https://danishbits.org/torrents.php/some.torrent?action=download&id=".$torrentid."&authkey=".$key."&torrent_pass=".$passkey);
	return 0 if($eh==0);

	
	
	
	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("	Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('	Can not continue without infohash, aborting!'); return 0; }
	$r->err('	Downloaded file infohash: '.$down_hash);
	my $newtorr=$r->{curldat};

	#$newtorr=$r->remove_hashcheck($config->{paths}->{upload_dir}, $newtorr);
	#return 0 if($newtorr eq 0);

	###################################
	# Write torrent file
	my $torr_file=$config->{paths}->{watch2_dir}."[".uc($to_tracker)."]".$defname.".torrent";
	if($r->write_file('torrent', $torr_file, $newtorr)==0){ return 0; }

	my %retvals=(
		"id" => $torrentid,
		"hash" => $down_hash,
	);
	return \%retvals;

}
1;
