require "include/upload_dtn.config.pm";

sub upload_dtn {

	my $name=shift; # Torrent name from database
	my $category=shift; # Category ID
	my $description=shift; # Description file path
	my $torrent=shift;  # Torrent file path
	my $nfo=shift; # NFO file path
	my $to_tracker=shift; # tracker code (for example: fano)
	my $defname=shift; # Filename from database
	my $defhash=shift; # Download torrent file info hash
	my $config=shift;

	#use ClientFunctions;
	my $r=ClientFunctions->new('upload', 'dtn', $config);

	###################################
	# Search for original NFO that comes with torrent
	$nfo=$r->find_nfo($torrent, $nfo, $config->{paths}->{download_dir});

	###################################
	# Requesting upload page before sending POST data
	# This should be used to bypass some session verification checks
	my $eh=$r->get("http://dispersethe.net/upload.php");
	return 0 if($eh==0);

	###################################
	# Search for nologin
	my $match_nologin=qr/type="submit" value="LOGIN"/ms;
	my $nologin_matches=$r->match('nologin', $match_nologin);
	if($nologin_matches!=0){ $r->err('Can not continue without login, aborting!'); return 0;}

	###################################
	# Duplicate torrent check
	$r->form_new;
	$r->form_add('do', 'search');
	$r->form_add('value', $name);
	# POSTing data to upload script
	$eh=$r->post("http://dispersethe.net/ts_ajax9.php");
	if($eh==0){ $r->err("Failed to check if torrent with the same name exists."); }

	my $torrentid;

	###################################
	# Search for existing id
	my $match_existing=qr/https?:\/\/dispersethe.net\/details.php\?id=(.*?)"/ms;
	my $existing_matches=$r->match('existing id', $match_existing);
	if($existing_matches!=0){ # Exists - downloading existing on

		$torrentid=@$existing_matches[0];
		$r->err("Existing torrent ID: $torrentid");

	}else{ # Does not exist - upload new one

		my $descr_txt=$r->read_file($description);

		if($descr_txt eq $config->{tuper}->{no_descr_txt}){
			$r->err("Empty description, using original NFO instead.");
			$descr_txt=$r->read_file($nfo);
		}

		###################################
		# Upload torrent
		$r->form_new;
		# Form fields passed to upload script
		$r->form_add('autopretime', 'yes');
		$r->form_add('anonymous', 'yes');
		$r->form_add('offensive', '');
		$r->form_add('isScene', '');
		$r->form_add('submit', 'Upload Torrent');
		$r->form_add('isrequest', '');

			# Match IMDB URL
  		my $match_imdb=qr/imdb.com\/title\/tt([0-9]*)/ms; 
        my $imdb=""; 
        if($descr_txt =~ $match_imdb){
                $imdb="http://www.imdb.com/title/tt".$1."/"; 
                $r->err("Found IMDB link: ".$imdb); 
        }
		$r->form_add('t_link', $imdb);
		$r->form_add('t_image_file', '');
		$r->form_add('t_image_url', '');
		$r->form_add('nothingtopost', '1');
		$r->form_add('category', $category);
		$r->form_add('subject', $name);
		$r->form_add('message', $descr_txt);

		# Form files passed to upload script
		return 0 if(not $r->form_add_file('torrentfile', $torrent, "application/x-bittorrent"));
		return 0 if(not $r->form_add_file('nfofile', $nfo, "multipart/form-data"));

		# POSTing data to upload script
		my $eh=$r->post("http://dispersethe.net/upload.php");
		return 0 if($eh==0);

		###################################
		# Search for torrent id
		my $match_torrentid=qr/reseedid=(.*?)><b>here<\/b><\/a>/ms;
		my $torrentid_matches=$r->match('torrent id', $match_torrentid);
		if($torrentid_matches==0){ $r->err('Can not continue without torrent ID, aborting!'); return 0;}
		$torrentid=@$torrentid_matches[0];
		$r->err("Torrent ID: $torrentid");

	}

	###################################
	# Request torrent file
	$eh=$r->get("http://dispersethe.net/download.php?id=".$torrentid);
	return 0 if($eh==0);

	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('Can not continue without infohash, aborting!'); return 0; }
	$r->err('Downloaded file infohash: '.$down_hash);
	my $newtorr=$r->{curldat};

	##################################
	# If existed - compare info hashes
	#if($existing_matches!=0 and $down_hash ne $defhash){ $r->err("Downloaded and stored file info hashes don't match, aborting!"); return 0; }
	#elsif($existing_matches!=0){ $r->err("Info hashes match, can add for seeding."); }
	if($config->{tuper}->{rem_hashcheck}==1){
		$newtorr=$r->remove_hashcheck($config->{paths}->{upload_dir}, $newtorr);
		return 0 if($newtorr eq 0);
	}

	###################################
	# Write torrent file
	my $torr_file=$config->{paths}->{watch2_dir}."[".uc($to_tracker)."]".$defname.".torrent";
	if($r->write_file('torrent', $torr_file, $newtorr)==0){ return 0; }

	my %retvals=(
		"id" => $torrentid,
		"hash" => $down_hash,
	);
	return \%retvals;

}
1;
