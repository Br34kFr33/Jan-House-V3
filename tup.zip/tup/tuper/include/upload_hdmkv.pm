require "include/upload_hdmkv.config.pm";

sub in_array {
    my ($arr, $search_for) = @_;
    foreach(@$arr) {
        return 1 if $_ eq $search_for;
    }
    return 0;
}


sub upload_hdmkv {

	my $name=shift; # Torrent name from database
	my $category=shift; # Category ID
	my $description=shift; # Description file path
	my $torrent=shift;  # Torrent file path
	my $nfo=shift; # NFO file path
	my $to_tracker=shift; # tracker code (for example: fano)
	my $defname=shift; # Filename from database
	my $defhash=shift; # Download torrent file info hash
	my $config=shift;

	my $r=ClientFunctions->new('upload', 'hdmkv', $config);

	###################################
	# Requesting upload page before sending POST data
	# This should be used to bypass some session verification checks
	my $eh=$r->get("http://hd-mkv.me/index.php?page=upload");
	return 0 if($eh==0);

	###################################
	# Search for nologin
	my $match_nologin=qr/<form action="index.php\?page=login" name="login" method="post">/ms;
	my $nologin_matches=$r->match('nologin', $match_nologin);
	if($nologin_matches!=0 and not defined $config->{cookies}->{cookie_hdmkv}){
        $r->err('Can not continue without login, trying to login!');
        $r->form_new;
        $r->form_add('uid', $config->{cookies}->{user_hdmkv});
        $r->form_add('pwd', $config->{cookies}->{pass_hdmkv});
        $eh=$r->post("http://hd-mkv.me/index.php?page=login");
        return 0 if($eh==0);
        $nologin_matches=$r->match('nologin', $match_nologin);
        if($nologin_matches!=0){
                $r->err('Can not continue without login, aborting!');
                return 0;
        }
	        $eh=$r->get("http://hd-mkv.me/index.php?page=upload");
	        return 0 if($eh==0);
	}elsif($nologin_matches!=0){
		$r->err('Can not continue without login, aborting!');
		return 0;
	}

	###################################
	# Search for original NFO that comes with torrent
	$nfo=$r->find_nfo($torrent, $nfo, $config->{paths}->{download_dir});
    # Read description	
    my $descr_txt=$r->read_file($description);
    if($descr_txt eq $config->{tuper}->{no_descr_txt}){
        $descr_txt=$r->read_file($nfo);
    }

# Categories that contain videos
#my @extractlist=(54, 55, 16, 58, 11, 42, 50);
# Extract only from video categories
#if(in_array(\@extractlist, $category)){
    my $rartorr=$r->rarextract($torrent, $defname, 0, 0, 0, 0);
    $torrent=$rartorr;
#}


#Movies
if($category==1){
        if($name =~ m/1080p/i) {
                $category=2;
        }
}


	###################################
	# Upload torrent
	$r->form_new;
	# Form fields passed to upload script
	$r->form_add('user_id', '');
	$r->form_add('videoalignment', '');
	$r->form_add('videotype', '');
	$r->form_add('fontchange', '');
	$r->form_add('scroll', '');	
	$r->form_add('anonymous', 'false');
	$r->form_add('req', 'false');
	$r->form_add('nuk', 'false');
	$r->form_add('nuk_rea', '');
	#$r->form_add('gold', '0');
	#$r->form_add('moder', 'ok');
	# Match IMDB URL
	my $match_imdb=qr/imdb.com\/title\/tt([0-9]*)/ms; 
        my $imdb=""; 
        if($descr_txt =~ $match_imdb){
                $imdb=$1; #"http://www.imdb.com/title/tt".$1."/"; 
                $r->err("Found IMDB link: ".$imdb); 
        }
	$r->form_add('imdb', $imdb);
	$r->form_add('category', $category);
	$r->form_add('filename', $name);
	$r->form_add('info', $descr_txt);

	# Form files passed to upload script
	return 0 if(not $r->form_add_file('torrent', $torrent, "application/x-bittorrent"));
	return 0 if(not $r->form_add_file('nfo', $nfo, "text/plain"));

	# POSTing data to upload script
	$eh=$r->post("http://hd-mkv.me/index.php?page=upload");
	return 0 if($eh==0);
#$r->err($r->{curldat});
    ###################################
    # Search for already uploaded
    my $match_uploaded=qr/This torrent may already exist in our database./ms;
    my $uploaded_matches=$r->match('uploaded', $match_uploaded);
    if($uploaded_matches!=0){ $r->err('	Torrent already uploaded, aborting!'); return 0;}

	###################################
	# Search for torrent id
	my $match_torrentid=qr/<a href="download.php\?id=(.*?)&(amp;)?f=(.*?).torrent/ms;
	my $torrentid_matches=$r->match('torrent id', $match_torrentid);
	if($torrentid_matches==0){ $r->err('	Can not continue without torrent ID, aborting!'); return 0;}
	my $torrentid=@$torrentid_matches[0];
	my $downkey=@$torrentid_matches[2];
	$r->err("Torrent ID: $torrentid");

	###################################
	# Request torrent file
	my $eh=$r->get("http://hd-mkv.me/download.php?id=".$torrentid."&f=some.torrent&key=".$downkey);
	return 0 if($eh==0);

	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("	Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('	Can not continue without infohash, aborting!'); return 0; }
	$r->err('Downloaded file infohash: '.$down_hash);
	my $newtorr=$r->{curldat};

	$newtorr=$r->remove_hashcheck($config->{paths}->{upload_dir}, $newtorr);
	return 0 if($newtorr eq 0);

	###################################
	# Write torrent file
	my $torr_file=$config->{paths}->{watch2_dir}."[".uc($to_tracker)."]".$defname.".torrent";
	if($r->write_file('torrent', $torr_file, $newtorr)==0){ return 0; }

	my %retvals=(
		"id" => $torrentid,
		"hash" => $down_hash,
	);
	return \%retvals;

}
1;
