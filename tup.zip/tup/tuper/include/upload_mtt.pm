require "include/upload_mtt.config.pm";

sub upload_mtt {

	my $name=shift; # Torrent name from database
	my $category=shift; # Category ID
	my $description=shift; # Description file path
	my $torrent=shift;  # Torrent file path
	my $nfo=shift; # NFO file path
	my $to_tracker=shift; # tracker code (for example: fano)
	my $defname=shift; # Filename from database
	my $defhash=shift; # Download torrent file info hash
	my $config=shift;

	my $r=ClientFunctions->new('upload', 'mtt', $config);

	###################################
	# Search for original NFO that comes with torrent
	$nfo=$r->find_nfo($torrent, $nfo, $config->{paths}->{download_dir});

	###################################
	# Request page
	my $eh=$r->get("http://www.mytorrent.tv/tracker/upload.php");
	return 0 if($eh==0);

	###################################
	# Search for nologin
	my $match_nologin=qr/<\/p><form method="post" action="\/tracker\/login.php">/ms;
        my $nologin_matches=$r->match('nologin', $match_nologin);
        if($nologin_matches!=0){
                $r->err('       Can not continue without login, trying to login!');
                #return 0;
                $r->form_new;
                $r->form_add('username', $config->{cookies}->{user_mtt});
                $r->form_add('password', $config->{cookies}->{pass_mtt});
                $eh=$r->post("http://www.mytorrent.tv/tracker/login.php");
                return 0 if($eh==0);
                $nologin_matches=$r->match('nologin', $match_nologin);
                if($nologin_matches!=0){
                        $r->err('Can not continue without login, aborting!');
                        return 0;
                }
            	$eh=$r->get("http://www.mytorrent.tv/tracker/upload.php");
                return 0 if($eh==0);
        }

	###################################
    # Read description	
    my $descr_txt=$r->read_file($description);
    if($descr_txt eq $config->{tuper}->{no_descr_txt}){
        $descr_txt=$r->read_file($nfo);
    }

	# Parse NFO
	$r->form_new;
	return 0 if(not $r->form_add_file('nfo', $nfo, "application/x-bittorrent"));
	$eh=$r->post("http://www.mytorrent.tv/tracker/parsenfo.php");
	return 0 if($eh==0);
	# Search for parsed nfo
	my $match_pnfo=qr/parent.document.upload.descr.value = "(.*?)\n";/ms;
	my $pnfo_matches=$r->match('parsed nfo', $match_pnfo);
	if($pnfo_matches==0){ 
		$descr_txt=$config->{tuper}->{no_descr_txt};
	}else{
		$descr_txt=@$pnfo_matches[0];
		$descr_txt =~ s/\\n\\/\n/g;
	}
	
	###################################
	# Upload torrent
	$r->form_new;
	# Form fields passed to upload script
	$r->form_add('anonymous', '1');	
	
	$r->form_add('poster', '');

	if($category == 51 or $category == 24){
		my $match_genre1=qr/^\[(.*?)\]/ms; 
		if($name =~ $match_genre1){
			$r->form_add('music_genre', $1);
			$r->err("Music genre: $1");
			$name =~ s/^(\[.*?\]\s?)//;
			$r->err("New name: $name");
		}else{
			$r->form_add('music_genre', 'MTT');
		}
		
	}else{
		$r->form_add('music_genre', '');
	}
	
	# Match IMDB URL
	my $match_imdb=qr/imdb.com\/title\/tt([0-9]*)/ms; 
        my $imdb=""; 
        if($descr_txt =~ $match_imdb){
                $imdb="http://www.imdb.com/title/tt".$1."/"; 
                $r->err("Found IMDB link: ".$imdb); 
        }
	$r->form_add('description', ''); #genre/mini descr
	$r->form_add('imdb', $imdb);
	$r->form_add('type', $category);
	$r->form_add('name', $name);
	$r->form_add('descr', $descr_txt);

	# Form files passed to upload script
	return 0 if(not $r->form_add_file('file', $torrent, "application/x-bittorrent"));
	return 0 if(not $r->form_add_file('nfo', $nfo, "text/plain"));
	$r->form_add_file('pfile', "$nfo", "text/plain");

	# POSTing data to upload script
	$eh=$r->post("http://www.mytorrent.tv/tracker/takeupload.php");
	return 0 if($eh==0);
	#$r->err($r->{curldat});
    ###################################
    # Search for already uploaded
    my $match_uploaded=qr/<p>Dieser Torrent wurde bereits hochgeladen/ms;
    my $uploaded_matches=$r->match('uploaded', $match_uploaded);
    if($uploaded_matches!=0){ $r->err('	Torrent already uploaded, aborting!'); return 0;}

	###################################
	# Search for torrent id
	my $match_torrentid=qr/href="download.php\/(.*?)\//ms;
	my $torrentid_matches=$r->match('torrent id', $match_torrentid);
	if($torrentid_matches==0){ $r->err('	Can not continue without torrent ID, aborting!'); return 0;}
	my $torrentid=@$torrentid_matches[0];
	$r->err("	Torrent ID: $torrentid");

	###################################
	# Request torrent file
	my $eh=$r->get("http://www.mytorrent.tv/tracker/download.php/".$torrentid."/some.torrent");
	return 0 if($eh==0);

	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("	Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('	Can not continue without infohash, aborting!'); return 0; }
	$r->err('	Downloaded file infohash: '.$down_hash);
	my $newtorr=$r->{curldat};

	if(defined $config->{tuper}->{rem_hashcheck} and $config->{tuper}->{rem_hashcheck}==1){
		$newtorr=$r->remove_hashcheck($config->{paths}->{upload_dir}, $newtorr);
		return 0 if($newtorr eq 0);
	}
	
	###################################
	# Write torrent file
	my $torr_file=$config->{paths}->{watch2_dir}."[".uc($to_tracker)."]".$defname.".torrent";
	if($r->write_file('torrent', $torr_file, $newtorr)==0){ return 0; }

	my %retvals=(
		"id" => $torrentid,
		"hash" => $down_hash,
	);
	return \%retvals;

}
1;
