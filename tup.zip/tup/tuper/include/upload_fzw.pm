require "include/upload_fzw.config.pm";

sub trim($)
{
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}

sub upload_fzw {

	my $name=shift; # Torrent name from database
	my $category=shift; # Category ID
	my $description=shift; # Description file path
	my $torrent=shift;  # Torrent file path
	my $nfo=shift; # NFO file path
	my $to_tracker=shift; # tracker code (for example: fano)
	my $defname=shift; # Filename from database
	my $defhash=shift; # Download torrent file info hash
	my $config=shift;

	my $r=ClientFunctions->new('upload', 'fzw', $config);

	###################################
	# Search for original NFO that comes with torrent
	#$nfo=$r->find_nfo($torrent, $nfo, $config->{paths}->{download_dir});

	###################################
	# Requesting upload page before sending POST data
	# This should be used to bypass some session verification checks
	my $eh=$r->get("http://filezoneworld.com/newforum/newthread.php?do=newthread&f=".$category);
	return 0 if($eh==0);

	###################################
	# Search for nologin
	my $match_nologin=qr/<form action="login.php/ms;
	my $nologin_matches=$r->match('nologin', $match_nologin);
	if($nologin_matches!=0){ $r->err('	Can not continue without login, aborting!'); return 0;}

	###################################
	# Search for post hash
	my $match_posthash=qr/name="posthash" value="(.*?)" \/>/ms;
	my $posthash_matches=$r->match('post hash', $match_posthash);
	if($posthash_matches==0){ $r->err('	Can not continue without posthash, aborting!'); return 0;}
	my $posthash=@$posthash_matches[0];
	$r->err("	Post hash: $posthash");

	###################################
	# Search for poststarttime
	my $match_poststarttime=qr/name="poststarttime" value="(.*?)" \/>/ms;
	my $poststarttime_matches=$r->match('poststarttime', $match_poststarttime);
	if($poststarttime_matches==0){ $r->err('	Can not continue without poststarttime, aborting!'); return 0;}
	my $poststarttime=@$poststarttime_matches[0];
	$r->err("	poststarttime: $poststarttime");

	###################################
	# Search for securitytoken
	my $match_securitytoken=qr/name="securitytoken" value="(.*?)" \/>/ms;
	my $securitytoken_matches=$r->match('securitytoken', $match_securitytoken);
	if($securitytoken_matches==0){ $r->err('	Can not continue without securitytoken, aborting!'); return 0;}
	my $securitytoken=@$securitytoken_matches[0];
	$r->err("	securitytoken: $securitytoken");

	###################################
	# Search for loggedinuser
	my $match_loggedinuser=qr/name="loggedinuser" value="(.*?)" \/>/ms;
	my $loggedinuser_matches=$r->match('loggedinuser', $match_loggedinuser);
	if($loggedinuser_matches==0){ $r->err('	Can not continue without loggedinuser, aborting!'); return 0;}
	my $loggedinuser=@$loggedinuser_matches[0];
	$r->err("	loggedinuser: $loggedinuser");

    #http://filezoneworld.com/newforum/newattachment.php?f=37&poststarttime=1312929949&posthash=bcc02e2198da4b27fe5866208dd2d9ea


    # Reading description
	$nfo=$r->find_nfo($torrent, $nfo, $config->{paths}->{download_dir});
	my $descr_txt=$r->read_file($description);
	if($descr_txt eq $config->{tuper}->{no_descr_txt} or trim($descr_txt) eq ""){
		$r->err("Empty description, using original NFO instead.");
		$descr_txt=trim($r->read_file($nfo));
		if($descr_txt eq ""){
			$descr_txt=$config->{tuper}->{no_descr_txt};
		}
	}

	###################################
	# Upload torrent
	$r->form_new;
	# Form fields passed to upload script
	$r->form_add('MAX_FILE_SIZE', '2097152');
	$r->form_add('s', '');
	$r->form_add('attachmenturl[]', '');
	$r->form_add('upload', 'Upload');
	$r->form_add('do', 'manageattach');
	$r->form_add('t', '');
	$r->form_add('f', $category);	
	$r->form_add('p', '');
	$r->form_add('editpost', '0');
	$r->form_add('poststarttime', $poststarttime);
	$r->form_add('posthash', $posthash);
	$r->form_add('securitytoken', $securitytoken);
	# Match IMDB URL
	#my $match_imdb=qr/imdb.com\/title\/tt([0-9]*)/ms; 
    #    my $imdb=""; 
    #    if($descr_txt =~ $match_imdb){
    #            $imdb="http://www.imdb.com/title/tt".$1."/"; 
    #            $r->err("Found IMDB link: ".$imdb); 
    #    }
	#$r->form_add('description', ''); #genre
	#$r->form_add('url', $imdb);
	#$r->form_add('type', $category);
	#$r->form_add('name', $name);
	#$r->form_add('descr', $descr_txt);

	# Form files passed to upload script
	return 0 if(not $r->form_add_file('attachment[]', $torrent, "application/x-bittorrent"));


	# POSTing data to upload script
	$eh=$r->post("http://filezoneworld.com/newforum/newattachment.php?do=manageattach&p=");
	return 0 if($eh==0);

#$r->err($r->{curldat});
	###################################
	# Search for torrentfile
	my $match_torrentfile=qr/target="_blank">(.*?).torrent<\/a>/ms;
	my $torrentfile_matches=$r->match('torrentfile', $match_torrentfile);
	if($torrentfile_matches==0){ $r->err('	Can not continue without torrentfile, aborting!'); return 0;}
	my $torrentfile=@$torrentfile_matches[0];
	$r->err("	torrentfile: $torrentfile");

    # New form...
    $r->form_new;

	$r->form_add('subject', $name);
	$r->form_add('message', $descr_txt);
	$r->form_add('wysiwyg', '0');
	$r->form_add('iconid', '0');
	$r->form_add('do', 'postthread');
	$r->form_add('s', '');
	$r->form_add('f', $category);
	$r->form_add('posthash', $posthash);
	$r->form_add('securitytoken', $securitytoken);
    $r->form_add('poststarttime', $poststarttime);
    $r->form_add('parseurl', '1');
    $r->form_add('emailupdate', '9999');
    $r->form_add('polloptions', '4');
    $r->form_add('sbutton', 'Submit New Thread');
    $r->form_add('loggedinuser', $loggedinuser);

	# POSTing data to upload script
	$eh=$r->post("http://filezoneworld.com/newforum/newthread.php?do=postthread&f=".$category);
	return 0 if($eh==0);

#open (MYFILE, '>>/home/tup/tuper/out.html');
#print MYFILE $r->{curldat}."\n";
#close (MYFILE);

#    $r->err($r->{curldat});

    ###################################
    # Search for already uploaded
    my $match_uploaded=qr/<p><strong>This thread is a duplicate of a thread that/ms;
    my $uploaded_matches=$r->match('uploaded', $match_uploaded);
    if($uploaded_matches!=0){ $r->err('	Torrent already uploaded, aborting!'); return 0;}

###################################
# Search for torrent ID

my $torrentid=0;
my $match_torrentidz=qr/<input type="hidden" name="t" value="(.*?)"/ms;
my $torrentidz_matches=$r->match('torrent id', $match_torrentidz);
if($torrentidz_matches!=0){ 
        $torrentid=@$torrentidz_matches[0];
        $r->err("       Torrent ID: $torrentid");
}else{

	my $match_torrentid=qr/URL=http:\/\/filezoneworld.com\/newforum\/showthread.php\?p=(.*?).post(.*?)" \/>/ms;
	my $torrentid_matches=$r->match('torrent id', $match_torrentid);
	if($torrentid_matches==0){ $r->err('Can not continue without torrent ID, aborting!'); return 0;}
	$torrentid=@$torrentid_matches[0];
	$r->err("	Torrent ID: $torrentid");

        # Requesting torrent page
        $eh=$r->get("http://filezoneworld.com/newforum/showthread.php?p=".$torrentid);
        return 0 if($eh==0);
}
#$r->err($r->{curldat});
	###################################
	# Search for torrent file
	my $match_newfiler=qr/<td><a href="attachment.php\?attachmentid=(.*?)&amp;d=(.*?)">(.*?).torrent<\/a>/ms;
	my $newfiler_matches=$r->match('torrent file', $match_newfiler);
	if($newfiler_matches==0){ $r->err('	Can not continue without torrent file, aborting!'); return 0;}
	my $newfiler1=@$newfiler_matches[0];
	my $newfiler2=@$newfiler_matches[1];

	###################################
	# Request torrent file
	$r->form_new;
	my $eh=$r->get("http://filezoneworld.com/newforum/attachment.php?attachmentid=$newfiler1&d=$newfiler2");
	return 0 if($eh==0);

	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("	Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('	Can not continue without infohash, aborting!'); return 0; }
	$r->err('	Downloaded file infohash: '.$down_hash);
	my $newtorr=$r->{curldat};


	##################################
	# Remove hashcheck
	    if($config->{tuper}->{rem_hashcheck}==1){
	        $newtorr=$r->remove_hashcheck($config->{paths}->{upload_dir}, $newtorr);
	        return 0 if($newtorr eq 0);
	    }

	###################################
	# Write torrent file
	my $torr_file=$config->{paths}->{watch2_dir}."[".uc($to_tracker)."]".$defname.".torrent";
	if($r->write_file('torrent', $torr_file, $newtorr)==0){ return 0; }

	my %retvals=(
		"id" => $torrentid,
		"hash" => $down_hash,
	);
	return \%retvals;

}
1;
