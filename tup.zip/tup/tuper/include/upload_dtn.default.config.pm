sub cat_id_tv_dtn{
	my $veids=shift;
	my %cat=(
		"Appz/0DAY" => 5,
		"Appz/Mac" => 5,
		"Appz/PC-ISO" => 4,
		"BlurayTV" => 8,
		"Documentaries" => 8,
		"Ebooks" => 7,
		"Episodes/TV-Boxset" => 8,
		"Episodes/TV-x264" => 8,
		"Episodes/TV-XviD" => 8,
		"Episodes/TV-Foreign" => 8,
		"Games/Misc" => 9,
		"Games/NDS" => 22,
		"Games/PC-ISO" => 9,
		"Games/PS2" => 14,
		"Games/PSP" => 12,
		"Games/Wii" => 27,
		"Game/Packs" => 9,
		"Games/X360" => 11,
		"Movies/MDVDR" => 18,
		"Movies/Boxsets" => 21,
		"Movies/DVDR" => 21,
		"Movies/x264" => 28,
		"Movies/XviD" => 13,
		"Movies/Foreign" => 13,
		"Music/MP3" => 16,
		"Music/Videos" => 18,
		"Requests" => 999,
		"Packs/0DAY" => 5,
		"Packs/Ebooks" => 7,
		"Packs/Music" => 16,
		"Retro/Music" => 16,
		"Episodes/TV-DVDR" => 8
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_gft_dtn{
	my $veids=shift;
	my %cat=(
		"APPS" => 114,
		"0DAY" => 115,
		"XXX-XVID" => 85,
		"TV-XVID" => 41,
		"Music" => 44,
		"Games/PC" => 102,
		"Movies-XVID" => 6,
		"Movies-DVDR" => 5,
		"E-Learning" => 999,
		"Misc" => 999,
		"Games/XBOX360" => 107,
		"MVID" => 47,
		"GFT Gems" => 999,
		"Anime" => 999,
		"TV-X264" => 122,
		"Movies-X264" => 100,
		"Movies/XviD" => 6,
		"TV-DVDRIP" => 999,
		"XXX-HD" => 128,
		"XXX-0DAY" => 999,
		"Games/WII" => 111,
		"XXX-DVDR" => 999,
		"Portable/Mobile/PDA" => 999,
		"MAC" => 119,
		"Games/PSP" => 106,
		"Games/NDS" => 110
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_rtt_dtn{
	my $veids=shift;
	my %cat=(
		"Anime" => 6,
		"Apps/Misc" => 5,
		"Appz/PC-ISO" => 4,
		"E-Book" => 7,
		"Games/PC-ISO" => 9,
		"Games/PC-Rips" => 9,
		"Games/PS2" => 14,
		"Games/PS3" => 12,
		"Games/Wii" => 27,
		"Games/XBOX360" => 11,
		"Handheld/PSP" => 12,
		"Mac" => 5,
		"Movies/DVDR" => 21,
		"Movies/Packs" => 13,
		"Movies/WMV" => 13,
		"Movies/x264" => 28,
		"Movies/XviD" => 13,
		"Music" => 16,
		"Music/Packs" => 16,
		"MusicVideos" => 18,
		"TV/DVDR" => 8,
		"TV/HR" => 8,
		"TV/Packs" => 8,
		"TV/x264" => 8,
		"TV/XViD" => 8,
		"XXX" => 999,
		"XXX/DVDR" => 999,
		"XXX/HD" => 999
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_scc_dtn{
	my $veids=shift;
	my %cat=(
		"Dox" => 117,
		"APPS" => 114,
		"Games/PC" => 102,
		"Games/PS2" => 105,
		"Games/PS3" => 104,
		"Games/WII" => 111,
		"Games/XBOX" => 109,
		"Games/XBOX360" => 107,
		"MiSC" => 117,
		"Movies/DVDR" => 5,
		"Movies/VCD" => 6,
		"Movies/X264" => 100,
		"Movies/XviD" => 6,
		"TV/DVDR" => 40,
		"TV/X264" => 122,
		"TV/XviD" => 41,
		"TV/Packs" => 40,
		"XXX/XviD" => 85,
		"0DAY" => 115,
		"MP3" => 44,
		"MVID" => 47
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_tl_dtn{
	my $veids=shift;
	my %cat=(
		"Cam" => 6,
		"TS/TC" => 6,
		"R5/Screeners" => 6,
		"DVDRip/DVDScreener" => 6,
		"DVD-R" => 5,
		"HD" => 100,
		"BDRip" => 6,
		"Boxsets" => 6,
		"Documentaries" => 50,
		"Episodes" => 41,
		"Episodes HD" => 122,
		"PC" => 102,
		"XBOX" => 109,
		"XBOX360" => 107,
		"PS2" => 105,
		"PS3" => 104,
		"PSP" => 106,
		"Wii" => 111,
		"Nintendo DS" => 110,
		"Music Videos" => 47,
		"Audio" => 44,
		"Anime" => 7,
		"Books" => 90,
		"PC-ISO" => 114,
		"Mac" => 119,
		"PDA" => 116,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_ipt_dtn{
	my $veids=shift;
	my %cat=(
		"Anime" => 6,
		"Appz/misc" => 115,
		"AudioBook" => 124,
		"Books - Mags" => 90,
		"Games / Mixed" => 101,
		"Games/Nintendo DS" => 110,
		"Games/PC ISO" => 102,
		"Games/PC Rips" => 103,
		"Games/PS2" => 105,
		"Games/PSP" => 106,
		"Games/PSX" => 125,
		"Games/Wii" => 111,
		"Games/XBOX" => 109,
		"Games/XBOX360" => 107,
		"HD/X264" => 100,
		"iPod/Movies" => 1,
		"iPod/TV" => 1,
		"Kids" => 1,
		"MAC" => 119,
		"Mobile" => 123,
		"Movies/DVD-R" => 5,
		"Movies/FLAWL3SS" => 6,
		"Movies/Non-English" => 6,
		"Movies/Packs" => 6,
		"Movies/XviD" => 6,
		"Music > Video" => 47,
		"Music/Audio" => 44,
		"Pics/Wallpapers" => 126,
		"Sports" => 1,
		"TV > Episodes" => 41,
		"TV/Packs" => 40,
		"XXX" => 85
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}
1;
