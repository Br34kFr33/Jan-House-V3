require "include/upload_ipt.config.pm";

sub upload_ipt {

	my $name=shift; # Torrent name from database
	my $category=shift; # Category ID
	my $description=shift; # Description file path
	my $torrent=shift;  # Torrent file path
	my $nfo=shift; # NFO file path
	my $to_tracker=shift; # tracker code (for example: fano)
	my $defname=shift; # Filename from database
	my $defhash=shift; # Download torrent file info hash
	my $config=shift;

	my $r=ClientFunctions->new('upload', 'ipt', $config);

	###################################
	# Search for original NFO that comes with torrent
	$nfo=$r->find_nfo($torrent, $nfo, $config->{paths}->{download_dir});

	###################################
	# Requesting upload page before sending POST data
	# This should be used to bypass some session verification checks
	my $eh=$r->get("http://on.iptorrents.com/upload.php");
	return 0 if($eh==0);

	###################################
	# Search for nologin
	my $match_nologin=qr/<form method="post" action="takelogin.php">/ms;
	my $nologin_matches=$r->match('nologin', $match_nologin);
	if($nologin_matches!=0){ $r->err('	Can not continue without login, aborting!'); return 0;}
	my $descr_txt=$r->read_file($description);

# TV Series
if($category==178){
        if($name =~ m/720p/i) {
                $category=15;
        }elsif($name =~ m/1080p/i) {
                $category=15;
        }elsif($name =~ m/1080i/i) {
                $category=15;
        }
}

	###################################
	# Upload torrent
	$r->form_new;
	# Form fields passed to upload script
	$r->form_add('MAX_FILE_SIZE', '100000000');
	$r->form_add('filetype', '2'); #non-audio file
	$r->form_add('artist', '');	
	$r->form_add('album', '');
	$r->form_add('year', '');
        $r->form_add('format', '');
        $r->form_add('bitrate', '');
	# Match IMDB URL
	#my $match_imdb=qr/imdb.com\/title\/tt([0-9]*)/ms; 
        #my $imdb=""; 
        #if($descr_txt =~ $match_imdb){
        #        $imdb="http://www.imdb.com/title/tt".$1."/"; 
        #        $r->err("Found IMDB link: ".$imdb); 
        #}
	#$r->form_add('url', $imdb);
	$r->form_add('type', $category);
	$r->form_add('name', $name);
	$r->form_add('descr', $descr_txt);

	# Form files passed to upload script
	return 0 if(not $r->form_add_file('file', $torrent, "application/x-bittorrent"));
	return 0 if(not $r->form_add_file('nfo', $nfo, "text/plain"));

	# POSTing data to upload script
	$eh=$r->post("http://on.iptorrents.com/takeupload.php");
	return 0 if($eh==0);
    #$r->err($r->{curldat});

    ###################################
    # Searc for upload failed
    my $match_failed=qr/<\/a><\/p><h3>Upload failed.<\/h3>\n<p>(.*?)<\/p>/ms;
    my $failed_matches=$r->match('upload failed', $match_failed);
    if($failed_matches!=0){ $r->err(' Upload failed: '.@$failed_matches[0]); return 0;}

    ###################################
    # Search for already uploaded
    my $match_uploaded=qr/Duplicate entry '/ms;
    my $uploaded_matches=$r->match('uploaded', $match_uploaded);
    if($uploaded_matches!=0){ $r->err('	Torrent already uploaded, aborting!'); return 0;}

	###################################
	# Search for torrent id
	my $match_torrentid=qr/<tr><td width=99% align=left><a class="index" href="download.php\/(.*?)\/(.*?).torrent"><img /ms;
	my $torrentid_matches=$r->match('torrent id', $match_torrentid);
	if($torrentid_matches==0){ $r->err('	Can not continue without torrent ID, aborting!'); return 0;}
	my $torrentid=@$torrentid_matches[0];
	$r->err("	Torrent ID: $torrentid");

	###################################
	# Request torrent file
	my $eh=$r->get("http://on.iptorrents.com/download.php/".$torrentid."/some.torrent");
	return 0 if($eh==0);

	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("	Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('	Can not continue without infohash, aborting!'); return 0; }
	$r->err('	Downloaded file infohash: '.$down_hash);
	my $newtorr=$r->{curldat};

	$newtorr=$r->remove_hashcheck($config->{paths}->{upload_dir}, $newtorr);
	return 0 if($newtorr eq 0);

	###################################
	# Write torrent file
	my $torr_file=$config->{paths}->{watch2_dir}."[".uc($to_tracker)."]".$defname.".torrent";
	if($r->write_file('torrent', $torr_file, $newtorr)==0){ return 0; }

	my %retvals=(
		"id" => $torrentid,
		"hash" => $down_hash,
	);
	return \%retvals;

}
1;
