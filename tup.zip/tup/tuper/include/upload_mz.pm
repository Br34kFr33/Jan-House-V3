require "include/upload_mz.config.pm";
sub trim($)
{
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}
sub upload_mz {

	my $name=shift; # Torrent name from database
	my $category=shift; # Category ID
	my $description=shift; # Description file path
	my $torrent=shift;  # Torrent file path
	my $nfo=shift; # NFO file path
	my $to_tracker=shift; # tracker code (for example: fano)
	my $defname=shift; # Filename from database
	my $defhash=shift; # Download torrent file info hash
	my $config=shift;

	my $r=ClientFunctions->new('upload', 'mz', $config);

	###################################
	# Search for original NFO that comes with torrent
	$nfo=$r->find_nfo($torrent, $nfo, $config->{paths}->{download_dir});

	###################################
	# Request page
	my $eh=$r->get("http://movieszone.org/?p=torrents&action=upload&pid=21");
	return 0 if($eh==0);

	###################################
	# Search for nologin
	my $match_nologin=qr/<br \/>You do not have permission to view this page or perform this action./ms;
        my $nologin_matches=$r->match('nologin', $match_nologin);
        if($nologin_matches!=0){
                $r->err('       Can not continue without login, trying to login!');
                #return 0;
                $r->form_new;
				$r->form_add('action', 'login');
				$r->form_add('loginbox_remember', 'true');
                $r->form_add('loginbox_membername', $config->{cookies}->{user_mz});
                $r->form_add('loginbox_password', $config->{cookies}->{pass_mz});
                $eh=$r->post("http://movieszone.org/ajax.php");
                return 0 if($eh==0);
				my $match_nologin_fail=qr/You have entered an invalid membername or password./ms;
                $nologin_matches=$r->match('nologin', $match_nologin_fail);
                if($nologin_matches!=0){
                        $r->err('Can not continue without login, aborting!');
                        return 0;
                }
            	$eh=$r->get("http://movieszone.org/?p=torrents&action=upload&pid=21");
                return 0 if($eh==0);
        }

	###################################
    # Read description	
    my $descr_txt=$r->read_file($description);
    if($descr_txt eq $config->{tuper}->{no_descr_txt}){
        $descr_txt=$r->read_file($nfo);
    }
	$descr_txt=$config->{tuper}->{no_descr_txt} if trim($descr_txt) eq "";
	
	###################################
	# Search for security token
	my $match_security_token=qr/stKey: "(.*?)",/ms;
	my $security_token_matches=$r->match('security token', $match_security_token);
	if($security_token_matches==0){ $r->err('Can not continue without security token, aborting!'); return 0;}
	my $security_token=@$security_token_matches[0];
	$r->err("Security token: $security_token");
	
	###################################
	# Upload torrent file
	$r->form_new;
	return 0 if(not $r->form_add_file('qqfile', $torrent, "application/x-bittorrent"));
	# Uploading .torrent

	$eh=$r->post("http://movieszone.org/ajax/upload_file.php?postid=&action=upload_file&content_type=torrent_files&forumid=NaN&securitytoken=".$security_token."&qqfile=".$r->urlencode($defname).".torrent");
	return 0 if($eh==0);
	#$r->err($r->{curldat});
    ###################################
    # Search for error
    my $match_uploaded=qr/{"error":"(.*?)"}/ms;
    my $uploaded_matches=$r->match('uploaded', $match_uploaded);
    if($uploaded_matches!=0){ $r->err('Got error: '.@$uploaded_matches[0]." Aborting."); return 0;}
	
	###################################
	# Search for success response
	my $match_torrentid=qr/{"success":(.*?)}/ms;
	my $torrentid_matches=$r->match('torrent id', $match_torrentid);
	if($torrentid_matches==0){ $r->err('	Can not continue without torrent ID, aborting!'); return 0;}
	my $torrentid=@$torrentid_matches[0];
	$r->err("Torrentfile ID: $torrentid");

	$r->form_new;
	# Form fields passed to upload script
	$r->form_add('securitytoken', $security_token);
	$r->form_add('attachment_ids[]', $torrentid);
	$r->form_add('action', 'upload_torrent');
	$r->form_add('description', '');
	$r->form_add('annonymouse', '1');
	$r->form_add('record_stats', '1');
	$r->form_add('download_multiplier', '1');
	$r->form_add('upload_multiplier', '1');
	$r->form_add('hitRunRatio', '48');
	$r->form_add('tid', '0');
	$r->form_add('uploadStep', '1');
	
	# Match IMDB URL
	my $match_imdb=qr/imdb.com\/title\/tt([0-9]*)/ms; 
        my $imdb=""; 
        if($descr_txt =~ $match_imdb){
                $imdb="http://www.imdb.com/title/tt".$1."/"; 
                $r->err("Found IMDB link: ".$imdb); 
        }
	$r->form_add('imdb', $imdb);
	$r->form_add('cid', $category);
	$r->form_add('name', $name);
	$r->form_add('rDescription', $descr_txt);

	# POSTing data to upload script
	$eh=$r->post("http://movieszone.org/ajax/torrents.php");
	return 0 if($eh==0);
	#$r->err($r->{curldat});

    ###################################
    # Search for error
    my $match_error=qr/<div class="error" header="An error has occured!">(.*?)<\/div>/ms;
    my $error_matches=$r->match('error', $match_error);
    if($creating_matches!=0){ $r->err('Got some error message: '.@$error_matches[0]); return 0;}
	
    ###################################
    # Search for "creating torrent..."
    my $match_creating=qr/Creating Torrent.../ms;
    my $creating_matches=$r->match('creating torrent', $match_creating);
    if($creating_matches==0){ $r->err('No clue what the site thinks of this. Aborting!'); return 0;}

	
	# Step 2
	$r->form_add('uploadStep', '2');
	$eh=$r->post("http://movieszone.org/ajax/torrents.php");
	return 0 if($eh==0);
	$r->err($r->{curldat});
	
	my $match_torrentfin=qr/~tid~(.*)/ms;
	my $torrentfin_matches=$r->match('torrent id', $match_torrentfin);
	if($torrentfin_matches==0){ $r->err('Can not continue without torrent ID, aborting!'); return 0;}
	my $torrentfin=@$torrentfin_matches[0];
	$r->err("Torrent ID: $torrentfin");
	
	# Step 3
	$r->form_add('uploadStep', '2');
	$eh=$r->post("http://movieszone.org/ajax.php");
	return 0 if($eh==0);
	$r->form_add('uploadStep', '3');
	$r->form_add('tid', $torrentfin);
	
	###################################
	# Request torrent file
	my $eh=$r->get("http://movieszone.org/?p=torrents&pid=10&action=download&tid=".$torrentfin);
	return 0 if($eh==0);

	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("	Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('	Can not continue without infohash, aborting!'); return 0; }
	$r->err('	Downloaded file infohash: '.$down_hash);
	my $newtorr=$r->{curldat};

	if(defined $config->{tuper}->{rem_hashcheck} and $config->{tuper}->{rem_hashcheck}==1){
		$newtorr=$r->remove_hashcheck($config->{paths}->{upload_dir}, $newtorr);
		return 0 if($newtorr eq 0);
	}
	
	###################################
	# Write torrent file
	my $torr_file=$config->{paths}->{watch2_dir}."[".uc($to_tracker)."]".$defname.".torrent";
	if($r->write_file('torrent', $torr_file, $newtorr)==0){ return 0; }

	my %retvals=(
		"id" => $torrentfin,
		"hash" => $down_hash,
	);
	return \%retvals;

}
1;
