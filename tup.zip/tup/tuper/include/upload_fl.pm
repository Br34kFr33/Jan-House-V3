require "include/upload_fl.config.pm";
sub trim($)
{
    my $string = shift;
    $string =~ s/^\s+//;
    $string =~ s/\s+$//;
    return $string;
}
sub upload_fl {

    my $name=shift; # Torrent name from database
    my $category=shift; # Category ID
    my $description=shift; # Description file path
    my $torrent=shift;  # Torrent file path
    my $nfo=shift; # NFO file path
    my $to_tracker=shift; # tracker code (for example: fano)
    my $defname=shift; # Filename from database
    my $defhash=shift; # Download torrent file info hash
    my $config=shift;

    my $r=ClientFunctions->new('upload', 'fl', $config);

    ###################################
    # Search for original NFO that comes with torrent
    $nfo=$r->find_nfo($torrent, $nfo, $config->{paths}->{download_dir});

    ###################################
    # Request page
    my $eh=$r->get("http://flix4u.biz/?p=torrents&action=upload&pid=21");
    return 0 if($eh==0);

    ###################################
    # Search for nologin
    my $match_nologin=qr/<form id="loginbox_form" action="">/ms;
        my $nologin_matches=$r->match('nologin', $match_nologin);
        if($nologin_matches!=0){
                $r->err('       Can not continue without login, trying to login!');
                #return 0;
                $r->form_new;
                $r->form_add('action', 'login');
                $r->form_add('loginbox_remember', 'true');
                $r->form_add('loginbox_membername', $config->{cookies}->{user_fl});
                $r->form_add('loginbox_password', $config->{cookies}->{pass_fl});
                $eh=$r->post("http://flix4u.biz/ajax/login.php");
                return 0 if($eh==0);
                my $match_nologin_fail=qr/You have entered an invalid membername or password./ms;
                $nologin_matches=$r->match('nologin', $match_nologin_fail);
                if($nologin_matches!=0){
                        $r->err('Can not continue without login, aborting!');
                        return 0;
                }
                $eh=$r->get("http://flix4u.biz/?p=torrents&action=upload&pid=21");
#$eh=$r->get("http://flix4u.biz/?p=torrents&pid=32");

                return 0 if($eh==0);
        }

    ###################################
    # Read description  
    my $descr_txt=$r->read_file($description);
    if($descr_txt eq $config->{tuper}->{no_descr_txt}){
        $descr_txt=$r->read_file($nfo);
    }
    $descr_txt=$config->{tuper}->{no_descr_txt} if trim($descr_txt) eq "";
#$r->err($r->{curldat});    
    ###################################
    # Search for security token
    my $match_security_token=qr/stKey: "(.*?)",/ms;
    my $security_token_matches=$r->match('security token', $match_security_token);
    if($security_token_matches==0){ $r->err('Can not continue without security token, aborting!'); return 0;}
    my $security_token=@$security_token_matches[0];
    $r->err("Security token: $security_token");
    
    
    ###################################
    # Upload nfo file
    $r->form_new;
    return 0 if(not $r->form_add_file('qqfile', $nfo, "multipart/form-data"));
    # Uploading .nfo

    $eh=$r->post("http://flix4u.biz/ajax/upload_file.php?postid=&action=upload_file&content_type=torrent_files&forumid=NaN&securitytoken=".$security_token."&qqfile=".$r->urlencode($defname).".nfo");
    return 0 if($eh==0);
    $r->err($r->{curldat});
    ###################################
    # Search for error
    my $match_nuploaded=qr/{"error":"(.*?)"}/ms;
    my $nuploaded_matches=$r->match('error', $match_nuploaded);
    if($nuploaded_matches!=0){ $r->err('Got error: '.@$nuploaded_matches[0]." Aborting."); return 0;}
    
        ###################################
    # Search for success response
    my $nfoid;
    my $match_nfoid=qr/{"success":(.*?)}/ms;
    my $nfoid_matches=$r->match('nfo id', $match_nfoid);
    if($nfoid_matches==0){ $r->err('    No nfoid found.'); $nfoid=0; }
    $nfoid=@$nfoid_matches[0];
    $r->err("NFO ID: $nfoid");
    
    ###################################
    # Upload torrent file
    $r->form_new;
    return 0 if(not $r->form_add_file('qqfile', $torrent, "application/x-bittorrent"));
    # Uploading .torrent

    $eh=$r->post("http://flix4u.biz/ajax/upload_file.php?postid=&action=upload_file&content_type=torrent_files&forumid=NaN&securitytoken=".$security_token."&qqfile=".$r->urlencode($defname).".torrent");
    return 0 if($eh==0);
    #$r->err($r->{curldat});
    ###################################
    # Search for error
    my $match_uploaded=qr/{"error":"(.*?)"}/ms;
    my $uploaded_matches=$r->match('error', $match_uploaded);
    if($uploaded_matches!=0){ $r->err('Got error: '.@$uploaded_matches[0]." Aborting."); return 0;}
    
    ###################################
    # Search for success response
    my $match_torrentid=qr/{"success":(.*?)}/ms;
    my $torrentid_matches=$r->match('torrent id', $match_torrentid);
    if($torrentid_matches==0){ $r->err('    Can not continue without torrent ID, aborting!'); return 0;}
    my $torrentid=@$torrentid_matches[0];
    $r->err("Torrentfile ID: $torrentid");

	# fix descr \n
	$descr_txt =~ s/\n/<br \/>\n/g;

    $r->form_new;
    # Form fields passed to upload script
    $r->form_add('securitytoken', $security_token);

    $r->form_add('attachment_ids[0]', $torrentid);
    $r->form_add('attachment_ids[1]', $nfoid) if $nfoid > 0;
    
    $r->form_add('action', 'upload_torrent');
    $r->form_add('description', $descr_txt);
    $r->form_add('annonymouse', '1');
    $r->form_add('record_stats', '1');
    $r->form_add('download_multiplier', '1');
    $r->form_add('upload_multiplier', '1');
    $r->form_add('hitRunRatio', '48');
    $r->form_add('tid', '0');
    $r->form_add('uploadStep', '1');
    
    # Match IMDB URL
    my $match_imdb=qr/imdb.com\/title\/tt([0-9]*)/ms; 
        my $imdb=""; 
        if($descr_txt =~ $match_imdb){
                $imdb="http://www.imdb.com/title/tt".$1."/"; 
                $r->err("Found IMDB link: ".$imdb); 
        }
    $r->form_add('imdb', $imdb);
    $r->form_add('cid', $category);
    $r->form_add('name', $name);
    $r->form_add('rDescription', $descr_txt);

    # POSTing data to upload script
    $eh=$r->post("http://flix4u.biz/ajax/torrents.php");
    return 0 if($eh==0);
    #$r->err($r->{curldat});

    ###################################
    # Search for error
    my $match_error=qr/<div class="error" header="An error has occured!">(.*?)<\/div>/ms;
    my $error_matches=$r->match('error', $match_error);
    if($error_matches!=0){ $r->err('Got some error message: '.@$error_matches[0]); return 0;}
    
    ###################################
    # Search for "creating torrent..."
    my $match_creating=qr/Creating Torrent.../ms;
    my $creating_matches=$r->match('creating torrent', $match_creating);
    if($creating_matches==0){ $r->err('No clue what the site thinks of this. Aborting!'); return 0;}

    
    # Step 2
    $r->form_add('uploadStep', '2');
    $eh=$r->post("http://flix4u.biz/ajax/torrents.php");
    return 0 if($eh==0);
    $r->err($r->{curldat});
    
    my $match_torrentfin=qr/~tid~(.*)/ms;
    my $torrentfin_matches=$r->match('torrent id', $match_torrentfin);
    if($torrentfin_matches==0){ $r->err('Can not continue without torrent ID, aborting!'); return 0;}
    my $torrentfin=@$torrentfin_matches[0];
    $r->err("Torrent ID: $torrentfin");
    
    # Step 3
    $r->form_add('uploadStep', '3');
    $r->form_add('tid', $torrentfin);
    $eh=$r->post("http://flix4u.biz/ajax/torrents.php");
    return 0 if($eh==0);
    $r->err("Step 3: ".$r->{curldat}, "green");

    # Step 4
    $r->form_add('uploadStep', '4');
    $eh=$r->post("http://flix4u.biz/ajax/torrents.php");
    return 0 if($eh==0);
    $r->err("Step 4: ".$r->{curldat}, "green");
    
    # Step 5
    $r->form_add('uploadStep', '5');
    $eh=$r->post("http://flix4u.biz/ajax/torrents.php");
    return 0 if($eh==0);
    $r->err("Step 5: ".$r->{curldat}, "green");
    
    ###################################
    # Request torrent file
    my $eh=$r->get("http://flix4u.biz/?p=torrents&pid=10&action=download&tid=".$torrentfin);
    return 0 if($eh==0);

    ###################################
    # Check for bittorrent header
    my $file_type=$r->curl_get_type();
    if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("  Downloaded file is not bittorrent: ".$file_type); }

    ###################################
    # Get infohash from downloaded file
    my $down_hash = $r->get_infohash_from_curl;
    if($down_hash eq 0){ $r->err('  Can not continue without infohash, aborting!'); return 0; }
    $r->err('   Downloaded file infohash: '.$down_hash);
    my $newtorr=$r->{curldat};

    if(defined $config->{tuper}->{rem_hashcheck} and $config->{tuper}->{rem_hashcheck}==1){
        $newtorr=$r->remove_hashcheck($config->{paths}->{upload_dir}, $newtorr);
        return 0 if($newtorr eq 0);
    }
    
    ###################################
    # Write torrent file
    my $torr_file=$config->{paths}->{watch2_dir}."[".uc($to_tracker)."]".$defname.".torrent";
    if($r->write_file('torrent', $torr_file, $newtorr)==0){ return 0; }

    my %retvals=(
        "id" => $torrentfin,
        "hash" => $down_hash,
    );
    return \%retvals;

}
1;



