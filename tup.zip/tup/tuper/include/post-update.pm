=pod
* Change table field types and add new field - hide (to hide items in web panel)
=cut

sub restore_db {
    my ($orig, $backup)=@_;
    my @args=($orig);
    system("rm", @args);
    my @argz=($backup, $orig);
    system("cp", @argz);
    print "$backup, $orig";
}

sub post_update {
    my $config=shift;
    my $t=new JhUp();
    my $statement="";

    my $db=undef;
    if(not $db = DBI->connect("dbi:SQLite:".$config->{paths}->{tuper_db}, "", "", {RaiseError => 0, PrintError => 0})){
        $t->err('Failed connecting to database ('.$config->{paths}->{tuper_db}.'): '.$DBI::errstr, 'red');
        return 0;
    }

    $t->err("Checking if tuper.db needs changes.", "cyan");

    $statement = 'PRAGMA table_info(data) ';
    my $rows=undef;
    if(not $rows = $db->selectall_arrayref($statement, { Slice => {} }) and $DBI::errstr){
        $t->err('Failed SQL query that shows table info: '.$DBI::errstr, 'red');
        undef $rows if defined $rows;
        $db->disconnect  or warn $db->errstr;
        return 0;
    }

    if(defined $rows and scalar @$rows == 0){
        $self->err('Query did not bring up any results.', 'cyan');
        undef $rows if defined $rows;
        $db->disconnect  or warn $db->errstr;
        return 0;
    }

    foreach my $row ( @$rows ) {
        if($row->{name} eq "hide"){
            $t->err("tuper.db is up to date.", "cyan");
            $db->disconnect  or warn $db->errstr;
            return 1;
        }
    }

    $t->err("Creating backup copy of existing tuper.db.", "cyan");
    my @argz=($config->{paths}->{tuper_db}, $config->{paths}->{tuper_db}.".bak");
    system("cp", @argz);
    
    $t->err("Rename original table to tmp_data", "cyan");
    $statement='ALTER TABLE "data" RENAME TO "tmp_data";';
    
    if(not $db->do($statement)){
        $t->err('Failed to rename the table: '.$DBI::errstr, 'red');
        $db->disconnect  or warn $db->errstr;
        $t->err("Restoring backup...", "cyan");
        &restore_db($config->{paths}->{tuper_db}, $config->{paths}->{tuper_db}.".bak");
        return 0;
    }

    $t->err("Creating new table: data", "cyan");

    $statement='CREATE TABLE "data" (
        "id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        "infohash" TEXT NOT NULL,
        "name" TEXT NOT NULL,
        "file" TEXT NOT NULL,
        "category" INTEGER NOT NULL,
        "added" INTEGER,
        "started" INTEGER,
        "downloaded" INTEGER,
        "uploaded" INTEGER,
        "seeded" INTEGER,
        "upload_infohash" TEXT,
        "download_removed" INTEGER,
        "upload_removed" INTEGER,
        "from" TEXT NOT NULL,
        "to" TEXT NOT NULL,
        "upload_id" TEXT,
        "download_id" TEXT,
        "hide" INTEGER);';

    if(not $db->do($statement)){
        $t->err('Failed to create table: '.$DBI::errstr, 'red');
        $db->disconnect  or warn $db->errstr;
        $t->err("Restoring backup...", "cyan");
        &restore_db($config->{paths}->{tuper_db}, $config->{paths}->{tuper_db}.".bak");
        return 0;
    }
    
    $t->err("Transfering old data to the new table", "cyan");

    $statement='
    INSERT INTO data ("id", "infohash", "name", "file", "category", "added", 
    "started", "downloaded", "uploaded", "seeded", "upload_infohash", 
    "download_removed", "upload_removed", "from", "to", "upload_id", "download_id")
    SELECT "id", "infohash", "name", "file", "category", "added", 
    "started", "downloaded", "uploaded", "seeded", "upload_infohash", 
    "download_removed", "upload_removed", "from", "to", "upload_id", "download_id"
    FROM tmp_data;
    ';

    if(not $db->begin_work() or not $db->do($statement)){
        $t->err('Failed to copy the data: '.$DBI::errstr, 'red');
        $db->disconnect  or warn $db->errstr;
        $t->err("Restoring backup...", "cyan");
        &restore_db($config->{paths}->{tuper_db}, $config->{paths}->{tuper_db}.".bak");
        return 0;
    }

    $t->err("Removing tmp_data table.", "cyan");
    
    $statement='DROP TABLE IF EXISTS tmp_data';

    $db->do($statement);
    if(not $db->commit()){
        $t->err('Failed to remove tmp_data table: '.$DBI::errstr, 'red');
        $db->disconnect  or warn $db->errstr;
        $t->err("Restoring backup...", "cyan");
        &restore_db($config->{paths}->{tuper_db}, $config->{paths}->{tuper_db}.".bak");
        return 0;
    }

    $statement='CREATE UNIQUE INDEX "PK_data" on "data" (id ASC);';
    if(not $db->do($statement)){
        $t->err('Failed to remove tmp_data table: '.$DBI::errstr, 'red');
        $db->disconnect  or warn $db->errstr;
        $t->err("Restoring backup...", "cyan");
        &restore_db($config->{paths}->{tuper_db}, $config->{paths}->{tuper_db}.".bak");
        return 0;
    }

    $db->disconnect or warn $db->errstr;

    return 2;
}
1;
