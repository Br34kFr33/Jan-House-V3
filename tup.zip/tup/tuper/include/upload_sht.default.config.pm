sub cat_id_fro_sht{
        my $veids=shift;
        return 12;
}

sub cat_id_tv_sht{
	my $veids=shift;
	my %cat=(
		"Appz/0DAY" => 3,
		"Appz/Mac" => 3,
		"Appz/PC-ISO" => 3,
		"Ebooks" => 5,
		"BlurayTV" => 20,
		"Documentaries" => 20,
		"Episodes/TV-Boxset" => 20,
		"Episodes/TV-x264" => 20,
		"Episodes/TV-XviD" => 20,
		"Episodes/TV-Foreign" => 20,
		"Games/Wii" => 10,
		"Games/NDS" => 6,
		"Games/PC-ISO" => 7,
		"Games/PS2" => 9,
		"Games/PS3" => 33,
		"Games/PSP" => 8,
		"Games/Wii" => 10,
		"Game/Packs" => 6,
		"Games/X360" => 22,
		"Movies/Boxsets" => 11,
		"Movies/DVDR" => 12,
		"Movies/x264" => 13,
		"Movies/XviD" => 14,
		"Music/MP3" => 16,
		"Music/Videos" => 17,
		"Music/FLAC" => 15,
		"Requests" => 81,
		"Packs/0DAY" => 3,
		"Packs/Ebooks" => 5,
		"Packs/Music" => 16,
		"Retro/Music" => 16,
		"Episodes/TV-DVDR" => 20,
		"Sports" => 18,
		"Sports/UFC" => 19,
		"Sports/WWE" => 31,
		"XXX" => 26,
		"Windows Software" => 30,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_gft_sht{
	my $veids=shift;
	my %cat=(
		"APPS" => 5,
		"0DAY" => 5,
		"XXX-XVID" => 1,
		"TV-XVID" => 8,
		"Music" => 17,
		"Games/PC" => 9,
		"Movies-XVID" => 6,
		"Movies-DVDR" => 4,
		"E-Learning" => 7,
		"Misc" => 16,
		"Games/XBOX360" => 11,
		"MVID" => 17,
		"GFT Gems" => 999,
		"Anime" => 3,
		"TV-X264" => 8,
		"Movies-X264" => 10,
		"Movies/XviD" => 6,
		"TV-DVDRIP" => 8,
		"XXX-HD" => 1,
		"XXX-0DAY" => 1,
		"Games/WII" => 27,
		"XXX-DVDR" => 1,
		"Portable/Mobile/PDA" => 5,
		"MAC" => 5,
		"Games/PSP" => 12,
		"Games/NDS" => 22
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}


sub cat_id_rtt_sht{
	my $veids=shift;
	my %cat=(
		"Anime" => 19,
		"Apps/Misc" => 1,
		"Appz/PC-ISO" => 1,
		"E-Book" => 10,
		"Games/PC-ISO" => 4,
		"Games/PC-Rips" => 4,
		"Games/PS2" => 33,
		"Games/PS3" => 33,
		"Games/Wii" => 33,
		"Games/XBOX360" => 33,
		"Handheld/PSP" => 33,
		"Mac" => 1,
		"Movies/DVDR" => 20,
		"Movies/Packs" => 36,
		"Movies/WMV" => 19,
		"Movies/x264" => 14,
		"Movies/XviD" => 19,
		"Music" => 6,
		"Music/Packs" => 37,
		"MusicVideos" => 13,
		"TV/DVDR" => 7,
		"TV/HR" => 7,
		"TV/Packs" => 7,
		"TV/x264" => 7,
		"TV/XViD" => 7,
		"XXX" => 9,
		"XXX/DVDR" => 9,
		"XXX/HD" => 9
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_scc_sht{
	my $veids=shift;
	my %cat=(
	"Movies/DVD-R" => 4,
	"Movies/x264" => 10,
	"Movies/XviD" => 6,
	"Movies/Packs" => 14,
	"TV/DVD-R" => 12,
	"TV/DVDRip" => 12,
	"TV/x264" => 12,
	"TV/XviD" => 12,
	"TV/Packs" => 12,
	"Games/PC" => 16,
	"Games/PS3" => 16,
	"Games/PSP" => 16,
	"Games/WII" => 16,
	"Games/XBOX360" => 16,
	"Games/Packs" => 16,
	"APPS" => 16,
	"DOX" => 16,
	"MISC" => 16,
	"MP3" => 17,
	"Music/Packs" => 17,
	"0DAY" => 16,
	"MVID" => 17,
	"XXX/XviD" => 1,
	"XXX/x264" => 1,
	"XXX/0DAY" => 1,
	"XXX/Packs" => 1,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_tl_sht{
	my $veids=shift;
	my %cat=(
		"Anime/Cartoon" => 16,
		"Appz/MAC" => 19,
		"Appz/misc" => 8,
		"Appz/PC ISO" => 8,
		"Appz/PDA" => 8,
		"Books - Mags" => 30,
		"Documentaries" => 5,
		"Episodes/Boxsets" => 43,
		"Episodes/TV" => 5,
		"Games/PC ISO" => 15,
		"Games/PC Retro" => 15,
		"Games/PC Rips" => 15,
		"Games/PS2" => 9,
		"Games/PS3" => 35,
		"Games/PS2 Retro" => 9,
		"Games/PSP" => 22,
		"Games/Wii" => 7,
		"Games/X360 Retro" => 12,
		"Games/XBOX" => 24,
		"Games/XBOX360" => 12,
		"Movies/DVD-R" => 11,
		"Movies/Foreign" => 39,
		"Movies/HD-x264" => 39,
		"Movies/Music DVD" => 13,
		"Movies/Retro" => 39,
		"Movies/XviD" => 39,
		"Music" => 6,
		"Nintendo DS" => 2,
		"NonScene/BRRip-x264" => 39,
		"NonScene/BRRip-XviD" => 39,
		"NonScene/Xvid" => 39,
		"XXX" => 39
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_danbit_sht{
	my $veids=shift;
	my %cat=(
		"Appz" => 3,
		"BluRay" =>86,
		"Console" => 85,
		"Covers" => 81,
		"Danishbits Custom" => 81,
		"Danske Film" => 77,
		"Ebooks" => 95,
		"HD-X264" => 86,
		"Movies/DVDnonDK" => 87,
		"Movies/DVDR" => 87,
		"Movies/DVDR-NOR" => 87,
		"Movies/DVDR-SWE" => 87,
		"Movies/XviD" => 77,
		"Music" => 84,
		"Music Videos" => 78,
		"PC Games" => 6,
		"TV" => 77,
		"XXX" => 90
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

# IPTorrents category converter
sub cat_id_ipt_sht{
	my $veids=shift;
	my %cat=(
		"Appz/misc" => 3,
		"Ebooks" => 5,
		"Games/Nintendo DS" => 6,
		"Games/PC ISO" => 7,
		"Games/PC Rips" => 7,
		"Games/PS2" => 9,
		"Games/PSP" => 9,
		"Games/PS3" => 33,
		"Games/Wii" => 10,
		"Games/XBOX" => 22,
		"Games/XBOX360" => 22,
		"HD/X264" => 13,
		"Movies/DVD-R" => 12,
		"Movies/Non-English" => 32,
		"Movies/Packs" => 11,
		"Movies/XviD" => 14,
		"Music > Video" => 17,
		"Music/Audio" => 16,
		"Sports" => 18,
		"Sports/UFC" => 19,
		"Sports/WWE" => 31,
		"TV > Episodes" => 20,
		"TV/Packs" => 20,
		"Windows > Software" => 30,
		"XXX" => 26
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}
1;
