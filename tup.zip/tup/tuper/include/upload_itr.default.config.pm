sub cat_id_xsn_itr{
	my $veids=shift;
	my %cat=(
		"Anime" => 4,
		"Apps" => 10,
		"Apps - Mac" => 10,
		"Audiobooks" => 10,
		"Blu-Ray" => 4,
		"Books Magazines" => 10,
		"Documentaries" => 4,
		"DVDR" => 4,
		"Foreign Tv/Movies" => 4,
		"Kids" => 4,
		"MMA" => 20,
		"Movie Boxsets" => 4,
		"Movies" => 4,
		"Movies Cams/TS" => 11,
		#"Music" => ,
		#"Music Videos" => 0,
		#"NDS Games" => 0,
		#"Other" => 0,
		#"PC Games" => 0,
		#"Pictures" => 0,
		#"Playstation" => 0,
		"PPV" => 3,
		"Soaps	" => 3,
		#"Sports" => 0,
		"TV Boxsets" => 5,
		"HD Boxsets" => 19,
		"TV-x264" => 3,
		"TV-XviD" => 3,
		#"Wii Games" => 0,
		"Wrestling" => 3,
		#"Xbox Games" => 0,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_tv_itr{
	my $veids=shift;
	my %cat=(
		"Appz/0DAY" => 3,
		"Appz/Mac" => 3,
		"Appz/PC-ISO" => 3,
		"Ebooks" => 5,
		"BlurayTV" => 20,
		"Documentaries" => 20,
		"Episodes/TV-Boxset" => 20,
		"Episodes/TV-x264" => 20,
		"Episodes/TV-XviD" => 20,
		"Episodes/TV-Foreign" => 20,
		"Games/Wii" => 10,
		"Games/NDS" => 6,
		"Games/PC-ISO" => 7,
		"Games/PS2" => 9,
		"Games/PS3" => 33,
		"Games/PSP" => 8,
		"Games/Wii" => 10,
		"Game/Packs" => 6,
		"Games/X360" => 22,
		"Movies/Boxsets" => 11,
		"Movies/DVDR" => 12,
		"Movies/x264" => 13,
		"Movies/XviD" => 14,
		"Music/MP3" => 16,
		"Music/Videos" => 17,
		"Music/FLAC" => 15,
		"Requests" => 81,
		"Packs/0DAY" => 3,
		"Packs/Ebooks" => 5,
		"Packs/Music" => 16,
		"Retro/Music" => 16,
		"Episodes/TV-DVDR" => 20,
		"Sports" => 18,
		"Sports/UFC" => 19,
		"Sports/WWE" => 31,
		"XXX" => 26,
		"Windows Software" => 30,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_gft_itr{
	my $veids=shift;
	my %cat=(
		"APPS" => 5,
		"0DAY" => 5,
		"XXX-XVID" => 999,
		"TV-XVID" => 8,
		"Music" => 16,
		"Games/PC" => 9,
		"Movies-XVID" => 13,
		"Movies-DVDR" => 21,
		"E-Learning" => 7,
		"Misc" => 9,
		"Games/XBOX360" => 11,
		"MVID" => 18,
		"GFT Gems" => 999,
		"Anime" => 3,
		"TV-X264" => 8,
		"Movies-X264" => 28,
		"Movies/XviD" => 13,
		"TV-DVDRIP" => 8,
		"XXX-HD" => 999,
		"XXX-0DAY" => 999,
		"Games/WII" => 27,
		"XXX-DVDR" => 999,
		"Portable/Mobile/PDA" => 5,
		"MAC" => 5,
		"Games/PSP" => 12,
		"Games/NDS" => 22
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}


sub cat_id_rtt_itr{
	my $veids=shift;
	my %cat=(
		"Anime" => 77,
		"Apps/Misc" => 81,
		"Appz/PC-ISO" => 3,
		"E-Book" => 95,
		"Games/PC-ISO" => 6,
		"Games/PC-Rips" => 6,
		"Games/PS2" => 85,
		"Games/PS3" => 85,
		"Games/Wii" => 85,
		"Games/XBOX360" => 85,
		"Handheld/PSP" => 91,
		"Mac" => 81,
		"Movies/DVDR" => 87,
		"Movies/Packs" => 82,
		"Movies/WMV" => 77,
		"Movies/x264" => 86,
		"Movies/XviD" => 86,
		"Music" => 84,
		"Music/Packs" => 88,
		"MusicVideos" => 78,
		"TV/DVDR" => 89,
		"TV/HR" => 77,
		"TV/Packs" => 89,
		"TV/x264" => 86,
		"TV/XViD" => 77,
		"XXX" => 90,
		"XXX/DVDR" => 90,
		"XXX/HD" => 90
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_scc_itr{
	my $veids=shift;
	my %cat=(
		"Dox" => 14,
		"Apps/PC ISO" => 7,
		"Games/PC ISO" => 7,
		"Games/PS2" => 1,
		"Games/PS3" => 49,
		"Games/WII" => 22,
		"Games/XBOX" => 1,
		"Games/XBOX360" => 12,
		"MiSC" => 1,
		"Movies/DVDR" => 6,
		"Movies/VCD" => 5,
		"Movies/X264" => 40,
		"Movies/XviD" => 5,
		"TV/DVDR" => 32,
		"TV-X264" => 10,
		"TV/XviD" => 10,
		"XXX" => 1,
		"Apps/0DAY" => 1,
		"MP3" => 4,
		"Music Videos" => 23
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_tl_itr{
	my $veids=shift;
	my %cat=(
		"Anime/Cartoon" => 20,
		"Appz/MAC" => 1,
		"Appz/misc" => 1,
		"Appz/PC ISO" => 25,
		"Appz/PDA" => 25,
		"Books - Mags" => 8,
		"Documentaries" => 14,
		"Episodes/Boxsets" => 10,
		"Episodes/TV" => 10,
		"Episodes" => 10,		
		"Games/PC ISO" => 7,
		"Games/PC Retro" => 7,
		"Games/PC Rips" => 7,
		"Games/PS2" => 1,
		"Games/PS3" => 1,
		"Games/PS2 Retro" => 1,
		"Games/PSP" => 27,
		"Games/Wii" => 22,
		"Games/X360 Retro" => 1,
		"Games/XBOX" => 1,
		"Games/XBOX360" => 12,
		"Movies/DVD-R" => 6,
		"Movies/Foreign" => 5,
		"Movies/HD-x264" => 40,
		"Movies/Music DVD" => 23,
		"Movies/Retro" => 5,
		"Movies/XviD" => 5,
		"Music" => 4,
		"Nintendo DS" => 27,
		"NonScene/BRRip-x264" => 40,
		"NonScene/BRRip-XviD" => 5,
		"NonScene/Xvid" => 5,
		"XXX" => 1
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

sub cat_id_danbit_itr{
	my $veids=shift;
	my %cat=(
		"Appz" => 3,
		"BluRay" =>86,
		"Console" => 85,
		"Covers" => 81,
		"Danishbits Custom" => 81,
		"Danske Film" => 77,
		"Ebooks" => 95,
		"HD-X264" => 86,
		"Movies/DVDnonDK" => 87,
		"Movies/DVDR" => 87,
		"Movies/DVDR-NOR" => 87,
		"Movies/DVDR-SWE" => 87,
		"Movies/XviD" => 77,
		"Music" => 84,
		"Music Videos" => 78,
		"PC Games" => 6,
		"TV" => 77,
		"XXX" => 90
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}

# IPTorrents category converter
sub cat_id_ipt_itr{
	my $veids=shift;
	my %cat=(
		"Appz/misc" => 25,
		"Anime" => 20,
		"Ebooks" => 8,
		"Books - Mags" => 8,
		"Games/Nintendo DS" => 27,
		"Games/PC ISO" => 7,
		"Games/PC Rips" => 7,
		"Games/PS2" => 1,
		"Games/PSP" => 1,
		"Games/PS3" => 49,
		"Games/Wii" => 22,
		"Games/XBOX" => 1,
		"Games/XBOX360" => 12,
		"HD/X264" => 40,
		"Movies/DVD-R" => 6,
		"Movies/Non-English" => 5,
		"Movies/Packs" => 34,
		"Movies/XviD" => 5,
		"Music > Video" => 23,
		"Music/Audio" => 4,
		"Sports" => 18,
		"Sports/UFC" => 18,
		"Sports/WWE" => 38,
		"TV > Episodes" => 10,
		"TV/Packs" => 32,
		"TV/XVID" => 10,
		"Windows > Software" => 1,
		"XXX" => 1
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}
1;
