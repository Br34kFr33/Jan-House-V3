require "include/upload_rbg.config.pm";

sub upload_rbg {

	my $name=shift; # Torrent name from database
	my $category=shift; # Category ID
	my $description=shift; # Description file path
	my $torrent=shift;  # Torrent file path
	my $nfo=shift; # NFO file path
	my $to_tracker=shift; # tracker code (for example: fano)
	my $defname=shift; # Filename from database
	my $defhash=shift; # Download torrent file info hash
	my $config=shift;

	my $r=ClientFunctions->new('upload', 'rbg', $config);

	my $passkey=$config->{cookies}->{passkey_rbg};
	
	###################################
	# Search for original NFO that comes with torrent
	$nfo=$r->find_nfo($torrent, $nfo, $config->{paths}->{download_dir});

	###################################
	# Requesting upload page before sending POST data
	# This should be used to bypass some session verification checks
	my $eh=$r->get("http://rarbg.com/upload");
	return 0 if($eh==0);

	###################################
	# Search for nologin
	my $match_nologin=qr/<form action="\/login" name="login"/ms;
    my $nologin_matches=$r->match('nologin', $match_nologin);
    if($nologin_matches!=0 and not defined $config->{cookies}->{cookie_rbg}){
        $r->err('Can not continue without login, trying to login!');
        $r->form_new;
        $r->form_add('uid', $config->{cookies}->{user_rbg});
        $r->form_add('pwd', $config->{cookies}->{pass_rbg});
        $eh=$r->post("http://rarbg.com/login");
        return 0 if($eh==0);
        $nologin_matches=$r->match('nologin', $match_nologin);
        if($nologin_matches!=0){
                $r->err('Can not continue without login, aborting!');
                return 0;
        }
        $eh=$r->get("http://rarbg.com/upload");
        return 0 if($eh==0);
    }elsif($nologin_matches!=0){
        $r->err('Can not continue without login, aborting!');
        return 0;
    }

    # Copy rbg text file in the download directory so the file
    # gets added to the upload torrent.
    $r->err("Adding the .txt file if the torrent is not single-file torrent.");
    my $upl_data_dir = $r->find_data($torrent, $config->{paths}->{download_dir});
    # Copy only if it is a directory
    if(defined $upl_data_dir and -d $config->{paths}->{download_dir}."/".$upl_data_dir."/"){
        my @argz=($config->{cookies}->{txt_rbg}, $config->{paths}->{download_dir}."/".$upl_data_dir."/");
        system("cp", @argz);
    }
    # Last parameter makes it public
    my $rartorr=$r->rarextract($torrent, $defname, 0, 0, 1);
    $torrent=$rartorr;

    use Net::BitTorrent::File;
    my $fromfile = new Net::BitTorrent::File($torrent);
    delete($fromfile->{data}{"announce-list"});
    delete($fromfile->{data}{"announce"});
    $fromfile->announce('udp://9.rarbg.com:2710/announce');
    $fromfile->{data}{"announce-list"}=[
                               [
                                 'http://10.rarbg.com:80/announce'
                               ],
                               [
                                 'udp://9.rarbg.com:2710/announce'
                               ],
                               [
                                 'udp://11.rarbg.com:80/announce'
                               ]
                             ];
    my $newtorr=$config->{paths}->{temp_dir}.$defname.".torrent";
    $fromfile->save($newtorr);
    if(-f $newtorr){
        $torrent=$newtorr;
    }

    my $finhash=lc($r->bin2hex($fromfile->info_hash()));

    # Read description	
    my $descr_txt=$r->read_file($description);
    if($descr_txt eq $config->{tuper}->{no_descr_txt}){
        $descr_txt=$r->read_file($nfo);
    }
	
	###################################
	# Upload torrent
	$r->form_new;
	# Form fields passed to upload script
	
	# Match IMDB URL
	my $match_imdb=qr/imdb.com\/title\/tt([0-9]*)/ms; 
        my $imdb=""; 
        if($descr_txt =~ $match_imdb){
                $imdb="http://www.imdb.com/title/tt".$1."/"; 
                $r->err("Found IMDB link: ".$imdb); 
        }
	$r->form_add('imdb', $imdb);
	$r->form_add('youtube', '');
	$r->form_add('anonymous', 'true');
        $r->form_add('fontchange', '');
        $r->form_add('user_id', '$user_id');
        $r->form_add('autoset', 'disabled');
	$r->form_add('type', $category);
	$r->form_add('filename', $name);
	$r->form_add('info', $descr_txt);

	# Form files passed to upload script
	return 0 if(not $r->form_add_file('torrent', $torrent, "application/x-bittorrent"));
	return 0 if(not $r->form_add_file('nfo', $nfo, "multipart/form-data"));
        return 0 if(not $r->form_add_file('poster', $config->{cookies}->{poster_rbg}, "image/jpeg"));


	# POSTing data to upload script
	$eh=$r->post("http://rarbg.com/upload");
	return 0 if($eh==0);

	my $torrentid=0;
	###################################
	# Search for already uploaded
	my $match_uploaded=qr/Torrent already exists<\/div>/ms;
	my $uploaded_matches=$r->match('uploaded', $match_uploaded);
	if($uploaded_matches!=0){ $r->err('Torrent already uploaded, adding for seed!'); }else{

		#$r->err($r->{curldat});

		###################################
		# Search for torrent id
		my $match_torrentid=qr/<center>Upload successful. The torrent has been added.<br \/>/ms;
		my $torrentid_matches=$r->match('torrent id', $match_torrentid);
		if($torrentid_matches==0){ $r->err('	Can not continue without success message, aborting!'); return 0;}

	}
	
	###################################
	# Request torrent file
	my $eh=$r->get("http://rarbg.com/download.php?id=".$finhash."&f=some.torrent");
	return 0 if($eh==0);
	
	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("	Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('	Can not continue without infohash, aborting!'); return 0; }
	$r->err('	Downloaded file infohash: '.$down_hash);
	my $newtorr=$r->{curldat};

	$newtorr=$r->remove_hashcheck($config->{paths}->{upload_dir}, $newtorr);
	return 0 if($newtorr eq 0);

	###################################
	# Write torrent file
	my $torr_file=$config->{paths}->{watch2_dir}."[".uc($to_tracker)."]".$defname.".torrent";
	if($r->write_file('torrent', $torr_file, $newtorr)==0){ return 0; }

	my %retvals=(
		"id" => 1,
		"hash" => $down_hash,
	);
	return \%retvals;

}
1;
