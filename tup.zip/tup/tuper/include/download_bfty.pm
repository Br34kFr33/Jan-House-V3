sub download_bfty {

	$tid=shift;
	$config=shift;

	my $r=ClientFunctions->new('download', 'bfty', $config);

	###################################
	# Request page
	my $eh=$r->get("http://bitfactory.dyn.pl/details.php?id=".$tid);
	return 0 if($eh==0);

	###################################
	# Search for nologin
	my $match_nologin=qr/href="login.php">/ms;
	my $nologin_matches=$r->match('nologin', $match_nologin);
	if($nologin_matches!=0){ $r->err('Can not continue without login, aborting!'); return 0;}

	###################################
	# Search for notorrent
	my $match_notorrent=qr/class="tablea">Es existiert kein Torrent mit der ID/m;
	my $notorrent_matches=$r->match('notorrent', $match_notorrent);
	if($notorrent_matches!=0){ $r->err('Can not continue without torrent, aborting!'); return 0;}

	###################################
	# Search for name
	my $match_name=qr/<b>Details zu (.*?) <\/b><\/td>/ms;
	my $name_matches=$r->match('name', $match_name);
	if($name_matches==0){ $r->err('Can not continue without name, aborting!'); return 0;}
	my $name=@$name_matches[0];
	$r->err("Name: $name");

	###################################
	# Search for filename and some hash needed for downloading
	my $match_filename=qr/Herunterladen<\/td><td class="tableb" width="99%" style="text-align:left"><a class="index" href="download.php\?torrent=.*?">(.*?).torrent<\/a>/ms;
	my $filename_matches=$r->match('filename and some hash', $match_filename);
	if($filename_matches==0){ $r->err('Can not continue without filename, aborting!'); return 0;}
	my $downloadname=@$filename_matches[0];
	my $filename=$r->urldecode($downloadname);
	$r->err("Filename: $filename");

	###################################
	# Search for category
	my $match_category=qr/Typ<\/td><td class="tablea" valign="top" align=left>(.*?)<\/td><\/tr>/ms;
	my $category_matches=$r->match('category', $match_category);
	if($category_matches==0){ $r->err('Can not continue without category, aborting!'); return 0;}
	my $category=$r->html_unescape(@$category_matches[0]);
	$r->err("Category: $category...");

	###################################
	# Search for description
	$eh=$r->get("http://bitfactory.dyn.pl/viewnfo.php?id=".$tid."&dl=1");
	return 0 if($eh==0);
    my $description=$r->{curldat};
    if(not defined $description or $description eq ""){
        $r->err('No description found, using default one');
        $description=$config->{tuper}->{no_descr_txt};
    }

	###################################
	# Request torrent page
	$eh=$r->get("http://bitfactory.dyn.pl/download.php?torrent=".$tid);
	return 0 if($eh==0);

	###################################
	# Check for bittorrent header
	my $file_type=$r->curl_get_type();
	if($file_type eq 0 or $file_type ne "application/x-bittorrent"){ $r->err("Downloaded file is not bittorrent: ".$file_type); }

	###################################
	# Get infohash from downloaded file
	my $down_hash = $r->get_infohash_from_curl;
	if($down_hash eq 0){ $r->err('Can not continue without infohash, aborting!'); return 0; }
	$r->err('Downloaded file infohash: '.$down_hash);
	$torrent=$r->{curldat};

	###################################
	# Stripping html from description and converting some of it to bbcode
	if($description ne $config->{tuper}->{no_descr_txt}){ $description=$r->strip_description($description); }

	###################################
	# Writing files
	# Write NFO file
	my $nfo_file=$config->{paths}->{temp_dir}.$filename.".nfo";
	if($r->write_file('nfo', $nfo_file, $description)==0){ return 0; }
	# Wrtie description file
	my $descr_file=$config->{paths}->{temp_dir}.$filename.".txt";
	if($r->write_file('description', $descr_file, $description)==0){ return 0; }
	# Write torrent file
	my $torr_file=$config->{paths}->{temp_dir}.$filename.".torrent";
	if($r->write_file('torrent', $torr_file, $torrent)==0){ return 0; }

	my %retvals=(
		"name" => $name,
		"descr" => $description,
		"filename" => $filename,
		"category" => $category,
		"nfo_file" => $nfo_file,
		"descr_file" =>  $descr_file,
		"torrent_data" => $torrent,
		"down_hash" => $down_hash,
	);
	return \%retvals;

}

1;
