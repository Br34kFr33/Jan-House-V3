
sub cat_id_scc_mom{
	my $veids=shift;
	my %cat=(
        "Movies/DVD-R" => 114,
        "Movies/x264" => 108,
        "Movies/XviD" => 113,
        "TV/DVD-R" => 106,
        "TV/DVDRip" => 106,
        "TV/x264" => 106,
        "TV/XviD" => 106,
        "Games/PC" => 116,
        "Games/PS3" => 117,
        "Games/PSP" => 117,
        "Games/WII" => 112,
        "Games/XBOX360" => 102,
        "APPS" => 103,
        "DOX" => 103,
        "MISC" => 103,
        "MP3" => 110,
        "0DAY" => 103,
        "MVID" => 110,
        "Movies/Packs" => 105,
        "TV/Packs" => 106,
        "Games/Packs" => 116,
        "XXX/Packs" => 113,
        "Music/Packs" => 110,
        "XXX/XviD" =>113,
        "XXX/x264" => 113,
        "XXX/0DAY" => 113,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}


# IPTorrents category converter
sub cat_id_ipt_mom{
	my $veids=shift;
	my %cat=(
        "Anime" => 104,
        "Appz/misc" => 103,
        "AudioBook" => 103,
        "Books - Mags" => 103,
        "Games / Mixed" => 116,
        "Games/Nintendo DS" => 111,
        "Games/PC ISO" => 116,
        "Games/PC Rips" => 116,
        "Games/PS2" => 117,
        "Games/PS3" => 117,
        "Games/PSP" => 117,
        "Games/PSX" => 117,
        "Games/Wii" => 112,
        "Games/XBOX" => 102,
        "Games/XBOX360" => 102,
        "HD/X264" => 108,
        "iPod/Movies" => 109,
        "iPod/TV" => 109,
        "Kids" => 104,
        "MAC" => 103,
        "Mobile" => 103,
        "Movies/DVD-R" => 114,
        "Movies/FLAWL3SS" => 113,
        "Movies/Non-English" => 113,
        "Movies/Packs" => 105,
        "Movies/XviD" => 113,
        "Music > Video" => 110,
        "Music/Audio" => 110,
        "Pics/Wallpapers" => 103,
        "Sports" => 131,
        "TV/Packs" => 106,
        "TV/X264" => 106,
        "TV/XVID" => 106,
        "XXX" => 113,
	);
	return &JhUp::find_hash_value(0, $veids, \%cat);
}
1;
