<?php

error_reporting(E_ERROR & ~(E_WARNING|E_STRICT|E_NOTICE)); // Temp hax until the next big update.

/////////////////////         Config part      /////////////////////////////////
include_once("config.inc.php");
////////////////////////////////////////////////////////////////////////////////

$l['off_txt']='NOT running';
$l['on_txt']='Running';
$l['restart_txt']='Restart';
$l['start_txt']='Try force start';

////////////////////////////////////////////////////////////////////////////////
$h="";
$datef="D M j, H:i:s";

if(!isset($_GET['page'])) $_GET['page']='';
if(!isset($_GET['offset'])) $_GET['offset']='';
    
if($_GET['page']=='more'){

    $db = new SQLite3($tuper_db, SQLITE3_OPEN_READONLY);

    $row=$db->querySingle('SELECT * FROM data WHERE id='.$db->escapeString($_GET['id']), true);
    
/*
    <td{$alt_class}>".$row['started']."</td>
    <td{$alt_class}>".$row['downloaded']."</td>
    <td{$alt_class}>".$row['uploaded']."</td>
    <td{$alt_class}>".$row['seeded']."</td>
    <td{$alt_class}>".$row['upload_infohash']."</td>
    <td{$alt_class}>".$row['infohash']."</td>
    <td{$alt_class}>".$row['download_removed']."</td>
    <td{$alt_class}>".$row['upload_removed']."</td>
    <td{$alt_class}>".$row['from']."</td>
    <td{$alt_class}>".$row['to']."</td>
    <td{$alt_class}>".$row['download_id']."</td>
    <td{$alt_class}>".$row['upload_id']."</td>
*/
    
    /*
Array
(
*    [id] =&gt; 3885
*    [infohash] =&gt; e5ed149c53d5d2737b991af0fd2de6d85f04ab4b
    [name] =&gt; So.You.Think.You.Can.Dance.S08E22.Top.4.Perform.HDTV.XviD-FQ
*    [file] =&gt; So.You.Think.You.Can.Dance.S08E22.Top.4.Perform.HDTV.XviD-FQM
*    [category] =&gt; 41
*    [added] =&gt; 1313031174
*    [started] =&gt; 1313031176
*    [downloaded] =&gt; 
*    [uploaded] =&gt; 
*  [seeded] =&gt; 
*    [upload_infohash] =&gt; 
    [download_removed] =&gt; 
    [upload_removed] =&gt; 
    [from] =&gt; gft
    [to] =&gt; dtn
    [upload_id] =&gt; 
    [download_id] =&gt; 529037
)
*/
$h.='<div class="clear"></div>';

$h.='<div class="infotable"><table>';

$h.='<tr>
<th>Entry ID</th>
<td><strong>'.$row['id'].'</strong></td>
</tr>';

$h.='<tr>
<th>Filename</th>
<td><strong>'.$row['file'].'</strong></td>
</tr>';

$h.='<tr>
<th>Download Infohash</th>
<td>'.$row['infohash'].'</td>
</tr>';

$h.='<tr>
<th>Upload Infohash</th>
<td>'.($row['upload_infohash'] ? $row['upload_infohash'] : '---').'</td>
</tr>';

$h.='<tr>
<th>Target category ID</th>
<td>'.$row['category'].'</td>
</tr>';


$h.='</table></div>';

$h.='<div class="infotable"><table>';

$h.='<tr>
<th>Started downloading</th>
<td>'.($row['started']>0 ? nice_date($row['started']) : '---').'</td>
</tr>';

$h.='<tr>
<th>Finished downloading</th>
<td>'.($row['uploaded']>0 ? nice_date($row['uploaded']) : '---').'</td>
</tr>';

$h.='<tr>
<th>Uploaded torrent</th>
<td>'.($row['downloaded']>0 ? nice_date($row['downloaded']) : '---').'</td>
</tr>';

$h.='<tr>
<th>Started seeding upload</th>
<td>'.($row['seeded']>0 ? nice_date($row['seeded']) : '---').'</td>
</tr>';

$h.='</table></div>';

$h.='<div class="clear"></div>';

    //print_r($row);
    //print $tuper_com." upload ".$row['infohash'];
    //print exec($tuper_com." upload ".escapeshellarg($row['infohash']));
    $h.='<div class="buttonlist"><button type="button" id="download'.$row['id'].'" class="download" onclick="download('.$row['id'].');return false;">Force download again!</button>';
    $h.='<button type="button" id="deldown'.$row['id'].'" class="deldown" onclick="deldown('.$row['id'].');return false;">Force remove download</button>';
    if($row['upload_infohash']!='')
    $h.='<button type="button" id="delup'.$row['id'].'" class="delup" onclick="delup('.$row['id'].');return false;">Force remove upload</button></div>';
    print $h;
    $db->close(); 
    die();
}elseif($_GET['page']=='logstream'){

    @ini_set('implicit_flush',1);
    @ob_end_clean();
    set_time_limit(0);
    @apache_setenv('no-gzip', 1);
    @ini_set('zlib.output_compression', 0);

    // start output buffer
    if (ob_get_level() == 0) ob_start();

/*
    for($i=0;$i<70;$i++)
    {
        $data="printing<br />";
        print str_pad($data,4096)."\n";
        
        ob_flush();
        flush();
        usleep(500000);

        // depending on what you are doing, you may or may not need this
        set_time_limit(30); 

    }
*/

 //if (!is_numeric($client_port) or !is_numeric($timeout)) {return false;}
 $socket = fsockopen($client_ip, $client_port, $errno, $errstr, $connect_timeout);
 fputs($socket, '{"c":"logstream"}'."\n");
 $data = '';
 $zb=0;
 while (!feof($socket))
 {

    $data.= fgets($socket, 4096);
    

    if(strlen($data)<296 and $zb<2){
        $zb++;
        usleep(100000);
            //2000000 - 2 sec
        continue;
    }
    
    $zb=0;
    $pos = strrpos($data, "\n");
    if ($pos === false){ continue; }
    $msg=substr($data, 0, $pos);
    $data=substr($data, $pos, strlen($data));
    
    $msg=str_replace("[0m", "</span>", $msg);
    $msg=str_replace("[30m", '<span style="color:black">', $msg);
    $msg=str_replace("[31m", '<span style="color:red">', $msg);
    $msg=str_replace("[32m", '<span style="color:green">', $msg);
    $msg=str_replace("[33m", '<span style="color:yellow">', $msg);
    $msg=str_replace("[34m", '<span style="color:blue">', $msg);
    $msg=str_replace("[35m", '<span style="color:magenta">', $msg);
    $msg=str_replace("[36m", '<span style="color:cyan">', $msg);
    $msg=str_replace("[37m", '<span style="color:gray">', $msg);
    $msg=str_replace("\n", "<br />\n", $msg);
    print str_pad($msg."",4096);

        ob_flush();
        flush();

 }

 fclose($socket);

    die();
    
}elseif($_GET['page']=='upload'){
    
    set_time_limit(0);
    $db = new SQLite3($tuper_db, SQLITE3_OPEN_READONLY);

    $row=$db->querySingle('SELECT * FROM data WHERE id='.$db->escapeString($_GET['id']), true);
    //print_r($row);
    print $tuper_com." upload ".$row['infohash']."\n";
    print exec($tuper_com." upload ".escapeshellarg($row['infohash']));



    //print "123";
    $db->close();
    die();
}elseif($_GET['page']=='download'){
set_time_limit(0);
    $db = new SQLite3($tuper_db, SQLITE3_OPEN_READONLY);

    $row=$db->querySingle('SELECT * FROM data WHERE id='.$db->escapeString($_GET['id']), true);
    //print_r($row);
    print $tuper_com." get ".$row['from']." ".$row['download_id']." ".$row['to']."\n";
    print exec($tuper_com." get ".$row['from']." ".$row['download_id']." ".$row['to']);



    //print "123";
    $db->close();
    die();
}elseif($_GET['page']=='deldown'){
set_time_limit(0);
    $db = new SQLite3($tuper_db, SQLITE3_OPEN_READONLY);

    $row=$db->querySingle('SELECT * FROM data WHERE id='.$db->escapeString($_GET['id']), true);
    //print_r($row);
    print $eliminator_com." del down ".$row['infohash']."\n";
    print exec($eliminator_com." del down ".$row['infohash']);



    //print "123";
    $db->close();
    die();
}elseif($_GET['page']=='delup'){
set_time_limit(0);
     $db = new SQLite3($tuper_db, SQLITE3_OPEN_READONLY);

    $row=$db->querySingle('SELECT * FROM data WHERE id='.$db->escapeString($_GET['id']), true);
    //print_r($row);
    print $eliminator_com." del up ".$row['upload_infohash']."\n";
    print exec($eliminator_com." del up ".$row['upload_infohash']);

    //print "123";
    $db->close();
    die();
    
}elseif($_GET['page']=='status'){
    set_time_limit(0);
    $param='';
    if($_GET['param']=='rt1') $param=' rt1';
    if($_GET['param']=='rt2') $param=' rt2';
    
    $status=exec($status_cmd.$param);
    print $status;
    die();
}elseif($_GET['page']=='restart'){
    set_time_limit(0);
    $param='';
    if($_GET['param']=='rt1') $param=' rt1';
    if($_GET['param']=='rt2') $param=' rt2';
    if($_GET['action']==0 or $_GET['param']=='rt1' or $_GET['param']=='rt2') $status=exec($start_cmd.$param);
    else $status=exec($restart_cmd);
    print $status;
    die();
}elseif($_GET['page']=='rt_status'){
    set_time_limit(0);
/*
    include_once("ixr.php");
    $h='';
    
    $client = new IXR_Client($scgi2);
    
    $hash="A2D26B51A8DF8E9DD7E532A951CBDC6440761586";
    
    $client->query("t.get_url", $hash, 0);
    $announce=$client->getResponse();
    
	if($announce['faultString']=="Could not find info-hash."){
        print "Nav tāds torrentos...\n";
	}else{
$h.="<br />\n";
			$client->query("d.get_state", $hash);
			$statuss=$client->getResponse();
			$h.=$statuss == 1 ? 'Working' : 'Stopped';
		$h.="<br />\n";
			$client->query("d.get_complete", $hash);
			$complete=$client->getResponse();
			$h.=$complete==1 ? 'Seeding' : 'Leeching';	
			$h.="<br />\n";
			$client->query("d.get_completed_bytes", $hash);
			$complete_bytes=$client->getResponse();
			print $complete_bytes;	
$h.="<br />\n";
			$client->query("d.get_hashing", $hash);
			$hashing=$client->getResponse();
			$h.=$hashing == 1 ? 'Hashing' : '';
			$h.="<br />\n";
			
			$client->query("d.get_name", $hash);
			$name=$client->getResponse();
			$h.=$name;
$h.="<br />\n";

#d.get_hashing

print $h;
//d.get_connection_leech
 //   [84] => d.get_connection_seed


$client->query("d.get_ratio", $hash);
$ratio=$client->getResponse();
if(is_array($ratio)){
print "No raatijo\n";
}
print $ratio."\n";

else if($ratio>$upload_removal_ratio){
$errors.="	Torrent (".$row["name"].") ratio is greater then ".($upload_removal_ratio/1000).".\n";
remove_torrent($row);

}else if($row['downloaded']<$remove_time){
$errors.="	Torrent (".$row["name"].") has been in the list for more then ".$upload_removal_time." hours.\n";
remove_torrent($row);

}

$client->query('d.get_base_path', $row["upload_infohash"]);
$mape=$client->getResponse();
$rmlocked[$row['id']]=$row['id'];
if(is_array($mape)){
$errors.="	Folder not found...\n";
}else{			


//print $ratio." - ".$row['name'];

}    

//$teh=$client->get_session();
//$teh1=$client->d->is_open("AEC9CA1D77D23EC7FDE1E58DD8D636C01F157FDC");
//$teh2=$client->d->state("AEC9CA1D77D23EC7FDE1E58DD8D636C01F157FDC");
//print_r($announce);
    
//print_r($teh1);
//print_r($teh2);
*/
    die();
}elseif($_GET['page']=='log'){
    set_time_limit(0);
$h='';
$h.='
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US"> 
<head> 
<title>Torrent auto uploader web manager</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
<link href="design.css" rel="stylesheet" type="text/css" media="screen" /> 
<script type="text/javascript" src="jquery-1.4.4.min.js"></script> 
<script type="text/javascript" src="jquery.hoverIntent.minified.js"></script>
<script type="text/javascript" src="jquery.ajax-http-stream.js"></script> 
<script type="text/javascript" src="common.js"></script>
<script type="text/javascript" src="log.js"></script>
</head>
<body>
<div id="preloader" style="display: none;"></div>
<div id="stream"><span class="logblock">Keep this window open to see tuper client output stream.<br /></span></div>
</body>
</html>
';
print $h;
die();
}

////////////////////////////////////////////////////////////////////////////////

$h.='
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US"> 
<head> 
<title>Torrent auto uploader web manager</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
<link href="design.css" rel="stylesheet" type="text/css" media="screen" /> 
<script type="text/javascript">
var stat_on_txt=\''.$l['on_txt'].'\';
var stat_off_txt=\''.$l['off_txt'].'\';
var restart_txt=\''.$l['restart_txt'].'\';
var start_txt=\''.$l['start_txt'].'\';
</script>
<script type="text/javascript" src="jquery-1.4.4.min.js"></script> 
<script type="text/javascript" src="jquery.hoverIntent.minified.js"></script>
<script type="text/javascript" src="jquery.ajax-http-stream.js"></script> 
<script type="text/javascript" src="common.js"></script>
<script type="text/javascript" src="tuper.js"></script>
</head>

<body><div id="preloader" style="display: none;"></div><div id=container>';

$db = new SQLite3($tuper_db, SQLITE3_OPEN_READONLY);;

$h.='<h1><a href="?">Torrent auto uploader database</a> (alpha version)</h1>
    <div><strong>Server time: '.date($datef).'</strong></div>';

//$h.='<a href="?page=log" class="viewlog" >View tuper-client output</a>';

//////// Tuper client status

$h.='<div class="tuper_status">
Click the button to check status.<br />
Keep in mind that restarting rTorrent with many torrents can be really slow, use only if really needed.
<div class="clear"></div>
<div class="service">
<h3>Tuper-client</h3>
<button onclick="tuper_status(\'tuper\')" id="tuper_status_tuper" class="">click me!</button>
<button onclick="tuper_restart(\'tuper\')" id="tuper_restart_tuper" class="hide"></button><br />
<button onclick=\'window.open("?page=log", "log", "width=850,height=450")\' class="">Tuper-client output stream</button>
</div>
<div class="service">
<h3>rTorrent 1 (downloads) screen session</h3>
<button onclick="tuper_status(\'rt1\')" id="tuper_status_rt1" class="">click me!</button>
<button onclick="tuper_restart(\'rt1\')" id="tuper_restart_rt1" class="hide"></button>
</div>
<div class="service">
<h3>rTorrent 2 (uploads) screen session</h3>
<button onclick="tuper_status(\'rt2\')" id="tuper_status_rt2" class="">click me!</button>
<button onclick="tuper_restart(\'rt2\')" id="tuper_restart_rt2" class="hide"></button>
</div>
<div class="clear"></div>
</div>
<hr />';

///////////////////////////////////

$s_ql='';
$s_url='';
if(isset($_GET['search']) and $_GET['search']!=''){
    
    $vardi=explode(" ", $_GET['search']);
    $s_string=implode("%", $vardi);
    
    $s_ql=' WHERE `name` LIKE "'.$db->escapeString('%'.$s_string.'%').'" OR `file` LIKE "'.$db->escapeString('%'.$s_string.'%').'"';
    $s_url='&search='.urlencode($_GET['search']);
}

////////////////// Paginator /////////////////////////
$offset_num=50;
$offnow=(($_GET['offset']-1)>=0 ? $_GET['offset']-1 : 0);
$offset=$offnow*$offset_num;
//print "".'SELECT COUNT(*) FROM data'.$s_ql;
$count=$db->querySingle('SELECT COUNT(*) FROM data'.$s_ql);
$pages=ceil($count/$offset_num);

$h.="<div>Query returned $pages pages.</div>";
$offpage='';
$showpages=($pages<10 ? $pages : 10);
if($offnow>floor($showpages/2)) $offpage=$offnow-floor($showpages/2);
if($offnow>$pages-floor($showpages/2)) $offpage=$pages-$showpages;
    $paginator="<div style=\"width:100%;text-align:center\">";
if($pages>=10)
    $paginator.=($offnow>=floor($showpages/2) ? "<a href=\"?offset=1$s_url\" style=\"margin:10px\"><<<</a> " : '');
for($i=1;$i<=$showpages;$i++){
    $k=$offpage+$i;
    $paginator.=($offnow+1==$k ? "<strong>$k</strong>" : "<a href=\"?offset=$k$s_url\" style=\"margin:10px\">".$k."</a> ");
}
if($pages>=10)
    $paginator.=($offnow<$pages-floor($showpages/2) ? "<a href=\"?offset=$pages$s_url\" style=\"margin:10px\">>>></a> " : '');
$paginator.="</div>";
//////////////////////////////////////////////////////////////////
$h.=$paginator;

$h.='<form name="browser" method="GET" action="?">Search: <input type="text" name="search" value="'.(isset($_GET['search']) ? $_GET['search'] : '').'" style="width: 300px;" /><input type="submit" value="Search" /></form>';

if($count==0){

    $h.="<h1>Query returned nothing!</h2>";

}else{
//print "<br />".'SELECT * FROM data '.$s_ql.'ORDER BY id DESC LIMIT '.$offset_num.' OFFSET '.$offset;
    $results = $db->query('SELECT * FROM data '.$s_ql.'ORDER BY id DESC LIMIT '.$offset_num.' OFFSET '.$offset);

    $h.='
    <table id="mytable" cellspacing="0">
    <caption>Click on the release name to get more details (requires javascript). <button type="button" id="closedata">Close all!</button></caption>
    <tr>
        <th scope="col" class="nobg">Name</th>
        <th scope="col">Added</th>
        <th scope="col">Download removed</th>
        <th scope="col">Upload removed</th>
        <th scope="col">From</th>
        <th scope="col">Download ID</th>
        <th scope="col">To</th>
        <th scope="col">Upload ID</th>
    </tr>
    ';

    $i=0;
    while ($row = $results->fetchArray()) {

    $alt_spec=($i % 2 == 0 ? ' class="specalt"' : ' class="spec"');
    $alt_class=($i++ % 2 == 0 ? ' class="alt"' : '');

    $h.="
    <tr id=\"data{$row['id']}\" class=\"hovery\">
        <th{$alt_spec}><a href=\"#\" class=\"loadmore\">".$row['name']."</a></th>
        <td{$alt_class}>".nice_date($row['added'])."</td>
        <td{$alt_class}>".($row['download_removed']>0 ? nice_date($row['download_removed']) : '<a href="#" id="deldown'.$row['id'].'" class="red deldown" onclick="deldown('.$row['id'].');return false;">REMOVE</a>')."</td>
        <td{$alt_class}>".($row['upload_removed']>0 ? nice_date($row['upload_removed']) : ($row['upload_infohash']!='' ? '<a href="#" id="delup'.$row['id'].'" class="delup" onclick="delup('.$row['id'].');return false;">REMOVE</a>' : '---'))."</td>
        <td{$alt_class}>".$row['from']."</td>
        <td{$alt_class}>".$row['download_id']."</td>
        <td{$alt_class}>".$row['to']."</td>
        <td{$alt_class} style=\"min-width:70px\">".($row['upload_id']>0 ? $row['upload_id'] : (($row['download_removed']>0 and $row['upload_removed']>0) ? '---' : '<a id="upload'.$row['id'].'" href="#" onclick="upload('.$row['id'].');return false;" class="red upload">UPLOAD</a>'))."</td>
    </tr>
    ";

    $h.="</tr>";
    }
    $h.="</table>";
    $h.='<br />'.$paginator;

}

$h.='<div style="margin-top:30px;text-align:center" class="footer"><p>&copy; Jānis Jansons (Janhouse)</p></div></div></body>
</html>';
$db->close();
print $h;

function nice_date($timestamp){
    if(date("dmY")==date("dmY", $timestamp)){
        $datef="H:i:s";
        $nice_date="today, ".date($datef, $timestamp);
    }else{
        $datef="D M j, H:i:s";
        $nice_date=date($datef, $timestamp);
    }
    return $nice_date;
}

?>
