		var loading='Loading...';
		var done='Done';
		var srtext='Text to search...';
		var failedtxt='Failed loading data...';
        var status_running=new Array();
        var specialTime=15000;
////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {

////////////////////////////////////////////////////////////////////////////////

	$("div#preloader").hide();
 
	var skaits=1;
	preload_on = function(){
	$("html").addClass("curs-loading");
	if ($("div#preloader").is(":hidden")){
	skaits=0;
	$("div#preloader").html(loading+"...");
	$("div#preloader").fadeIn("fast");
	}else{
	skaits=skaits+1;
	var skaits2=skaits+1;
	$("div#preloader").html(loading+"... ("+skaits2+")");
	$("div#preloader").fadeIn("fast");
	}
	}
 
	preload_off = function(){

	if(skaits==0){
		$("html").removeClass("curs-loading");
	$("div#preloader").html(done+"...");
	$("div#preloader").fadeOut("fast");
	}else{
	skaits=skaits-1;
	var skaits2=skaits+1;
	if(skaits2==1){
		$("html").removeClass("curs-loading");
	$("div#preloader").html(done+"...");
	$("div#preloader").fadeOut("fast");
	}else{
	$("div#preloader").html(loading+"... ("+skaits2+")");
	}
	}
	}

////////////////////////////////////////////////////////////////////////////////

});
