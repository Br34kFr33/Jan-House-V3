/// Check tuper status
function tuper_status(param){
    var url='index.php?page=status&param='+param;
    var elem=$('#tuper_status_'+param);
    var restart=$('#tuper_restart_'+param);
    var parent=elem.parent();
    var status_message;
    var status_class;
    var status_noclass;
    var restart_message;
    //var oldparent=$('#download'+id).parent();
        preload_on();
        $.get(url, function(data){
            if(data>0){
                status_message=stat_off_txt;
                status_class='tuper_off';
                status_noclass='tuper_on';
                restart_message=start_txt;
                status_running[param]=0;
            }else{
                status_message=stat_on_txt;
                status_class='tuper_on';
                status_noclass='tuper_off';
                restart_message=restart_txt;
                status_running[param]=1;
            }
            parent.fadeOut('fast', function(){
                elem.addClass(status_class);
                elem.removeClass(status_noclass);
                elem.html(status_message);
                restart.html(restart_message).show();
                parent.fadeIn('fast');
            });
            preload_off();
    });
}

/// Send restart command
function tuper_restart(param){
    var url='index.php?page=restart&param='+param+'&action='+(status_running[param] ? 1 : 0);
    var elem=$('#tuper_restart_'+param);
        preload_on();
        $.get(url, function(data){
            //alert(data);
            preload_off();
            window.setTimeout(function(){ tuper_status(param); }, 3000);
    });
}

function specialLoop(){
    tuper_status('tuper');
    tuper_status('rt1');
    tuper_status('rt2');
	setTimeout('specialLoop()', specialTime);
}

/// Uploading finished, failed torrent
function upload(id){
    var url='index.php?page=upload&id='+id;
    var oldelem=$('#upload'+id);
    var oldparent=$('#upload'+id).parent();
    var oldhtml=oldelem.parent().html();
    oldelem.parent().fadeOut('fast', function(){$(this).html("Loading...").fadeIn('fast', function(){
        preload_on();
        $.get(url, function(data){
        alert(data);
            if(data>0)oldparent.fadeOut('fast', function(){oldparent.html("Success!").fadeIn('fast').delay(1000).fadeOut('fast', function(){$(this).html(data).fadeIn('fast');});});
            else oldparent.fadeOut('fast', function(){oldparent.html("Failed!").fadeIn('fast').delay(1000).fadeOut('fast', function(){$(this).html(oldhtml).fadeIn('fast');});});
            preload_off();
        });
    });});
}

/// Uploading finished, failed torrent
function download(id){
    var url='index.php?page=download&id='+id;
    var oldelem=$('#download'+id);
    var oldparent=$('#download'+id).parent();
    var oldhtml=oldelem.parent().html();
    oldelem.parent().fadeOut('fast', function(){$(this).html("Loading...").fadeIn('fast', function(){
        preload_on();
        $.get(url, function(data){
        alert(data);
            if(data>0)oldparent.fadeOut('fast', function(){oldparent.html("Success!").fadeIn('fast').delay(1000).fadeOut('fast', function(){$(this).html(data).fadeIn('fast');});});
            else oldparent.fadeOut('fast', function(){oldparent.html("Failed!").fadeIn('fast').delay(1000).fadeOut('fast', function(){$(this).html(oldhtml).fadeIn('fast');});});
            preload_off();
        });
    });});
}

/// Uploading finished, failed torrent
function deldown(id){
    var url='index.php?page=deldown&id='+id;
    var oldelem=$('#deldown'+id);
    var oldparent=$('#deldown'+id).parent();
    var oldhtml=oldelem.parent().html();
    oldelem.parent().fadeOut('fast', function(){$(this).html("Loading...").fadeIn('fast', function(){
        preload_on();
        $.get(url, function(data){
        alert(data);
            if(data>0)oldparent.fadeOut('fast', function(){oldparent.html("Success!").fadeIn('fast').delay(1000).fadeOut('fast', function(){$(this).html(data).fadeIn('fast');});});
            else oldparent.fadeOut('fast', function(){oldparent.html("Failed!").fadeIn('fast').delay(1000).fadeOut('fast', function(){$(this).html(oldhtml).fadeIn('fast');});});
            preload_off();
        });
    });});
}

/// Uploading finished, failed torrent
function delup(id){
    var url='index.php?page=delup&id='+id;
    var oldelem=$('#delup'+id);
    var oldparent=$('#delup'+id).parent();
    var oldhtml=oldelem.parent().html();
    oldelem.parent().fadeOut('fast', function(){$(this).html("Loading...").fadeIn('fast', function(){
        preload_on();
        $.get(url, function(data){
        alert(data);
            if(data>0)oldparent.fadeOut('fast', function(){oldparent.html("Success!").fadeIn('fast').delay(1000).fadeOut('fast', function(){$(this).html(data).fadeIn('fast');});});
            else oldparent.fadeOut('fast', function(){oldparent.html("Failed!").fadeIn('fast').delay(1000).fadeOut('fast', function(){$(this).html(oldhtml).fadeIn('fast');});});
            preload_off();
        });
    });});
}

////////////////////////////////////////////////////////////////////////////////


$(document).ready(function() {

/// Opening and closing single row
$('a.loadmore').click(function(){
    var thisid=$(this).parent().parent().attr("id");
    if ($('#some'+thisid).length > 0){
        $('#some'+thisid).children('td').slideUp("fast", function(){$(this).parent().remove();});
    }else{
        $('#'+thisid).after('<tr id="some'+thisid+'" class="somedata"><td class="moredata" colspan="8"><div class="moredata-inner"></div></td></tr>');
        preload_on();
        $.get('index.php?page=more&id='+thisid.substr(4,thisid.length), function(data) {
            $('#some'+thisid).children('td').children('div.moredata-inner').html(data).slideDown("fast");
            preload_off();
        });
    }
    return false;
});

/// Closing all rows
$('#closedata').click(function(){
    $('.somedata').each(function () {
         $(this).children('td').slideUp("fast", function(){$(this).parent().remove();});
    });
});

/*
/// Uploading finished, failed torrent
$('a.upload').click(function(){
alert("aaa");
    var thisid=$(this).attr('id');
    var url='index.php?page=upload&id='+thisid.substr(6,thisid.length);
    var oldelem=$(this);
    var oldhtml=$(this).parent().html();
    $(this).fadeOut('fast', function(){$(this).parent().html("Loading...").fadeIn('fast');});
        preload_on();
        $.get(url, function(data){
            if(data>0) oldelem.parent().fadeOut('fast', function(){$(this).html("Success!");});
            else oldelem.parent().fadeOut('fast', function(){$(this).html("Failed!").delay(1000).fadeOut('fast', function(){$(this).html(oldhtml).fadeIn('fast');});});
            preload_off();
        });
    return false;
});
*/

////////////////////////////////////////////////////////////////////////////////
// alert("Hello");
//tuper_status();
some=specialLoop();


    $('.viewlog').click(function (event){
        window.open($(this).attr("href"), "log", "width=850,height=450");
        event.preventDefault();
    });


});
