<?php
// Rename this file to config.inc.php
$tuper_com="/home/tup/tuper/tuper.sh"; #tuper location
$eliminator_com="/home/tup/tuper/tuper.sh"; #eliminator location
$tuper_db='/home/tup/storage/tuper.db'; #database location
$status_cmd='sudo -H -u tup /home/tup/tuper/status.sh'; # status script
$restart_cmd='/home/tup/tuper/tuper.sh restart'; # restart script
$start_cmd='sudo -H -u tup /home/tup/tuper/start-screen.sh'; # screen start script
$scgi1="http://127.0.0.1/rt1";
$scgi2="http://127.0.0.1/rt2";
$client_ip="127.0.0.1";
$client_port="8505";
$connect_timeout="10";
?>
