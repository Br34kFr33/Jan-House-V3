$(document).ready(function() {

////////////////////////////////////////////////////////////////////////////////

preload_on();
$.post('?page=logstream',
    function(data, status) /* On Request Complete */
    {
        $('#stream').html(data); // put all the data in there
        $("#state").html(status); // update status
        //alert("stream closed");
        preload_off();
    },
    function(packet,status,fulldata, xhr) /* If the third argument is a function it is used as the OnDataRecieved callback */
    {
        //alert("pacanii");
        //$("#len").html(fulldata.length); // total how much was recieved so far
        //$("#state").html($('.logblock').length+" - jee"); // status (can be any ajax state or "stream"
        var data = $("#stream").html(); // get text of what we received so far
        data += '<span class="logblock">'+packet+"</span>"; // append the last packet we got
        $("#stream").html(data); // update the div
        //$("<li></li>").html(packet).appendTo("#stream"); // add this packet to the list
        $("#stream").scrollTop($("#stream")[0].scrollHeight);

        if($('.logblock').length>20)
        $('.logblock:lt(1)').css("background-color", "red").remove();
        
    }
);

////////////////////////////////////////////////////////////////////////////////

});
