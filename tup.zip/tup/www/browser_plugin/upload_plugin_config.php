<?php
// Rename this file to upload_plugin_config.php
$access_key="lpAWdhC0a__gYnKl"; // Key used in browser plugin configuration
$tuper_com="/home/tup/tuper/tuper.sh get"; // On Linux, something like 
                                            // "/home/tup/tuper/tuper.sh get"
                                            
// Tracker array. Make sure you update it when new download functions are added.
$trackers=array(
    'www.revolutiontt.net' => 'rtt',
    'revolutiontt.net' => 'rtt',
    'www.revolutiontt.me' => 'rtt',
    'revolutiontt.me' => 'rtt',

    'torrents.yourexotic.com' => 'yec',

    'www.torrent-damage.net' => 'toda',
    'torrent-damage.net' => 'toda',

    'www.danishbits.org' => 'danbit',
    'danishbits.org' => 'danbit',

    'www.thegft.org' => 'gft',
    'thegft.org' => 'gft',

    'www.torrentleech.org' => 'tl',
    'torrentleech.org"' => 'tl',

    'www.torrentvault.org' => 'tv',
    'torrentvault.org' => 'tv',

    'www.sceneaccess.org' => 'scc',
    'sceneaccess.org' => 'scc',
    'www.sceneaccess.eu' => 'scc',
    'sceneaccess.eu' => 'scc',

    'www.iptorrents.com' => 'ipt',
    'iptorrents.com' => 'ipt',
    'on.iptorrents.com' => 'ipt',
    'www.iptorrents.me' => 'ipt',
    'iptorrents.me' => 'ipt',

    'www.bitmetv.org' => 'btv',
    'bitmetv.org' => 'btv',

    'www.hdbits.org' => 'hdb',
    'hdbits.org' => 'hdb',

    'www.chdbits.org' => 'chd',
    'chdbits.org' => 'chd',

    'www.scenehd.org' => 'shd',
    'scenehd.org' => 'shd',

    'www.torrentbytes.net' => 'tb',
    'torrentbytes.net' => 'tb',

    'www.bitgamer.su' => 'bg',
    'bitgamer.su' => 'bg',
    'www.bitgamer.com' => 'bg',
    'bitgamer.com' => 'bg',

    'www.linkomanija.net' => 'ln',
    'linkomanija.net' => 'ln',

    'www.freshon.tv' => 'fro',
    'freshon.tv' => 'fro',

    'www.broadcasthe.net' => 'btn',
    'broadcasthe.net' => 'btn',

    'www.xnt.nu' => 'xnt',
    'xnt.nu' => 'xnt',

    'torrentday.com' => 'td',
    'www.torrentday.com' => 'td',
    'torrentday.me' => 'td',
    'www.torrentday.me' => 'td',
    'torrentday.ru' => 'td',
    'www.torrentday.ru' => 'td',

    'thedvdclub.org' => 'tdc',
    'www.thedvdclub.org' => 'tdc',

    'www.pussytorrents.org' => 'ptr',
    'pussytorrents.org' => 'ptr',

    'www.xtremespeeds.net' => 'xsn',
    'xtremespeeds.net' => 'xsn',
    'www.xspeeds.com' => 'xsn',
    'xspeeds.com' => 'xsn',

	'norbits.net'=>'norb',
	'www.norbits.net'=>'norb',

	'scanbits.org'=>'scnb',
	'www.scanbits.org'=>'scnb',

	'torrentstart.nu'=>'trns',
	'www.torrentstart.nu'=>'trns',

	'sparvar.org'=>'sprv',
	'www.sparvar.org'=>'sprv',

	'tecknat.net'=>'tecn',
	'www.tecknat.net'=>'tecn',

	'filmbits.net'=>'fbn',
	'www.filmbits.net'=>'fbn',

	'nordic-t.org'=>'nt',
	'www.nordic-t.org'=>'nt',

	'tti.nu'=>'tti',
	'www.tti.nu'=>'tti',

	'digitalhive.org'=>'dh',
	'www.digitalhive.org'=>'dh',

	'hd-space.org'=>'hds',
	'www.hd-space.org'=>'hds',

	'bit-hdtv.com'=>'bhdtv',
	'www.bit-hdtv.com'=>'bhdtv',

	'trancetraffic.com'=>'tt',
	'www.trancetraffic.com'=>'tt',

	'scenebits.info'=>'sceb',
	'www.scenebits.info'=>'sceb',

	'hd-torrents.org'=>'hdt',
	'www.hd-torrents.org'=>'hdt',

	'filelist.ro'=>'flr',
	'www.filelist.ro'=>'flr',

	'scanbytes.org'=>'sby',
	'www.scanbytes.org'=>'sby',

	'ninjabits.org'=>'njb',
	'www.ninjabits.org'=>'njb',

	'tsnu.ru'=>'tsnu',
	'www.tsnu.ru'=>'tsnu',

	'swedream.net'=>'swd',
	'www.swedream.net'=>'swd',

	'www.bitsoup.org'=>'bs',
	'bitsoup.org'=>'bs',

    'www.demonoid.me'=>'dmn',
    'demonoid.me'=>'dmn',

    'www.ilovetorrents.com'=>'ilt',
    'ilovetorrents.com'=>'ilt',

);

// Regexp to match domain, id and check if the link is usable.
// Update if new download sources are added or SVN log says to do so.
$matcher='/https?:\/\/(.*)\/(index|details|torrents|torrent|files)(.php)?(\?page=torrent-details&id=|\?id=|\/details\/|\/|\?)([0-9a-z]*?)(&hit(=1)?|$|.*$)/msU';
$matcher_name_num=1;
$matcher_domain_num=5;
?>
