<?php
set_time_limit(0);
include_once("upload_plugin_config.php");
$details="<br />Details on <a href='http://www.janhouse.lv/'>www.janhouse.lv</a>";
if(!isset($_GET['tracker'], $_GET['key'], $_GET['link']))
    die("Not all necessary parameters were passed. Are you really using uploader
     browser plugin to access this page?".$details);
$tracker=$_GET['tracker'];
$key=urldecode($_GET['key']);
$link=urldecode($_GET['link']);
if(!isset($access_key, $tuper_com, $trackers, $matcher, $matcher_name_num, $matcher_domain_num))
    die("Some configuration parameters are missing. Did you mess up config?".
    $details);
if($key!==$access_key)
	die("Inorrect key, access denied!".$details);
if($link=="")
	die("Empty link!".$details);
	if(!preg_match($matcher,$link,$name))
		die("Useless link! Are you really selecting link to torrent description
		 page?".$details);
    else{
        $domain=$name[$matcher_name_num];
        $tid=$name[$matcher_domain_num];
        manual_download($trackers, $domain, $tid, $tracker, $tuper_com);
	}
function manual_download($trackers, $domain, $tid, $tracker, $tuper_com){
    if(!isset($trackers[$domain])){
        print "Plugin serverisde script is not configured for this source.".
        $details;   
        return 0;
    }
    print "Download from <b>".strtoupper($trackers[$domain])."</b><br />Upload to <b>$tracker</b><br />Torrent ID: <b>".$tid."</b><br /><br />";
    print exec($tuper_com." ".$trackers[$domain]." ".escapeshellarg($tid)." ".escapeshellarg($tracker));
    return 1;
}
?>
