﻿/*
 * PLUGIN SeedingTime
 *
 * File Name: fr.js
 * 	French language file.
 *
 * File Author:
 *    Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.seedingTime          = "Terminé";
 theUILang.addTime              = "Ajouté";

thePlugins.get("seedingtime").langLoaded();