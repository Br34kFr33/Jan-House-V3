﻿
 theUILang.seedingTime		= "Ukończono";
 theUILang.addTime		= "Added";

thePlugins.get("seedingtime").langLoaded();